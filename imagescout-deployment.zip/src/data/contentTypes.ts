
import { ContentSuggestion } from '@/types/content';

// Re-export for backwards compatibility
export type { ContentSuggestion };
