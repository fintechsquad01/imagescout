
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { TooltipProvider } from '@radix-ui/react-tooltip'
import App from './App.tsx'
import './index.css'

// Create a query client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})

// Add global error handlers for uncaught exceptions
const originalConsoleError = console.error;
console.error = (...args) => {
  // Call the original console.error
  originalConsoleError(...args);
  
  // Additional error handling logic can be added here
  // You could send errors to a monitoring service if needed
};

// Handle unhandled promise rejections
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled Promise Rejection:', event.reason);
});

// Handle uncaught errors
window.addEventListener('error', (event) => {
  console.error('Uncaught Error:', event.error);
});

createRoot(document.getElementById("root")!).render(
  <BrowserRouter>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <App />
      </TooltipProvider>
    </QueryClientProvider>
  </BrowserRouter>
);
