// Create or update this file to define the feedback types

export interface FeedbackFormData {
  imageId: string;
  modelId?: string;
  modelName?: string;
  score?: number;
  rating: number;
  accuracy?: 'too_high' | 'too_low' | 'about_right';
  comment?: string;
  projectId?: string;
  userId?: string;
  isAnonymous?: boolean;
  tags?: string[];
  // Adding missing fields referenced in the codebase
  notes?: string;
  labels?: string[];
  promotedToTraining?: boolean;
  test?: boolean;
  imageUrl?: string;
}

export interface FeedbackData extends FeedbackFormData {
  id: string;
  createdAt: string;
  updatedAt?: string;
}

export interface FeedbackDataPoint {
  date: string;
  count: number;
  averageRating?: number;
  // Adding missing fields referenced in ScoringAnalyticsDashboard
  avgScore?: number;
  promotedCount?: number;
  feedbackCount?: number;
}

export interface ScoreDistributionPoint {
  score: number;
  count: number;
  // Adding missing fields referenced in ScoringAnalyticsDashboard
  range?: string;
  min?: number;
  max?: number;
}

export interface LabelFrequency {
  label: string;
  count: number;
  percentage: number;
  // Adding missing field referenced in ScoringAnalyticsDashboard
  name?: string;
}

export interface FeedbackSummary {
  totalFeedback: number;
  averageRating: number;
  averageAccuracy?: number;
  topTags?: string[];
  recentFeedback?: FeedbackData[];
  // Adding missing fields referenced in ScoringAnalyticsDashboard
  averageScore?: number;
  scoreTrend?: number;
  promotedCount?: number;
  testCount?: number;
  totalLabels?: number;
  highestScoringModel?: string;
  uniqueModels?: number;
  uniqueProjects?: number;
}

export interface FeedbackAnalytics {
  timeSeriesData: FeedbackDataPoint[];
  scoreDistribution: ScoreDistributionPoint[];
  labelFrequency: LabelFrequency[];
  summary: FeedbackSummary;
  ratingBreakdown?: {
    positive: number;
    neutral: number;
    negative: number;
  };
  accuracyBreakdown?: {
    tooHigh: number;
    tooLow: number;
    aboutRight: number;
  };
  // Additional fields mentioned in the codebase
  feedbackByModel?: Record<string, number>;
  feedbackOverTime?: Array<{ date: string; count: number }>;
  modelPerformance?: Array<{
    modelId: string;
    modelName: string;
    averageRating: number;
    feedbackCount: number;
  }>;
  promotedToTraining?: number;
  topLabels?: Array<{ label: string; count: number }>;
  totalFeedback?: number; // Add totalFeedback field
}

// Mapping functions for Supabase data conversion
export function mapFeedbackFromSupabase(data: any): FeedbackData {
  return {
    id: data.id,
    imageId: data.image_id,
    modelId: data.model_id,
    modelName: data.model_name,
    score: data.score,
    rating: data.rating,
    accuracy: data.accuracy,
    comment: data.comment,
    projectId: data.project_id,
    userId: data.user_id,
    isAnonymous: data.is_anonymous,
    tags: data.tags,
    notes: data.notes,
    labels: data.labels,
    promotedToTraining: data.promoted_to_training,
    test: data.test,
    imageUrl: data.image_url,
    createdAt: data.created_at,
    updatedAt: data.updated_at
  };
}

export function mapFeedbackFormToSupabase(formData: FeedbackFormData): Record<string, any> {
  return {
    image_id: formData.imageId,
    model_id: formData.modelId,
    model_name: formData.modelName,
    score: formData.score,
    rating: formData.rating,
    accuracy: formData.accuracy,
    comment: formData.comment,
    project_id: formData.projectId,
    user_id: formData.userId,
    is_anonymous: formData.isAnonymous,
    tags: formData.tags,
    notes: formData.notes,
    labels: formData.labels,
    promoted_to_training: formData.promotedToTraining,
    test: formData.test,
    image_url: formData.imageUrl
  };
}

// Additional types needed for supabaseLogger
export interface ScoringFeedbackPayload {
  imageId: string;
  score: number;
  rating: number;
  modelId?: string;
  projectId?: string;
  userId?: string;
}

export interface ScoringFeedbackItem {
  id: string;
  imageId: string;
  score: number;
  rating: number;
  createdAt: string;
  modelId?: string;
  projectId?: string;
}

export interface ScoringExportItem {
  id: string;
  imageId: string;
  score: number;
  rating: number;
  notes?: string;
  labels?: string[];
  modelId?: string;
  modelName?: string;
  projectId?: string;
  createdAt: string;
  promotedToTraining?: boolean;
}

export interface UploadStats {
  totalUploads: number;
  successfulUploads: number;
  failedUploads: number;
  averageSize: number;
}

export interface GenerationLogPayload {
  imageId: string;
  prompt: string;
  model: string;
  success: boolean;
  projectId?: string;
  userId?: string;
  error?: string;
  duration?: number;
}

export interface UploadLogPayload {
  fileName: string;
  fileSize: number;
  success: boolean;
  fileType?: string;
  projectId?: string;
  userId?: string;
  error?: string;
}
