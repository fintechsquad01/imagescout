
import { RenderNetResponse } from '@/types/content';

export interface ImageFile extends File {
  preview: string;
  id: string;
}

export interface BatchScoringResult {
  id: string;
  filename: string;
  model: string;
  score: number | null;
  status: 'success' | 'error' | 'pending';
  cached: boolean;
  error?: string;
  imageUrl?: string;
}

export interface BatchProcessConfig {
  modelId: string;
  prompt: string;
  skipCache?: boolean;
}

// ScoredImage interface - ensuring url is required
export interface ScoredImage {
  id: string;
  url: string; // Required
  src?: string;
  fileName?: string;
  name?: string;
  score?: number;
  opportunityScore?: number;
  visionData?: any;
  file?: File;
  width?: number;
  height?: number;
  uploadDate?: string;
  projectId?: string;
  hasFeedback?: boolean;
  test?: boolean;
  thumbnailUrl?: string;
  size: number; // Required
  format?: string;
  lastModified?: number;
}

// ModelComparisonResult interface
export interface ModelComparisonResult {
  modelId: string;
  modelName: string;
  score: number;
  visionData: any;
  weights?: Record<string, number>;
  version?: string;
  executionTime?: number;
  cached?: boolean;
  modelVersion?: string;
}

// ModelComparisonResultWithCache interface
export interface ModelComparisonResultWithCache extends ModelComparisonResult {
  cached: boolean;
  weights: Record<string, number>;
  version: string;
  cacheStatus?: {
    fromCache: boolean;
    cacheDate: string;
    cacheKey: string;
    expiresAt: string;
  };
}

// ScoringOptions interface
export interface ScoringOptions {
  projectId?: string;
  forceMock?: boolean;
  compareModels?: boolean;
  modelsToCompare?: any[];
  scoringConfig?: any;
  test?: boolean;
  skipCache?: boolean;
  debugInfo?: boolean;
  userId?: string;
  logTelemetry?: boolean; // For telemetry logging
  imageId?: string; // For identifying images in logs
}

// ScoreCacheEntry interface
export interface ScoreCacheEntry {
  id: string;
  imageHash: string;
  modelId: string;
  score: number;
  createdAt: string;
  data?: any;
}

// CachedStatus enum
export enum CachedStatus {
  HIT = 'hit',
  MISS = 'miss',
  ERROR = 'error'
}

// ScoreCacheLog interface
export interface ScoreCacheLog {
  id: string;
  imageHash: string;
  modelId: string;
  status: CachedStatus;
  score?: number;
  createdAt: string;
  image_id?: string;
  scoring_config_id?: string;
  created_at?: string;
  expires_at?: string;
  is_expired?: boolean;
}

// ScoringErrorEntry interface
export interface ScoringErrorEntry {
  id: string;
  errorMessage: string;
  imageId: string;
  modelId: string;
  context?: any;
  createdAt: string;
  error_message?: string;
  image_id?: string;
  model_name?: string;
  scoring_config_id?: string;
  created_at?: string;
  retry_count?: number;
  stack_trace?: string;
}

// ScoringLogFilters interface using Date objects
export interface ScoringLogFilters {
  startDate?: Date; // Using Date object for consistency
  endDate?: Date; // Using Date object for consistency
  modelId?: string;
  status?: string;
  minScore?: number;
  maxScore?: number;
  projectId?: string;
  showExpired?: boolean;
  modelName?: string;
}

// Export the utility functions from scoringUtils
export {
  mapResponseToScoringResult,
  transformToComparisonResultWithCache,
  transformToComparisonResultsWithCache
} from '@/utils/scoringUtils';
