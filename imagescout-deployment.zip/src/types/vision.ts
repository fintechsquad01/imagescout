
// Vision API related types
export interface VisionApiData {
  labels?: string[];
  objects?: any[];
  landmarks?: any[];
  colors?: any[];
  faces?: any[];
  text?: string;
  logos?: any[];
  webEntities?: any[];
  safeSearch?: any;
  properties?: any;
  cropHints?: any[];
  fullTextAnnotation?: any;
  error?: any;
  metadata?: any;
}

// Vision API options
export interface VisionApiOptions {
  projectId?: string;
  forceMock?: boolean;
  debugInfo?: boolean;
  scoringConfig?: any;
  test?: boolean;
}
