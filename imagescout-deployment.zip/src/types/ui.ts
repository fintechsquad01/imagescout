
export enum PlanType {
  FREE = 'free',
  PRO = 'pro',
  TEAM = 'team',
  ENTERPRISE = 'enterprise'
}

export function getSafePlanType(plan: string | null | undefined): PlanType {
  if (!plan) return PlanType.FREE;
  
  const normalizedPlan = plan.toLowerCase();
  
  switch (normalizedPlan) {
    case 'pro':
      return PlanType.PRO;
    case 'team':
      return PlanType.TEAM;
    case 'enterprise':
      return PlanType.ENTERPRISE;
    default:
      return PlanType.FREE;
  }
}

export function getPlanDisplayName(plan: PlanType | string): string {
  switch (plan) {
    case PlanType.FREE:
    case 'free':
      return 'Free';
    case PlanType.PRO:
    case 'pro':
      return 'Pro';
    case PlanType.TEAM:
    case 'team':
      return 'Team';
    case PlanType.ENTERPRISE:
    case 'enterprise':
      return 'Enterprise';
    default:
      return 'Unknown Plan';
  }
}
