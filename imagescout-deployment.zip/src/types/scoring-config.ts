
import { z } from 'zod';

// Zod schema for scoring weights
export const weightSchema = z.object({
  labels: z.number().min(0).max(100).default(5),
  objects: z.number().min(0).max(100).default(7),
  landmarks: z.number().min(0).max(100).default(10),
  colors: z.number().min(0).max(100).default(5),
  baseScore: z.number().min(0).max(100).default(50),
  maxScore: z.number().min(0).max(100).default(100)
});

export type ScoringWeights = z.infer<typeof weightSchema>;

// Schema for complete scoring configuration
export const scoringConfigSchema = z.object({
  id: z.string().uuid(),
  version: z.string(),
  model: z.string(),
  weights: weightSchema,
  prompt_template: z.string().optional(),
  is_active: z.boolean(),
  created_at: z.string().datetime(),
  updated_at: z.string().datetime()
});

export type ScoringConfig = z.infer<typeof scoringConfigSchema>;

// Default fallback configuration
export const DEFAULT_SCORING_CONFIG: ScoringConfig = {
  id: '00000000-0000-0000-0000-000000000000',
  version: '1.0.0',
  model: 'default',
  weights: {
    labels: 5,
    objects: 7,
    landmarks: 10,
    colors: 5,
    baseScore: 50,
    maxScore: 100
  },
  prompt_template: "Analyze the image for {{objects}} and {{labels}}.",
  is_active: true,
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString()
};
