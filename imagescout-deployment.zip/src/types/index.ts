
// Re-export all types from domain-specific files
export * from './project';
export * from './vision';
export * from './scoring';
export * from './content';
export * from './feedback';
export * from './ui';

// Legacy compatibility - these will be deprecated in future versions
// Import and re-export explicitly to avoid TS2308 ambiguity errors
import { Project, RoleType, GenerationLogPayload, UploadLogPayload, UploadStats } from './project';
import { ScoredImage, ModelComparisonResult, ModelComparisonResultWithCache, ImageFile } from './scoring';
import { PromptHistoryItem, AIModel, RenderNetResponse } from './content';
import { FeedbackFormData, FeedbackData, FeedbackAnalytics } from './feedback';

// Legacy re-exports with explicit naming
export type { 
  Project, 
  RoleType,
  GenerationLogPayload,
  UploadLogPayload, 
  UploadStats,
  ScoredImage,
  ImageFile,
  ModelComparisonResult,
  ModelComparisonResultWithCache,
  PromptHistoryItem,
  AIModel,
  RenderNetResponse,
  FeedbackFormData,
  FeedbackData,
  FeedbackAnalytics
};

// Additional legacy exports from types.ts
export * from './types';
