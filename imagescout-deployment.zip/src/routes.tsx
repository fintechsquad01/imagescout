
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Index from './pages/Index';
import NotFound from './pages/NotFound';
import ComingSoon from './pages/ComingSoon';
import BillingPage from './pages/BillingPage';
import TestScoringPage from './pages/TestScoringPage';
import FeedbackReviewPage from './pages/admin/FeedbackReviewPage';
import ScoringAnalyticsPage from './pages/admin/ScoringAnalyticsPage';
import ScoringLogsPage from './pages/admin/ScoringLogsPage';
import BatchScoringPage from './pages/BatchScoringPage';

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/billing" element={<BillingPage />} />
      <Route path="/test-scoring" element={<TestScoringPage />} />
      <Route path="/batch-scoring" element={<BatchScoringPage />} />
      <Route path="/widgets" element={<ComingSoon />} />
      <Route path="/admin/feedback" element={<FeedbackReviewPage />} />
      <Route path="/admin/scoring-analytics" element={<ScoringAnalyticsPage />} />
      <Route path="/admin/scoring-logs" element={<ScoringLogsPage />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default AppRoutes;
