
import React, { useState, useEffect } from 'react';
import { Progress } from "@/components/ui/progress";
import { Loader2, Wand2, CheckCircle, Clock, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from 'framer-motion';

interface GenerationLoadingProps {
  isRetrying: boolean;
  className?: string;
}

const GenerationLoading: React.FC<GenerationLoadingProps> = ({ 
  isRetrying, 
  className 
}) => {
  const [progress, setProgress] = useState(0);
  const [currentTask, setCurrentTask] = useState<string>("Initializing");
  const [completedTasks, setCompletedTasks] = useState<string[]>([]);
  const [elapsedTime, setElapsedTime] = useState(0);

  useEffect(() => {
    const tasks = [
      "Processing prompt",
      "Initializing model",
      "Generating image",
      "Refining details",
      "Applying style",
      "Finalizing result"
    ];
    
    let taskIndex = 0;
    const taskInterval = setInterval(() => {
      if (taskIndex < tasks.length) {
        setCurrentTask(tasks[taskIndex]);
        if (taskIndex > 0) {
          setCompletedTasks(prev => [...prev, tasks[taskIndex - 1]]);
        }
        taskIndex++;
      } else {
        clearInterval(taskInterval);
      }
    }, 1500);
    
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 95) {
          clearInterval(progressInterval);
          return 95;
        }
        
        // Make progress more natural with variable increments
        const increment = Math.max(1, Math.floor(10 * Math.random()));
        return Math.min(95, prev + increment);
      });
    }, 400);
    
    // Track elapsed time
    const timeInterval = setInterval(() => {
      setElapsedTime(prev => prev + 1);
    }, 1000);
    
    return () => {
      clearInterval(progressInterval);
      clearInterval(taskInterval);
      clearInterval(timeInterval);
      setProgress(0);
      setCurrentTask("Initializing");
      setCompletedTasks([]);
      setElapsedTime(0);
    };
  }, []);

  // Animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };
  
  const item = {
    hidden: { opacity: 0, y: 10 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      className={cn(
        "mt-4 rounded-xl overflow-hidden aspect-video bg-muted/40 flex flex-col items-center justify-center p-6 border border-white/10 shadow-md",
        className
      )}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <motion.div 
        variants={container}
        initial="hidden"
        animate="show"
        className="w-full max-w-md"
      >
        <motion.div variants={item} className="flex justify-between text-sm font-medium mb-2">
          <span>{isRetrying ? "Retrying with simplified settings..." : "Creating your image..."}</span>
          <span>{Math.round(progress)}%</span>
        </motion.div>
        <motion.div 
          variants={item}
          className="relative mb-6"
        >
          <Progress value={progress} className="h-2" />
          <motion.div 
            className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/30 to-transparent"
            animate={{ 
              x: ['-100%', '100%'],
            }}
            transition={{ 
              repeat: Infinity, 
              duration: 1.5,
              ease: "linear",
            }}
            style={{ height: '8px', opacity: 0.6 }}
          />
        </motion.div>
      </motion.div>
      
      <motion.div variants={container} initial="hidden" animate="show" className="w-full max-w-md space-y-3 my-4">
        <AnimatePresence mode="popLayout">
          {completedTasks.slice(-2).map((task, index) => (
            <motion.div 
              key={`completed-${index}`}
              className="flex gap-3 items-center"
              initial={{ opacity: 0, x: -10, height: 0 }}
              animate={{ opacity: 1, x: 0, height: 'auto' }}
              exit={{ opacity: 0, x: 10, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              <CheckCircle className="h-5 w-5 text-green-500" />
              <span className="text-sm text-muted-foreground">{task}</span>
            </motion.div>
          ))}
          
          <motion.div 
            className="flex gap-3 items-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            key={currentTask}
          >
            <div className="h-5 w-5 relative">
              <Loader2 className="h-5 w-5 text-primary animate-spin absolute" />
            </div>
            <span className="text-sm font-medium">{currentTask}</span>
          </motion.div>
          
          {progress < 80 && (
            <div className="flex gap-3 items-center text-muted-foreground/50">
              <Skeleton className="h-5 w-5 rounded-full bg-muted/60" />
              <Skeleton className="h-2.5 w-36 bg-muted/60" />
            </div>
          )}
        </AnimatePresence>
      </motion.div>
      
      <motion.div
        className="relative mt-4"
        animate={{ 
          rotate: [0, 5, 0, -5, 0],
        }}
        transition={{ 
          repeat: Infinity, 
          duration: 5, 
          ease: "easeInOut" 
        }}
      >
        <motion.div
          animate={{
            scale: [1, 1.1, 1],
            filter: ['drop-shadow(0 0 0px hsl(var(--primary)))', 'drop-shadow(0 0 8px hsl(var(--primary)))', 'drop-shadow(0 0 0px hsl(var(--primary)))']
          }}
          transition={{
            repeat: Infinity,
            duration: 2,
            ease: "easeInOut"
          }}
        >
          <Wand2 className="h-10 w-10 text-primary" />
        </motion.div>
        <motion.div
          className="absolute -inset-1 rounded-full"
          animate={{
            background: ['rgba(var(--primary), 0)', 'rgba(var(--primary), 0.1)', 'rgba(var(--primary), 0)'],
            scale: [0.8, 1.2, 0.8],
          }}
          transition={{
            repeat: Infinity,
            duration: 2,
            ease: "easeInOut"
          }}
        />
      </motion.div>
      
      <div className="text-sm text-foreground mb-2 font-medium mt-4">
        {currentTask}
      </div>
      
      <div className="text-xs text-muted-foreground max-w-md text-center">
        <div className="flex justify-center items-center gap-2 mb-2">
          <Clock className="h-3.5 w-3.5" />
          <span>Elapsed: {elapsedTime}s</span>
          {isRetrying && (
            <>
              <span className="mx-1 text-muted-foreground/50">•</span>
              <Sparkles className="h-3.5 w-3.5 text-amber-500" />
              <span className="text-amber-500">Using fallback settings</span>
            </>
          )}
        </div>
        <p>
          {isRetrying 
            ? "Retrying with simplified settings for better compatibility" 
            : "This could take 10-30 seconds depending on the complexity of your prompt and the selected model"}
        </p>
      </div>
    </motion.div>
  );
};

export default GenerationLoading;
export { GenerationLoading }; // Add named export alongside default export
