
import React from 'react';
import { cn } from "@/lib/utils";
import { Info } from "lucide-react";
import { contentIntents } from '@/data/contentIntents';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from "@/components/ui/tooltip";

interface ContentIntentSelectorProps {
  selectedIntentId: string;
  onIntentChange: (value: string) => void;
  className?: string;
}

const ContentIntentSelector: React.FC<ContentIntentSelectorProps> = ({
  selectedIntentId,
  onIntentChange,
  className
}) => {
  // Find the selected intent object for display
  const selectedIntent = contentIntents.find(intent => intent.id === selectedIntentId) || contentIntents[0];
  
  return (
    <div className={cn("space-y-2", className)}>
      <label className="text-sm font-medium block mb-2 text-foreground/90 flex items-center gap-2">
        Content Intent
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
            </TooltipTrigger>
            <TooltipContent className="max-w-[220px] text-xs">
              Choose the intent of your content to help generate more relevant results
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </label>
      <Select 
        value={selectedIntentId} 
        onValueChange={onIntentChange}
      >
        <SelectTrigger className="w-full bg-white/50 dark:bg-black/50 border border-white/20 dark:border-white/10 shadow-sm transition-colors hover:bg-white/70 dark:hover:bg-black/70 rounded-lg">
          <SelectValue placeholder="Select content intent">
            {selectedIntent && (
              <div className="flex items-center gap-2">
                <selectedIntent.icon className="h-4 w-4" />
                <span>{selectedIntent.label}</span>
              </div>
            )}
          </SelectValue>
        </SelectTrigger>
        <SelectContent className="rounded-lg border border-white/20 dark:border-white/10 shadow-md">
          {contentIntents.map((intent) => (
            <SelectItem key={intent.id} value={intent.id} className="cursor-pointer">
              <div className="flex flex-col py-1">
                <div className="flex items-center gap-2">
                  <intent.icon className="h-4 w-4" />
                  <span className="font-medium">{intent.label}</span>
                </div>
                <span className="text-xs text-muted-foreground mt-1">{intent.description}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default ContentIntentSelector;
