import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Star, Search } from "lucide-react";

export interface PromptHistoryItem {
  id: string;
  prompt: string;
  modelId: string;
  success: boolean;
  imageUrl?: string;
  favorite: boolean;
  createdAt: string;
}

interface PromptHistoryProps {
  items: PromptHistoryItem[];
  onSelect: (item: PromptHistoryItem) => void;
  onToggleFavorite?: (itemId: string) => void;
  onRerun?: (item: PromptHistoryItem) => void;
  currentModel?: string;
  selectedItem?: PromptHistoryItem | null;
  isGenerating?: boolean;
  filter?: (item: PromptHistoryItem) => boolean;
}

const PromptHistory: React.FC<PromptHistoryProps> = ({
  items,
  onSelect,
  onToggleFavorite,
  onRerun,
  currentModel,
  selectedItem,
  isGenerating,
  filter
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'favorites'>('all');
  const [filteredItems, setFilteredItems] = useState<PromptHistoryItem[]>([]);

  useEffect(() => {
    let filtered = items;

    if (searchTerm) {
      filtered = filtered.filter(item =>
        item.prompt.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedFilter === 'favorites') {
      filtered = filtered.filter(item => item.favorite);
    }

    setFilteredItems(filtered);
  }, [items, searchTerm, selectedFilter]);

  const handleFavoriteToggle = (item: PromptHistoryItem) => {
    if (onToggleFavorite) {
      onToggleFavorite(item.id);
    }
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleFilterChange = (filter: 'all' | 'favorites') => {
    setSelectedFilter(filter);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Button
          variant={selectedFilter === 'all' ? 'default' : 'outline'}
          onClick={() => handleFilterChange('all')}
          size="sm"
        >
          All Prompts
        </Button>
        <Button
          variant={selectedFilter === 'favorites' ? 'default' : 'outline'}
          onClick={() => handleFilterChange('favorites')}
          size="sm"
        >
          Favorites
        </Button>
      </div>
      <div className="relative">
        <Input
          type="text"
          placeholder="Search prompts..."
          value={searchTerm}
          onChange={handleSearchChange}
          className="pr-10"
        />
        <Search className="absolute h-4 w-4 top-3 right-3 text-gray-500" />
      </div>
      {selectedFilter === "all" && (
        <ScrollArea className="h-[200px] w-full rounded-md border">
          <div className="p-3">
            {items.map((item) => (
              <div key={item.id} className="border-b last:border-b-0">
                <Button
                  variant="ghost"
                  className="flex items-start space-x-2 w-full justify-between p-3 hover:bg-secondary/50 rounded-md"
                  onClick={() => onSelect(item)}
                  disabled={isGenerating}
                >
                  <div className="flex flex-col text-left">
                    <p className="text-sm font-medium truncate">{item.prompt}</p>
                    <p className="text-xs text-muted-foreground">
                      Model: {item.modelId}
                    </p>
                  </div>
                  <div className="flex justify-between items-center">
                    <Badge variant={item.success ? "success" : "destructive"}>
                      {item.success ? "Success" : "Failed"}
                    </Badge>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleFavoriteToggle(item)}
                        className={item.favorite ? "text-yellow-500" : "text-gray-400"}
                      >
                        {item.favorite ? (
                          <Star className="h-4 w-4 fill-yellow-500" />
                        ) : (
                          <Star className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </Button>
              </div>
            ))}
          </div>
        </ScrollArea>
      )}
      {selectedFilter === "favorites" && (
        <div>
          {filteredItems.length === 0 ? (
            <div className="text-center py-6 text-gray-500">
              <Star className="h-8 w-8 mx-auto mb-2" />
              <p>No favorite prompts yet.</p>
              <p className="text-sm">Click the star icon to favorite a prompt.</p>
            </div>
          ) : (
            filteredItems.map((item) => (
              <div key={item.id} className="border-b last:border-b-0 p-3">
                <div className="flex justify-between items-center">
                  <Badge variant={item.success ? "success" : "destructive"}>
                    {item.success ? "Success" : "Failed"}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleFavoriteToggle(item)}
                    className={item.favorite ? "text-yellow-500" : "text-gray-400"}
                  >
                    {item.favorite ? (
                      <Star className="h-4 w-4 fill-yellow-500" />
                    ) : (
                      <Star className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default PromptHistory;
