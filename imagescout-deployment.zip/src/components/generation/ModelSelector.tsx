
import React, { useState, useEffect } from 'react';
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScoredImage } from '@/types/scoring';
import { AIModel } from '@/types/content';
import { recommendModel } from '@/utils/mockData';
import { 
  CircleChevronDown, 
  CircleChevronUp, 
  Wand2, 
  Sparkles, 
  Layout, 
  Image as ImageIcon,
  Badge as BadgeIcon
} from "lucide-react";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";

interface ModelSelectorProps {
  selectedImage: ScoredImage;
  availableModels: AIModel[];
  selectedModelId: string;
  onModelSelect: (modelId: string) => void;
  className?: string;
  isCustomPrompt?: boolean;
}

const ModelSelector: React.FC<ModelSelectorProps> = ({
  selectedImage,
  availableModels,
  selectedModelId,
  onModelSelect,
  className,
  isCustomPrompt = false
}) => {
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);
  const [recommendedModel, setRecommendedModel] = useState<AIModel | null>(null);
  
  // Set recommended model when image changes
  useEffect(() => {
    const recommended = recommendModel(selectedImage.visionData);
    setRecommendedModel(recommended);
    if (!isCustomPrompt) {
      onModelSelect(recommended.id);
    }
  }, [selectedImage, isCustomPrompt, onModelSelect]);
  
  const getModelIcon = (iconName: string) => {
    switch (iconName) {
      case 'sparkles':
        return <Sparkles className="h-4 w-4" />;
      case 'layout':
        return <Layout className="h-4 w-4" />;
      case 'image':
        return <ImageIcon className="h-4 w-4" />;
      default:
        return <Wand2 className="h-4 w-4" />;
    }
  };
  
  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex justify-between items-center mb-1">
        <label className="text-sm font-medium text-foreground/90">Recommended Model</label>
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => setShowAdvancedOptions(!showAdvancedOptions)}
          className="h-6 px-2 text-xs flex items-center gap-1.5"
        >
          {showAdvancedOptions ? (
            <>
              <span>Hide options</span>
              <CircleChevronUp className="h-4 w-4" />
            </>
          ) : (
            <>
              <span>Show options</span>
              <CircleChevronDown className="h-4 w-4" />
            </>
          )}
        </Button>
      </div>
      
      {recommendedModel && (
        <HoverCard>
          <HoverCardTrigger asChild>
            <div className="bg-primary/5 border border-primary/20 rounded-xl p-4 mb-3 shadow-sm cursor-pointer relative transition-all duration-200 hover:border-primary/40 hover:bg-primary/10">
              <Badge variant="secondary" className="absolute -top-2 -right-2 bg-primary text-primary-foreground flex items-center gap-1.5 px-2 py-1">
                <BadgeIcon className="h-3 w-3" />
                <span>Recommended</span>
              </Badge>
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  {getModelIcon(recommendedModel.icon)}
                </div>
                <div>
                  <h4 className="font-medium">{recommendedModel.name}</h4>
                  <p className="text-xs text-muted-foreground mt-1">{recommendedModel.explanation}</p>
                </div>
              </div>
            </div>
          </HoverCardTrigger>
          <HoverCardContent className="w-80 text-sm p-4 rounded-xl">
            <div className="space-y-2">
              <h4 className="font-medium">{recommendedModel.name}</h4>
              <p className="text-sm text-muted-foreground">{recommendedModel.explanation}</p>
              <div className="mt-2 pt-2 border-t border-border">
                <h5 className="text-xs font-medium mb-1">Best for:</h5>
                <div className="flex flex-wrap gap-1.5">
                  {recommendedModel.suitableFor.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs bg-secondary/40">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </HoverCardContent>
        </HoverCard>
      )}
      
      {showAdvancedOptions && (
        <div className="mt-3 animate-fade-in">
          <label className="text-xs font-medium text-muted-foreground block mb-2">
            Manual Model Selection
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {availableModels.map((model) => (
              <HoverCard key={model.id}>
                <HoverCardTrigger asChild>
                  <button
                    className={cn(
                      "relative flex flex-col items-center justify-center p-3 rounded-xl border transition-all duration-200",
                      "text-sm text-center shadow-sm hover:border-primary/50",
                      selectedModelId === model.id
                        ? "bg-primary/10 border-primary"
                        : "bg-card border-white/20 dark:border-white/10"
                    )}
                    onClick={() => onModelSelect(model.id)}
                  >
                    {model.id === recommendedModel?.id && (
                      <Badge variant="secondary" className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs px-1.5 py-0.5">
                        <BadgeIcon className="h-3 w-3 mr-0.5" />
                        <span>Best match</span>
                      </Badge>
                    )}
                    <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center mb-2">
                      {getModelIcon(model.icon)}
                    </div>
                    <span className="font-medium">{model.name}</span>
                    <span className="text-xs text-muted-foreground mt-1">{model.description}</span>
                  </button>
                </HoverCardTrigger>
                <HoverCardContent className="w-64 text-sm p-3 rounded-xl">
                  <div className="space-y-2">
                    <h4 className="font-medium">{model.name}</h4>
                    <p className="text-xs text-muted-foreground">{model.explanation}</p>
                    <div className="mt-2 pt-2 border-t border-border">
                      <h5 className="text-xs font-medium mb-1">Suitable for:</h5>
                      <div className="flex flex-wrap gap-1.5">
                        {model.suitableFor.map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs bg-secondary/40">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </HoverCardContent>
              </HoverCard>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelSelector;
