import React from 'react';
import { cn } from "@/lib/utils";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, RefreshCw, Info } from "lucide-react";
import { toneOptions } from '@/data/toneOptions';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from "@/components/ui/tooltip";
import { PromptHistoryItem } from '@/types/content';
import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Wand2, Edit3, History } from 'lucide-react';
import { PromptHistoryComponent } from '@/components/generation/PromptHistory';
import { ScrollArea } from '@/components/ui/scroll-area';

interface PromptEditorProps {
  prompt: string;
  selectedTone: string;
  isCustomPrompt: boolean;
  onPromptChange: (value: string) => void;
  onToneChange: (value: string) => void;
  onResetPrompt: () => void;
  promptHistory?: PromptHistoryItem[];
  isHistoryLoading?: boolean;
  onFavoritePrompt?: (promptId: string, isFavorite: boolean) => Promise<boolean>;
  onAddTag?: (promptId: string, tag: string) => Promise<boolean>;
  className?: string;
}

const PromptEditor: React.FC<PromptEditorProps> = ({
  prompt,
  selectedTone,
  isCustomPrompt,
  onPromptChange,
  onToneChange,
  onResetPrompt,
  promptHistory = [],
  isHistoryLoading = false,
  onFavoritePrompt,
  onAddTag,
  className
}) => {
  // Find the selected tone object for display
  const selectedToneObject = toneOptions.find(tone => tone.id === selectedTone);
  
  return (
    <div className={cn("space-y-4", className)}>
      {/* Tone Selection */}
      <div>
        <label className="text-sm font-medium block mb-2 text-foreground/90 flex items-center gap-2">
          Writing Tone
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-[220px] text-xs">
                Choose a writing tone to influence the style and feel of the generated content
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </label>
        <Select 
          value={selectedTone} 
          onValueChange={onToneChange}
        >
          <SelectTrigger className="w-full bg-white/50 dark:bg-black/50 border border-white/20 dark:border-white/10 shadow-sm transition-colors hover:bg-white/70 dark:hover:bg-black/70 rounded-lg">
            <SelectValue placeholder="Select tone">
              {selectedToneObject && (
                <div className="flex items-center gap-2">
                  {selectedToneObject.emoji && <span className="text-base">{selectedToneObject.emoji}</span>}
                  <span>{selectedToneObject.name}</span>
                </div>
              )}
            </SelectValue>
          </SelectTrigger>
          <SelectContent className="rounded-lg border border-white/20 dark:border-white/10 shadow-md">
            {toneOptions.map((tone) => (
              <SelectItem key={tone.id} value={tone.id} className="cursor-pointer">
                <div className="flex flex-col py-1">
                  <div className="flex items-center gap-2">
                    {tone.emoji && <span className="text-base">{tone.emoji}</span>}
                    <span className="font-medium">{tone.name}</span>
                  </div>
                  <span className="text-xs text-muted-foreground mt-1">{tone.description}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {/* Prompt Input */}
      <div className="pt-1">
        <div className="flex justify-between items-center mb-2">
          <label htmlFor="prompt" className="text-sm font-medium flex items-center gap-2 text-foreground/90">
            Prompt
            {!isCustomPrompt && <Sparkles className="h-3.5 w-3.5 text-amber-500" />}
          </label>
          <div className="flex items-center gap-2">
            {promptHistory && promptHistory.length > 0 && (
              <PromptHistoryComponent
                items={promptHistory}
                isLoading={isHistoryLoading}
                onSelectPrompt={onPromptChange}
                onFavoritePrompt={onFavoritePrompt}
                onAddTag={onAddTag}
              />
            )}
            
            {isCustomPrompt && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={onResetPrompt}
                className="h-7 text-xs gap-1.5 hover:bg-secondary/80"
              >
                <RefreshCw className="h-3 w-3" />
                Reset
              </Button>
            )}
          </div>
        </div>
        <Textarea
          id="prompt"
          placeholder="Describe the content you want to generate..."
          value={prompt}
          onChange={(e) => onPromptChange(e.target.value)}
          className={cn(
            "resize-none min-h-[140px] bg-white/50 dark:bg-black/50 border shadow-sm transition-colors rounded-lg",
            "hover:bg-white/70 dark:hover:bg-black/70",
            prompt.length < 30 && prompt.length > 0 ? "border-amber-300" : "border-white/20 dark:border-white/10"
          )}
        />
        {prompt.length > 0 && prompt.length < 30 && (
          <p className="text-xs text-amber-500 mt-1 flex items-center gap-1.5">
            <Info className="h-3.5 w-3.5" />
            Adding more details to your prompt will improve results
          </p>
        )}
        <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1.5">
          {isCustomPrompt ? (
            <>Custom prompt</>
          ) : (
            <>
              <Sparkles className="h-3.5 w-3.5 text-amber-500" />
              AI-generated prompt based on image analysis and selected tone
            </>
          )}
        </p>
      </div>
    </div>
  );
};

export default PromptEditor;
