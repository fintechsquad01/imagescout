
import React, { useState } from 'react';
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { CheckCircle, Loader2, Copy, Sparkles, RefreshCw } from "lucide-react";
import { useCopyToClipboard } from '@/hooks/useCopyToClipboard';

interface FallbackPromptEditorProps {
  fallbackPrompt: string;
  onFallbackPromptChange: (prompt: string) => void;
  onRetry?: () => void;
  isRetrying?: boolean;
}

const FallbackPromptEditor: React.FC<FallbackPromptEditorProps> = ({
  fallbackPrompt,
  onFallbackPromptChange,
  onRetry,
  isRetrying = false
}) => {
  const [editFallbackPrompt, setEditFallbackPrompt] = useState(false);
  const { isCopying, copyToClipboard } = useCopyToClipboard();

  return (
    <div className="p-4 border border-border rounded-xl bg-background/70 backdrop-blur-sm shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <label className="text-sm font-medium">AI Simplified Prompt</label>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Edit</span>
          <Switch
            checked={editFallbackPrompt}
            onCheckedChange={setEditFallbackPrompt}
          />
        </div>
      </div>
      
      {editFallbackPrompt ? (
        <Textarea
          value={fallbackPrompt}
          onChange={(e) => onFallbackPromptChange(e.target.value)}
          className="resize-none min-h-[80px] bg-white/50 dark:bg-black/50 mb-3 animate-fade-in border border-white/20 dark:border-white/10 shadow-sm transition-colors rounded-lg"
        />
      ) : (
        <div className="p-3 bg-white/40 dark:bg-black/40 rounded-lg mb-3 border border-border text-sm animate-fade-in flex justify-between items-start">
          <div className="pr-2 flex-1">{fallbackPrompt}</div>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                className="ml-2 h-8 w-8 p-0 flex-shrink-0"
                onClick={() => copyToClipboard(fallbackPrompt)}
                disabled={isCopying || !fallbackPrompt.trim()}
              >
                {isCopying ? <Loader2 className="h-4 w-4 animate-spin" /> : <Copy className="h-4 w-4" />}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Copy prompt to clipboard</p>
            </TooltipContent>
          </Tooltip>
        </div>
      )}
      
      <div className="text-xs text-muted-foreground mb-1 flex items-start gap-2">
        <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
        <span>We've simplified your prompt and adjusted generation settings for better results</span>
      </div>

      {onRetry && (
        <Button 
          onClick={onRetry} 
          className="w-full mt-3" 
          disabled={isRetrying}
        >
          {isRetrying ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Retrying...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry with Simplified Settings
            </>
          )}
        </Button>
      )}
    </div>
  );
};

export default FallbackPromptEditor;
export { FallbackPromptEditor }; // Add named export alongside default export
