
import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Loader2, 
  Download, 
  RefreshCw, 
  AlertTriangle, 
  Star, 
  Image as ImageIcon,
  Code, 
  Check
} from 'lucide-react';
import FallbackPromptEditor from '@/components/generation/FallbackPromptEditor';
import GenerationLoading from '@/components/generation/GenerationLoading';
import { RenderNetResponse } from '@/types/content';

interface GenerationResultProps {
  isGenerating: boolean;
  isRetrying: boolean;
  generationResult: RenderNetResponse | null;
  fallbackPrompt: string;
  onFallbackPromptChange: (prompt: string) => void;
  onRetry: () => void;
  onDownload: () => void;
  onFavorite?: () => void;
  isFavorited?: boolean;
  className?: string;
}

export const GenerationResult: React.FC<GenerationResultProps> = ({
  isGenerating,
  isRetrying,
  generationResult,
  fallbackPrompt,
  onFallbackPromptChange,
  onRetry,
  onDownload,
  onFavorite,
  isFavorited = false,
  className
}) => {
  const [showPrompt, setShowPrompt] = useState(false);
  
  // If generating, show the loading state
  if (isGenerating || isRetrying) {
    return <GenerationLoading isRetrying={isRetrying} className={className} />;
  }
  
  // If no result, don't render anything
  if (!generationResult) {
    return null;
  }
  
  // Handle different result statuses
  const isError = generationResult.status === 'error';
  const isSuccess = generationResult.status === 'success';
  
  return (
    <Card className={cn(
      "w-full mt-6 overflow-hidden", 
      isError ? "border-red-300 dark:border-red-800" : "",
      className
    )}>
      <CardContent className="p-0">
        {/* Result Header */}
        <div className={cn(
          "px-4 py-3 flex items-center justify-between",
          isError ? "bg-red-50 dark:bg-red-950/20" : "bg-muted/50"
        )}>
          <div className="flex items-center">
            {isError ? (
              <>
                <AlertTriangle className="text-red-500 h-4 w-4 mr-2" />
                <span className="text-sm font-medium text-red-600 dark:text-red-400">
                  Generation Failed
                </span>
              </>
            ) : (
              <>
                <Check className="text-green-500 h-4 w-4 mr-2" />
                <span className="text-sm font-medium">
                  Generation Complete
                </span>
              </>
            )}
          </div>
          
          <div className="flex gap-1.5">
            {!isError && (
              <>
                {onFavorite && (
                  <Button 
                    variant="ghost" 
                    size="icon"
                    className={cn(
                      "h-8 w-8",
                      isFavorited && "text-amber-500"
                    )}
                    onClick={onFavorite}
                  >
                    <Star className="h-4 w-4" />
                  </Button>
                )}
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setShowPrompt(!showPrompt)}
                >
                  <Code className="h-4 w-4" />
                </Button>
              </>
            )}
          </div>
        </div>
        
        {/* Result Image for Success */}
        {isSuccess && generationResult.imageUrl && (
          <div className="relative flex flex-col items-center">
            <div className="w-full aspect-square sm:aspect-auto sm:h-[300px] bg-black/5 dark:bg-black/20 relative">
              <img 
                src={generationResult.imageUrl} 
                alt="Generated content"
                className="w-full h-full object-contain"
              />
            </div>
            
            {/* Image Actions */}
            <div className="absolute bottom-2 right-2 flex gap-2">
              <Button 
                onClick={onDownload}
                size="sm"
                variant="secondary"
                className="shadow-sm"
              >
                <Download className="h-4 w-4 mr-1.5" />
                Download
              </Button>
            </div>
          </div>
        )}
        
        {/* Error Message */}
        {isError && (
          <div className="p-4">
            <p className="text-sm text-red-600 dark:text-red-400 mb-2">
              {generationResult.error || "An unknown error occurred during generation."}
            </p>
            
            {/* Fallback Prompt Editor */}
            <FallbackPromptEditor
              fallbackPrompt={fallbackPrompt}
              onFallbackPromptChange={onFallbackPromptChange}
              onRetry={onRetry}
              isRetrying={isRetrying}
            />
          </div>
        )}
        
        {/* Prompt Display */}
        {showPrompt && (
          <div className="px-4 pb-4 pt-2">
            <ScrollArea className="h-[100px]">
              <div className="bg-muted rounded-md p-3">
                <p className="text-xs font-mono whitespace-pre-wrap">{generationResult.prompt}</p>
              </div>
            </ScrollArea>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default GenerationResult;
