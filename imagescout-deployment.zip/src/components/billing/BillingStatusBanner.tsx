
import React from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { BadgeDollarSign, Info, Beaker } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { isDevelopmentMode } from '@/utils/devMode';

interface BillingStatusBannerProps {
  enableStripeBilling: boolean;
}

const BillingStatusBanner: React.FC<BillingStatusBannerProps> = ({ 
  enableStripeBilling 
}) => {
  const isDevMode = isDevelopmentMode();
  
  // In dev mode, always show the banner for visibility testing
  if (isDevMode) {
    return (
      <Alert className="mb-4 border-amber-200 bg-amber-50/50 dark:bg-amber-900/20 relative">
        <Beaker className="h-4 w-4 text-amber-500" />
        <div className="flex justify-between w-full items-center">
          <div>
            <AlertTitle className="flex items-center">
              Development Mode
              <Badge className="ml-2 bg-amber-500 hover:bg-amber-600">Test Environment</Badge>
            </AlertTitle>
            <AlertDescription>
              The billing system is running in development mode. All features are enabled and payment flows are simulated.
            </AlertDescription>
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger>
                <Info className="h-4 w-4 text-amber-500 cursor-help ml-2" />
              </TooltipTrigger>
              <TooltipContent side="left">
                <p className="max-w-xs">
                  In development mode, all billing features are accessible and Stripe integration is simulated regardless of feature flags.
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </Alert>
    );
  }
  
  // In production, only show if Stripe is not enabled
  if (enableStripeBilling) return null;
  
  return (
    <Alert className="mb-4 border-amber-200 bg-amber-50/50 dark:bg-amber-900/20 relative">
      <BadgeDollarSign className="h-4 w-4 text-amber-500" />
      <div className="flex justify-between w-full items-center">
        <div>
          <AlertTitle className="flex items-center">
            Demo Mode
            <Badge className="ml-2 bg-amber-500 hover:bg-amber-600">Test Environment</Badge>
          </AlertTitle>
          <AlertDescription>
            The billing system is running in demo mode. No actual charges will be processed.
          </AlertDescription>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger>
              <Info className="h-4 w-4 text-amber-500 cursor-help ml-2" />
            </TooltipTrigger>
            <TooltipContent side="left">
              <p className="max-w-xs">
                In demo mode, all billing features are simulated. Enable the 'enable_stripe_billing' 
                feature flag to process real payments with Stripe.
              </p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </Alert>
  );
};

export default BillingStatusBanner;
