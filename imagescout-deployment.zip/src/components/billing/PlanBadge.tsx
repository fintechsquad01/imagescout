
import React from 'react';
import { Badge } from '@/components/ui/badge';
import { usePlanFeatures } from '@/hooks/usePlanFeatures';
import { getPlanDisplayName } from '@/types/ui';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Link } from 'react-router-dom';
import { CreditCard } from 'lucide-react';

interface PlanBadgeProps {
  className?: string;
  showIcon?: boolean;
}

const PlanBadge: React.FC<PlanBadgeProps> = ({ className, showIcon = true }) => {
  const { plan, isLoading } = usePlanFeatures();
  
  if (isLoading) {
    return null;
  }
  
  // Colors based on plan
  const getBadgeVariant = () => {
    switch (plan) {
      case 'enterprise':
        return 'default';
      case 'pro':
        return 'secondary';
      case 'free':
      default:
        return 'outline';
    }
  };
  
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Link to="/billing" className={className}>
            <Badge variant={getBadgeVariant()} className="cursor-pointer">
              {showIcon && <CreditCard className="mr-1 h-3 w-3" />}
              {getPlanDisplayName(plan)}
            </Badge>
          </Link>
        </TooltipTrigger>
        <TooltipContent>
          <p>{plan === 'free' ? 'Upgrade your plan' : 'Manage your subscription'}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default PlanBadge;
