
import React from 'react';
import { useBillingUI } from '@/hooks/useBillingUI';
import CurrentPlanDisplay from './CurrentPlanDisplay';
import BillingStatusBanner from './BillingStatusBanner';
import PlanList from './PlanList';

interface BillingSettingsProps {
  className?: string;
}

const BillingSettings: React.FC<BillingSettingsProps> = ({ className }) => {
  const {
    billingInterval,
    setBillingInterval,
    plan,
    planLoading,
    isRedirecting,
    isProcessing,
    inviteOnly,
    enableStripeBilling,
    handlePlanUpgrade,
    handleBillingManagement,
    plans
  } = useBillingUI();

  return (
    <div className={className}>
      <div className="space-y-4">
        <div>
          <h2 className="text-2xl font-bold">Subscription</h2>
          <p className="text-muted-foreground">
            Manage your subscription and billing information
          </p>
        </div>

        <BillingStatusBanner enableStripeBilling={enableStripeBilling} />

        <CurrentPlanDisplay
          plan={plan}
          isLoading={planLoading}
          enableStripeBilling={enableStripeBilling}
          onManageBilling={handleBillingManagement}
          isProcessing={isRedirecting || isProcessing}
        />

        <div className="mt-8">
          <PlanList
            plans={plans}
            currentPlan={plan}
            billingInterval={billingInterval}
            onIntervalChange={setBillingInterval}
            onUpgrade={handlePlanUpgrade}
            isDisabled={inviteOnly}
            isProcessing={isRedirecting || isProcessing}
            isTestMode={!enableStripeBilling}
          />
        </div>
      </div>
    </div>
  );
};

export default BillingSettings;
