
import React from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CreditCard, AlertTriangle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { getPlanDisplayName } from '@/types/types';
import BillingActionButton from './BillingActionButton';
import { PlanType } from '@/types/types';

interface CurrentPlanDisplayProps {
  plan: PlanType;
  isLoading: boolean;
  enableStripeBilling: boolean;
  onManageBilling: () => void;
  isProcessing: boolean;
}

const CurrentPlanDisplay: React.FC<CurrentPlanDisplayProps> = ({
  plan,
  isLoading,
  enableStripeBilling,
  onManageBilling,
  isProcessing
}) => {
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-8 w-1/3" />
          <Skeleton className="h-4 w-2/3" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-20 w-full" />
        </CardContent>
        <CardFooter>
          <Skeleton className="h-10 w-1/4" />
        </CardFooter>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Current Plan: {getPlanDisplayName(plan)}</span>
          <Badge 
            variant={plan === 'free' ? 'outline' : 'default'}
            className={enableStripeBilling ? '' : 'bg-amber-500 hover:bg-amber-600'}
          >
            {plan === 'free' ? 'Free' : (enableStripeBilling ? 'Active' : 'Demo')}
          </Badge>
        </CardTitle>
        <CardDescription>
          {plan === 'free' 
            ? 'You are currently on the free plan with basic features.' 
            : enableStripeBilling 
              ? `Your subscription renews on the 1st of each month.`
              : 'You are on a premium plan in demo mode.'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center">
            <CreditCard className="mr-2 h-5 w-5 text-muted-foreground" />
            <span className="text-sm">
              {plan === 'free' || !enableStripeBilling
                ? 'No payment method on file' 
                : 'Visa ending in 4242'}
            </span>
          </div>
          
          {plan !== 'free' && (
            <BillingActionButton 
              actionType="manage"
              onClick={onManageBilling}
              isProcessing={isProcessing}
              isTestMode={!enableStripeBilling}
              tooltipText={!enableStripeBilling 
                ? "Billing management is only available in production mode" 
                : undefined}
            >
              Manage Billing
            </BillingActionButton>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CurrentPlanDisplay;
