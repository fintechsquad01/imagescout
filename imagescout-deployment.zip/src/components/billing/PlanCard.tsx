
import React from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Check, Star, Info } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { BillingPlan } from '@/types/admin-dashboard';
import { cn } from '@/lib/utils';
import BillingActionButton from './BillingActionButton';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface PlanCardProps {
  plan: BillingPlan;
  isCurrent: boolean;
  billingInterval: 'month' | 'year';
  onUpgradeClick: (planId: string) => void;
  variant?: 'default' | 'secondary' | 'outline';
  disabled?: boolean;
  highlight?: boolean;
  isTestMode?: boolean;
}

const PlanCard: React.FC<PlanCardProps> = ({ 
  plan, 
  isCurrent, 
  billingInterval,
  onUpgradeClick,
  variant = 'default',
  disabled = false,
  highlight = false,
  isTestMode = false
}) => {
  return (
    <Card className={cn(
      "relative overflow-hidden transition-all duration-200",
      highlight && "border-primary/50 shadow-md",
      isTestMode && !isCurrent && "border-amber-200"
    )}>
      {plan.isPopular && (
        <div className="absolute right-0 top-0">
          <div className="bg-primary text-primary-foreground px-3 py-1 text-xs flex items-center">
            <Star className="mr-1 h-3 w-3" /> Popular
          </div>
        </div>
      )}
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          {plan.name}
          {isTestMode && !isCurrent && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center text-amber-500">
                    <Info className="h-4 w-4 cursor-help" />
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-xs">Demo mode active. No charges will be processed.</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </CardTitle>
        <CardDescription>{plan.description}</CardDescription>
        <div className="mt-1">
          <span className="text-2xl font-bold">${plan.price.toFixed(2)}</span>
          <span className="text-muted-foreground">/{billingInterval}</span>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <Separator />
        <ul className="space-y-2">
          {plan.features.map((feature, index) => (
            <li key={index} className="flex items-center">
              <Check className="mr-2 h-4 w-4 text-primary" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        <BillingActionButton 
          className="w-full" 
          variant={isCurrent ? 'outline' : (plan.id === 'pro' ? 'default' : 'secondary')}
          onClick={() => onUpgradeClick(plan.id)}
          disabled={disabled || isCurrent || plan.id === 'free'}
          isTestMode={isTestMode}
          actionType="upgrade"
          tooltipText={isCurrent 
            ? "You are currently on this plan" 
            : (plan.id === 'free' 
                ? "You can't downgrade to the free plan" 
                : isTestMode 
                  ? "Demo mode: No actual charges will be processed" 
                  : undefined)}
        >
          {isCurrent ? 'Current Plan' : `Upgrade to ${plan.name}`}
        </BillingActionButton>
      </CardFooter>
    </Card>
  );
};

export default PlanCard;
