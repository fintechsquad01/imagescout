
import React from 'react';
import { Button, ButtonProps } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface BillingActionButtonProps extends ButtonProps {
  isTestMode?: boolean;
  actionType: 'upgrade' | 'manage';
  isProcessing?: boolean;
  tooltipText?: string;
}

const BillingActionButton: React.FC<BillingActionButtonProps> = ({
  isTestMode = false,
  actionType,
  isProcessing = false,
  tooltipText,
  children,
  className,
  ...props
}) => {
  const button = (
    <Button
      variant={actionType === 'upgrade' ? 'default' : 'outline'}
      className={cn("relative", className)}
      disabled={isProcessing || (isTestMode && actionType === 'manage')}
      {...props}
    >
      {isProcessing ? 'Processing...' : children}
      {isTestMode && actionType === 'upgrade' && (
        <span className="absolute -top-1 -right-1 w-2 h-2 bg-amber-500 rounded-full animate-pulse" />
      )}
    </Button>
  );

  if (tooltipText && (isTestMode || props.disabled)) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            {button}
          </TooltipTrigger>
          <TooltipContent>
            <p className="max-w-xs">{tooltipText}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return button;
};

export default BillingActionButton;
