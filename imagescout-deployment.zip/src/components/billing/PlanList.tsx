
import React from 'react';
import PlanCard from './PlanCard';
import { Button } from '@/components/ui/button';
import { BillingPlan } from '@/types/admin-dashboard';

interface PlanListProps {
  plans: BillingPlan[];
  currentPlan: string;
  billingInterval: 'month' | 'year';
  onIntervalChange: (interval: 'month' | 'year') => void;
  onUpgrade: (planId: string) => void;
  isDisabled: boolean;
  isProcessing: boolean;
  isTestMode: boolean;
}

const PlanList: React.FC<PlanListProps> = ({
  plans,
  currentPlan,
  billingInterval,
  onIntervalChange,
  onUpgrade,
  isDisabled,
  isProcessing,
  isTestMode
}) => {
  return (
    <div>
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold">Available Plans</h3>
        <div className="flex items-center space-x-2 rounded-lg border p-1">
          <Button 
            variant={billingInterval === 'month' ? 'default' : 'ghost'} 
            size="sm"
            onClick={() => onIntervalChange('month')}
          >
            Monthly
          </Button>
          <Button 
            variant={billingInterval === 'year' ? 'default' : 'ghost'} 
            size="sm"
            onClick={() => onIntervalChange('year')}
          >
            Yearly (Save 15%)
          </Button>
        </div>
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-3">
        {plans.map((plan) => (
          <PlanCard
            key={plan.id}
            plan={plan}
            isCurrent={plan.id === currentPlan}
            billingInterval={billingInterval}
            onUpgradeClick={onUpgrade}
            disabled={isDisabled || isProcessing}
            highlight={plan.id === currentPlan}
            isTestMode={isTestMode}
          />
        ))}
      </div>

      <div className="mt-6 text-sm text-muted-foreground">
        {isTestMode ? (
          <p>Billing system is currently in demo mode. No actual charges will be processed.</p>
        ) : (
          <p>All plans include secure payment processing through Stripe. Your card details are never stored on our servers.</p>
        )}
      </div>
    </div>
  );
};

export default PlanList;
