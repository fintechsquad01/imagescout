
import React from 'react';
import { cn } from "@/lib/utils";
import { ScoredImage } from '@/types/scoring';
import { X, MessageSquare } from "lucide-react";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ImagePreviewProps {
  images: ScoredImage[];
  selectedImage: ScoredImage | null;
  onSelect: (image: ScoredImage) => void;
  onRemove: (imageId: string) => void;
  className?: string;
}

const ImagePreview: React.FC<ImagePreviewProps> = ({
  images,
  selectedImage,
  onSelect,
  onRemove,
  className
}) => {
  if (!images.length) return null;

  return (
    <div className={cn("w-full animate-slide-up", className)}>
      <h3 className="text-sm font-medium mb-3 text-muted-foreground">Uploaded Images</h3>
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hidden">
        {images.map((image) => (
          <div
            key={image.id}
            className={cn(
              "relative shrink-0 group cursor-pointer transition-all duration-200",
              "h-24 w-24 rounded-lg overflow-hidden",
              selectedImage?.id === image.id ? "ring-2 ring-primary" : "ring-1 ring-border"
            )}
            onClick={() => onSelect(image)}
          >
            <img
              src={image.url || image.src}
              alt={image.name || image.fileName || "Uploaded image"}
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200" />
            <button
              onClick={(e) => {
                e.stopPropagation();
                onRemove(image.id);
              }}
              className="absolute top-1 right-1 h-5 w-5 rounded-full bg-black/70 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X className="h-3 w-3" />
            </button>
            
            {/* Score indicator */}
            <div className="absolute bottom-1 right-1 bg-black/70 text-white text-xs font-medium rounded-full h-6 w-6 flex items-center justify-center">
              {image.opportunityScore || image.score || 0}
            </div>

            {/* Feedback indicator */}
            {image.hasFeedback && (
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <div className="absolute top-1 left-1 bg-green-500/90 text-white rounded-full h-5 w-5 flex items-center justify-center">
                      <MessageSquare className="h-3 w-3" />
                    </div>
                  </TooltipTrigger>
                  <TooltipContent side="bottom">
                    <p className="text-xs">Feedback submitted</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ImagePreview;
