
import React, { useState, useEffect } from 'react';
import { useProject, TEST_PROJECT_ID } from '@/context/ProjectContext';
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth';
import { getSupabaseClient } from '@/lib/supabaseLogger';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, ChevronDown, FolderPlus, Folder, LogIn, Beaker } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { isDevelopmentMode } from '@/utils/devMode';

interface ProjectSelectorProps {
  className?: string;
}

const ProjectSelector: React.FC<ProjectSelectorProps> = ({ className }) => {
  const { 
    projects = [], // Provide default empty array to prevent null reference
    currentProject, 
    isLoading, 
    createProject 
  } = useProject();
  
  // Safely access methods from the context
  const projectContext = useProject();
  const switchProject = projectContext?.switchProject;
  const createTestProject = projectContext?.createTestProject;
  
  const { isAuthenticated, isLoading: isAuthLoading } = useSupabaseAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [newProjectDescription, setNewProjectDescription] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [hasAttemptedTestProjectCreation, setHasAttemptedTestProjectCreation] = useState(false);

  // More aggressive auto-creation of test project in development mode
  useEffect(() => {
    const initializeDevProject = async () => {
      if (isDevelopmentMode() && !hasAttemptedTestProjectCreation && createTestProject) {
        console.log('[DEV] Auto-creating test project in development mode');
        setHasAttemptedTestProjectCreation(true);
        try {
          await createTestProject();
          console.log('[DEV] Test project successfully created or selected');
        } catch (error) {
          console.error('[DEV] Failed to auto-create test project:', error);
        }
      }
    };
    
    initializeDevProject();
  }, [createTestProject, hasAttemptedTestProjectCreation]);

  // Backup mechanism to ensure a project is always selected in dev mode
  useEffect(() => {
    if (isDevelopmentMode() && !isLoading && !currentProject) {
      const testProject = projects.find(p => p.id === TEST_PROJECT_ID || p.test === true);
      
      if (testProject && switchProject) {
        console.log('[DEV] Auto-selecting existing test project');
        switchProject(testProject.id);
      } else if (createTestProject && !hasAttemptedTestProjectCreation) {
        console.log('[DEV] No test project found, creating one');
        setHasAttemptedTestProjectCreation(true);
        createTestProject().catch(error => {
          console.error('[DEV] Failed to create test project in backup mechanism:', error);
        });
      }
    }
  }, [currentProject, isLoading, projects, switchProject, createTestProject, hasAttemptedTestProjectCreation]);

  useEffect(() => {
    if (!isAuthenticated && isDialogOpen) {
      setIsDialogOpen(false);
    }
  }, [isAuthenticated, isDialogOpen]);

  const handleCreateProject = async () => {
    if (!newProjectName.trim() || !createProject) return;
    
    setIsCreating(true);
    const success = await createProject(newProjectName, newProjectDescription);
    
    if (success) {
      setIsDialogOpen(false);
      setNewProjectName('');
      setNewProjectDescription('');
    }
    
    setIsCreating(false);
  };

  const handleNewProjectClick = () => {
    if (!isAuthenticated && !isDevelopmentMode()) {
      toast({
        title: "Authentication Required",
        description: "You need to log in to create a new project.",
        action: (
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleLoginClick}
            className="gap-1"
          >
            <LogIn className="h-3.5 w-3.5" />
            Log In
          </Button>
        ),
      });
      return;
    }
    
    setIsDialogOpen(true);
  };

  const handleCreateTestProject = async () => {
    if (!createTestProject) {
      toast({
        variant: "destructive",
        title: "Development Mode Required",
        description: "Test projects can only be created in development mode."
      });
      return;
    }

    try {
      await createTestProject();
    } catch (error) {
      console.error("Failed to create test project:", error);
      toast({
        variant: "destructive",
        title: "Test Project Creation Failed",
        description: error instanceof Error ? error.message : "Unknown error"
      });
    }
  };

  const handleLoginClick = async () => {
    const supabase = getSupabaseClient();
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.href,
      }
    });
  };

  const isTestProject = currentProject?.id === TEST_PROJECT_ID || currentProject?.test === true;
  const hasProjects = Array.isArray(projects) && projects.length > 0;

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="outline" 
            className={`flex items-center gap-2 bg-background/80 ${className}`}
          >
            {isLoading || isAuthLoading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Loading projects...</span>
              </>
            ) : (
              <>
                {isTestProject ? (
                  <Beaker className="h-4 w-4 text-yellow-500" />
                ) : (
                  <Folder className="h-4 w-4 text-primary" />
                )}
                <span className="max-w-[140px] truncate">
                  {currentProject?.name || 'Select Project'}
                </span>
                <ChevronDown className="h-4 w-4 opacity-50" />
              </>
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[220px]">
          <DropdownMenuLabel>Your Projects</DropdownMenuLabel>
          <DropdownMenuSeparator />
          
          {!isAuthenticated && !isDevelopmentMode() ? (
            <DropdownMenuItem disabled className="opacity-70">
              Log in to see your projects
            </DropdownMenuItem>
          ) : hasProjects ? (
            projects.map(project => (
              <DropdownMenuItem 
                key={project.id}
                className={`cursor-pointer ${project.id === currentProject?.id ? 'bg-secondary' : ''}`}
                onClick={() => switchProject && switchProject(project.id)}
              >
                <div className="flex items-center gap-2 w-full overflow-hidden">
                  {project.id === TEST_PROJECT_ID || project.test === true ? (
                    <Beaker className="h-4 w-4 flex-shrink-0 text-yellow-500" />
                  ) : (
                    <Folder className="h-4 w-4 flex-shrink-0" />
                  )}
                  <span className="truncate">{project.name}</span>
                </div>
              </DropdownMenuItem>
            ))
          ) : (
            <DropdownMenuItem disabled>No projects found</DropdownMenuItem>
          )}
          
          <DropdownMenuSeparator />
          <DropdownMenuItem 
            className="cursor-pointer text-primary focus:text-primary"
            onClick={handleNewProjectClick}
          >
            <FolderPlus className="h-4 w-4 mr-2" />
            New Project
          </DropdownMenuItem>
          
          {isDevelopmentMode() && createTestProject && (
            <DropdownMenuItem 
              className="cursor-pointer text-yellow-600 focus:text-yellow-600"
              onClick={handleCreateTestProject}
            >
              <Beaker className="h-4 w-4 mr-2" />
              Create Test Project
            </DropdownMenuItem>
          )}
          
          {!isAuthenticated && !isDevelopmentMode() && (
            <DropdownMenuItem 
              className="cursor-pointer mt-2"
              onClick={handleLoginClick}
            >
              <LogIn className="h-4 w-4 mr-2" />
              Log In
            </DropdownMenuItem>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Create New Project</DialogTitle>
            <DialogDescription>
              Create a new project to organize your content and images.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label htmlFor="name" className="text-sm font-medium">
                Name
              </label>
              <Input
                id="name"
                value={newProjectName}
                onChange={(e) => setNewProjectName(e.target.value)}
                placeholder="My Awesome Project"
                autoFocus
              />
            </div>
            
            <div className="grid gap-2">
              <label htmlFor="description" className="text-sm font-medium">
                Description (optional)
              </label>
              <Textarea
                id="description"
                value={newProjectDescription}
                onChange={(e) => setNewProjectDescription(e.target.value)}
                placeholder="What's this project about?"
                rows={3}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCreateProject}
              disabled={!newProjectName.trim() || isCreating}
            >
              {isCreating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : (
                'Create Project'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ProjectSelector;
