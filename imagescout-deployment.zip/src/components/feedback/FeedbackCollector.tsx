
import React, { useState } from 'react';
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ThumbsUp, ThumbsDown, MessageSquare, X } from "lucide-react";
import { useSupabaseLogger } from '@/hooks/useSupabaseLogger';
import { submitUserFeedback } from '@/utils/feedbackUtils';

interface FeedbackCollectorProps {
  generationId: string;
  imageId: string;
  className?: string;
  onFeedbackSubmitted?: () => void;
}

const FeedbackCollector: React.FC<FeedbackCollectorProps> = ({
  generationId,
  imageId,
  className,
  onFeedbackSubmitted
}) => {
  const [rating, setRating] = useState<'positive' | 'negative' | null>(null);
  const [showCommentField, setShowCommentField] = useState(false);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { isAuthenticated } = useSupabaseLogger();
  
  const handleRatingSelect = (selectedRating: 'positive' | 'negative') => {
    setRating(selectedRating);
    setShowCommentField(true);
  };
  
  const handleSubmit = async () => {
    if (!rating) return;
    
    setIsSubmitting(true);
    
    try {
      await submitUserFeedback({
        generation_id: generationId,
        image_id: imageId,
        rating,
        comment: comment.trim() || null
      });
      
      if (onFeedbackSubmitted) {
        onFeedbackSubmitted();
      }
    } catch (error) {
      console.error('Error submitting feedback:', error);
    } finally {
      setIsSubmitting(false);
      setRating(null);
      setShowCommentField(false);
      setComment('');
    }
  };
  
  const handleCancel = () => {
    setRating(null);
    setShowCommentField(false);
    setComment('');
    
    if (onFeedbackSubmitted) {
      onFeedbackSubmitted();
    }
  };
  
  if (!isAuthenticated) return null;
  
  return (
    <div className={cn(
      "p-4 rounded-lg border border-border/50 bg-card/30 space-y-3",
      className
    )}>
      {!showCommentField ? (
        <>
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-primary" />
              How was this generation?
            </p>
            <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={handleCancel}>
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </Button>
          </div>
          <div className="flex gap-2 pt-1">
            <Button
              variant="outline"
              size="sm"
              className={cn(
                "gap-2 flex-1",
                rating === 'positive' && "bg-green-500/10 border-green-500/30 text-green-600 dark:text-green-400"
              )}
              onClick={() => handleRatingSelect('positive')}
            >
              <ThumbsUp className="h-4 w-4" />
              Good result
            </Button>
            <Button
              variant="outline"
              size="sm"
              className={cn(
                "gap-2 flex-1",
                rating === 'negative' && "bg-red-500/10 border-red-500/30 text-red-600 dark:text-red-400"
              )}
              onClick={() => handleRatingSelect('negative')}
            >
              <ThumbsDown className="h-4 w-4" />
              Needs improvement
            </Button>
          </div>
        </>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-primary" />
              Additional feedback (optional)
            </p>
            <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={handleCancel}>
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </Button>
          </div>
          <Textarea
            placeholder="Tell us more about what you liked or how we can improve..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            className="resize-none h-20 text-sm bg-white/50 dark:bg-black/50 border"
          />
          <div className="flex justify-end gap-2 pt-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSubmit}
              disabled={isSubmitting}
            >
              Skip
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={handleSubmit}
              disabled={isSubmitting}
            >
              Submit Feedback
            </Button>
          </div>
        </>
      )}
    </div>
  );
};

export default FeedbackCollector;
