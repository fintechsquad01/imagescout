import React, { useState, useEffect } from 'react';
import { Star, SendIcon, Download, Beaker, Clock, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Switch } from '@/components/ui/switch';
import { ScoredImage } from '@/types/scoring';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useScoringFeedback } from '@/hooks/useScoringFeedback';
import { FeedbackFormData } from '@/types/feedback';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface ScoringFeedbackProps {
  image: ScoredImage;
  modelId?: string;
  modelName?: string;
  onFeedbackSubmitted?: () => void;
  isLoading?: boolean;
}

export const ScoringFeedback: React.FC<ScoringFeedbackProps> = ({
  image,
  modelId,
  modelName = 'default',
  onFeedbackSubmitted,
  isLoading = false
}) => {
  const [rating, setRating] = useState<number | null>(null);
  const [notes, setNotes] = useState('');
  const [labels, setLabels] = useState<string[]>([]);
  const [customLabel, setCustomLabel] = useState('');
  const [promotedToTraining, setPromotedToTraining] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);
  const [lastSavedTimestamp, setLastSavedTimestamp] = useState<string | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  
  const { 
    submitFeedback, 
    isLoading: isSubmitting, 
    deleteFeedback, 
    isDeleting,
    fetchImageFeedback
  } = useScoringFeedback();

  const DEFAULT_LABELS = [
    'accurate', 'inaccurate', 'too high', 'too low', 
    'technical', 'creative', 'educational', 'product', 'meme', 'portrait'
  ];

  useEffect(() => {
    if (image?.id) {
      loadExistingFeedback();
    }
  }, [image?.id]);

  const loadExistingFeedback = async () => {
    try {
      const feedback = await fetchImageFeedback(image.id);
      if (feedback) {
        setRating(feedback.rating || null);
        setNotes(feedback.notes || '');
        setLabels(feedback.labels || []);
        setPromotedToTraining(feedback.promotedToTraining || false);
        
        if (feedback.createdAt) {
          setLastSavedTimestamp(new Date(feedback.createdAt).toLocaleString());
        } else if (feedback.updatedAt) {
          setLastSavedTimestamp(new Date(feedback.updatedAt).toLocaleString());
        }
      }
    } catch (error) {
      console.error('Error loading existing feedback:', error);
    }
  };

  const toggleLabel = (label: string) => {
    if (labels.includes(label)) {
      setLabels(labels.filter(l => l !== label));
    } else {
      setLabels([...labels, label]);
    }
  };

  const addCustomLabel = () => {
    if (customLabel && !labels.includes(customLabel)) {
      setLabels([...labels, customLabel]);
      setCustomLabel('');
    }
  };

  const submitFeedbackData = async () => {
    if (!rating) {
      toast('Rating required: Please provide a rating before submitting');
      return;
    }

    if (!image.id) {
      toast('Missing image ID: Cannot submit feedback without image ID');
      return;
    }

    try {
      const feedbackData: FeedbackFormData = {
        imageId: image.id,
        score: image.opportunityScore || image.score || 0,
        rating,
        notes: notes.trim() || undefined,
        labels: labels.length > 0 ? labels : undefined,
        modelId: modelId || undefined,
        modelName: modelName || 'default',
        projectId: image.projectId || undefined,
        imageUrl: image.url || image.src || undefined,
        promotedToTraining: promotedToTraining,
        test: image.test || false
      };

      const success = await submitFeedback(feedbackData);

      if (success) {
        setSubmissionSuccess(true);
        setLastSavedTimestamp(new Date().toLocaleString());
        
        toast('Feedback saved! You can update it anytime.');
        
        // Mark the image as having feedback
        if (image && !image.hasFeedback) {
          image.hasFeedback = true;
        }
        
        // Reset form after 1.5 seconds to show success state
        setTimeout(() => {
          setSubmissionSuccess(false);
          
          if (onFeedbackSubmitted) {
            onFeedbackSubmitted();
          }
        }, 1500);
      }
    } catch (error) {
      console.error('Error submitting feedback:', error);
      toast('Submission failed: Failed to submit feedback. Please try again.');
    }
  };

  const handleDeleteFeedback = async () => {
    if (!image.id) return;

    try {
      const success = await deleteFeedback(image.id);
      if (success) {
        toast('Feedback deleted successfully');
        
        // Reset form fields
        setRating(null);
        setNotes('');
        setLabels([]);
        setPromotedToTraining(false);
        setLastSavedTimestamp(null);
        
        // Mark the image as not having feedback
        if (image) {
          image.hasFeedback = false;
        }
        
        if (onFeedbackSubmitted) {
          onFeedbackSubmitted();
        }
      }
    } catch (error) {
      console.error('Error deleting feedback:', error);
      toast('Failed to delete feedback. Please try again.');
    } finally {
      setShowDeleteDialog(false);
    }
  };

  if (isLoading) {
    return <ScoringFeedbackSkeleton />;
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center justify-between">
          <div className="flex items-center">
            <Star className="w-4 h-4 mr-2 text-yellow-500" />
            Scoring Feedback
          </div>
          {lastSavedTimestamp && (
            <div className="flex items-center text-xs text-muted-foreground">
              <Clock className="w-3 h-3 mr-1" />
              Last saved: {lastSavedTimestamp}
            </div>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {submissionSuccess ? (
          <div className="flex flex-col items-center justify-center py-6 space-y-4">
            <div className="rounded-full bg-green-100 dark:bg-green-900/20 p-3">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-6 w-6 text-green-600 dark:text-green-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M5 13l4 4L19 7"
                />
              </svg>
            </div>
            <p className="text-center font-medium">Feedback submitted successfully!</p>
            <p className="text-sm text-muted-foreground text-center">
              Thank you for helping us improve our scoring system.
            </p>
          </div>
        ) : (
          <>
            <div className="border rounded-lg p-4 bg-muted/30">
              <div className="text-sm font-medium mb-1">Opportunity Score</div>
              <div className="text-3xl font-bold">{image.opportunityScore || image.score || 0}</div>
              <div className="text-xs text-muted-foreground mt-1">
                Score calculated using {modelName} model
              </div>
            </div>
            
            <div className="space-y-1.5">
              <div className="text-sm font-medium">Your Rating</div>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((value) => (
                  <Button
                    key={value}
                    variant={rating === value ? 'default' : 'outline'}
                    size="sm"
                    className={cn(
                      "w-10 h-10",
                      rating === value && "bg-primary text-primary-foreground"
                    )}
                    onClick={() => setRating(value)}
                  >
                    {value}
                  </Button>
                ))}
              </div>
              {!rating && isSubmitting && (
                <p className="text-xs text-red-500 mt-1">Please select a rating</p>
              )}
            </div>

            <div className="space-y-1.5">
              <div className="text-sm font-medium">Add Labels</div>
              <div className="flex flex-wrap gap-2 mb-2">
                {DEFAULT_LABELS.map((label) => (
                  <Badge
                    key={label}
                    variant={labels.includes(label) ? 'default' : 'outline'}
                    className="cursor-pointer"
                    onClick={() => toggleLabel(label)}
                  >
                    {label}
                  </Badge>
                ))}
                {labels.filter(l => !DEFAULT_LABELS.includes(l)).map((label) => (
                  <Badge
                    key={label}
                    variant="default"
                    className="cursor-pointer"
                    onClick={() => toggleLabel(label)}
                  >
                    {label} <span className="ml-1 opacity-70">×</span>
                  </Badge>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={customLabel}
                  onChange={(e) => setCustomLabel(e.target.value)}
                  placeholder="Add custom label"
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addCustomLabel();
                    }
                  }}
                />
                <Button 
                  type="button" 
                  size="sm" 
                  variant="outline" 
                  onClick={addCustomLabel}
                  disabled={!customLabel}
                >
                  Add
                </Button>
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="text-sm font-medium">Additional Notes</div>
              <Textarea
                placeholder="Share your thoughts about this score..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={3}
              />
            </div>
            
            <div className="border-t pt-4 mt-2">
              <div className="flex items-center space-x-2">
                <Switch
                  id="promote-to-training"
                  checked={promotedToTraining}
                  onCheckedChange={setPromotedToTraining}
                />
                <label 
                  htmlFor="promote-to-training" 
                  className="text-sm font-medium flex items-center gap-1.5 cursor-pointer"
                >
                  <Beaker className="h-4 w-4 text-blue-500" />
                  Promote to training set
                </label>
              </div>
              <p className="text-xs text-muted-foreground mt-1 ml-7">
                Add this image to our training dataset to improve future scoring
              </p>
            </div>
          </>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        {!submissionSuccess && (
          <>
            {lastSavedTimestamp && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowDeleteDialog(true)}
                className="gap-1"
                disabled={isDeleting || isSubmitting}
              >
                <Trash2 className="h-4 w-4" />
                Delete
              </Button>
            )}
            <Button 
              onClick={submitFeedbackData} 
              disabled={!rating || isSubmitting || submissionSuccess}
              className={lastSavedTimestamp ? "" : "w-full"}
            >
              {isSubmitting ? (
                <>
                  <Skeleton className="h-4 w-4 mr-2 rounded-full animate-spin" />
                  Submitting...
                </>
              ) : lastSavedTimestamp ? (
                <>
                  Update Feedback
                  <SendIcon className="ml-2 h-4 w-4" />
                </>
              ) : (
                <>
                  Submit Feedback
                  <SendIcon className="ml-2 h-4 w-4" />
                </>
              )}
            </Button>
          </>
        )}
      </CardFooter>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Feedback</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this feedback? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteFeedback}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
};

// Skeleton loading state for the feedback component
const ScoringFeedbackSkeleton = () => {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-6 w-40" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="border rounded-lg p-4 bg-muted/30">
          <Skeleton className="h-4 w-32 mb-1" />
          <Skeleton className="h-8 w-16" />
          <Skeleton className="h-3 w-48 mt-1" />
        </div>
        
        <div className="space-y-2">
          <Skeleton className="h-4 w-24" />
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="w-10 h-10 rounded-md" />
            ))}
          </div>
        </div>
        
        <div className="space-y-2">
          <Skeleton className="h-4 w-24" />
          <div className="flex flex-wrap gap-2">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Skeleton key={i} className="w-16 h-6 rounded-full" />
            ))}
          </div>
        </div>
        
        <div className="space-y-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-24 w-full rounded-md" />
        </div>
        
        <div className="border-t pt-4 mt-2">
          <div className="flex items-center space-x-2">
            <Skeleton className="h-5 w-10 rounded-full" />
            <Skeleton className="h-4 w-40" />
          </div>
          <Skeleton className="h-3 w-64 mt-1 ml-7" />
        </div>
      </CardContent>
      <CardFooter>
        <Skeleton className="h-10 w-full rounded-md" />
      </CardFooter>
    </Card>
  );
};

export default ScoringFeedback;
