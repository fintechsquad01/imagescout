
import React, { useState } from 'react';
import { cn } from "@/lib/utils";
import { ContentSuggestion } from '@/types/types';
import { Instagram, Linkedin, Facebook, Twitter, ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

interface ContentSuggestionsProps {
  suggestions: ContentSuggestion[];
  onSelectSuggestion: (suggestion: ContentSuggestion) => void;
  className?: string;
}

const ContentSuggestions: React.FC<ContentSuggestionsProps> = ({
  suggestions,
  onSelectSuggestion,
  className
}) => {
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  
  // Platform icon mapping
  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return <Instagram className="h-3 w-3" />;
      case 'linkedin':
        return <Linkedin className="h-3 w-3" />;
      case 'facebook':
        return <Facebook className="h-3 w-3" />;
      case 'twitter':
        return <Twitter className="h-3 w-3" />;
      default:
        return null;
    }
  };
  
  return (
    <div className={cn("p-6 rounded-xl glass-card animate-scale-in", className)}>
      <h3 className="text-lg font-medium mb-4">Content Suggestions</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {suggestions.map((suggestion) => (
          <div
            key={suggestion.id}
            className={cn(
              "p-4 rounded-lg border border-border bg-card/50",
              "transition-all duration-300 ease-in-out cursor-pointer",
              hoveredId === suggestion.id ? "shadow-md -translate-y-1" : "shadow-sm"
            )}
            onMouseEnter={() => setHoveredId(suggestion.id)}
            onMouseLeave={() => setHoveredId(null)}
            onClick={() => onSelectSuggestion(suggestion)}
          >
            <h4 className="font-medium mb-2">{suggestion.title}</h4>
            <p className="text-sm text-muted-foreground mb-3">
              {suggestion.description}
            </p>
            
            <div className="flex justify-between items-center">
              <div className="flex gap-1.5">
                {suggestion.platforms.map((platform) => (
                  <Badge key={platform} variant="secondary" className="flex items-center gap-1 text-xs">
                    {getPlatformIcon(platform)}
                    {platform}
                  </Badge>
                ))}
              </div>
              
              <Button 
                size="sm" 
                variant="ghost" 
                className={cn(
                  "h-8 w-8 p-0",
                  hoveredId === suggestion.id ? "opacity-100" : "opacity-0"
                )}
              >
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ContentSuggestions;
