import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Sparkles, Download, Copy, RefreshCw, AlertTriangle } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { ScoredImage } from '@/types/scoring';
import { ContentSuggestion, AIModel, RenderNetResponse } from '@/types/content';
import { useRenderNet } from '@/hooks/useRenderNet';
import { usePromptHistory } from '@/hooks/usePromptHistory';
import { usePromptGenerator } from '@/hooks/usePromptGenerator';
import { useClipboard } from '@/hooks/useClipboard';
import PromptHistory from '@/components/generation/PromptHistory';
import GeneratedImage from '@/components/generation/GeneratedImage';
import GenerationError from '@/components/generation/GenerationError';
import PromptTemplates from '@/components/generation/PromptTemplates';
import { DEFAULT_MODEL } from '@/constants/aiModels';

interface GenerationPanelProps {
  selectedImage: ScoredImage | null;
  selectedSuggestion: ContentSuggestion | null;
  availableModels: AIModel[];
}

const GenerationPanel: React.FC<GenerationPanelProps> = ({
  selectedImage,
  selectedSuggestion,
  availableModels
}) => {
  const [currentPrompt, setCurrentPrompt] = useState<string>('');
  const [selectedModel, setSelectedModel] = useState<AIModel | null>(null);
  const [activeTab, setActiveTab] = useState<string>('prompt');
  const [selectedHistory, setSelectedHistory] = useState<any | null>(null);
  
  const imageId = selectedImage?.id || 'unknown';
  
  const { 
    isGenerating, 
    generationResult, 
    generateContent, 
    retryWithFallbackPrompt,
    downloadImage
  } = useRenderNet(imageId);
  
  const { 
    promptHistory, 
    savePromptToHistory, 
    toggleFavorite 
  } = usePromptHistory(imageId);
  
  const { generatePrompt } = usePromptGenerator();
  const { copyToClipboard } = useClipboard();
  
  // Set default model on initial load
  useEffect(() => {
    if (availableModels.length > 0 && !selectedModel) {
      const defaultModel = availableModels.find(model => model.id === DEFAULT_MODEL) || availableModels[0];
      setSelectedModel(defaultModel);
    }
  }, [availableModels, selectedModel]);
  
  // Update prompt when suggestion changes
  useEffect(() => {
    if (selectedSuggestion) {
      setCurrentPrompt(selectedSuggestion.prompt);
      setActiveTab('prompt');
    }
  }, [selectedSuggestion]);
  
  const handleGenerateContent = useCallback(async (prompt: string, modelId: string) => {
    if (!prompt.trim()) {
      toast({
        title: "Empty prompt",
        description: "Please enter a prompt before generating content.",
        variant: "destructive"
      });
      return;
    }
    
    if (!selectedImage) {
      toast({
        title: "No image selected",
        description: "Please select an image before generating content.",
        variant: "destructive"
      });
      return;
    }
    
    await generateContent(prompt, modelId);
    setActiveTab('result');
  }, [generateContent, selectedImage]);
  
  const handleRetry = useCallback(async () => {
    if (!selectedModel) return;
    
    await retryWithFallbackPrompt(selectedModel.id);
    setActiveTab('result');
  }, [retryWithFallbackPrompt, selectedModel]);
  
  const handleCopyPrompt = useCallback(() => {
    copyToClipboard(currentPrompt);
    toast({
      title: "Prompt copied",
      description: "The prompt has been copied to your clipboard."
    });
  }, [copyToClipboard, currentPrompt]);
  
  const handleDownloadImage = useCallback(() => {
    downloadImage();
  }, [downloadImage]);
  
  const handleGeneratePrompt = useCallback(async () => {
    if (!selectedImage || !selectedImage.visionData) {
      toast({
        title: "Missing image data",
        description: "Image metadata is required to generate a prompt.",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const generatedPrompt = await generatePrompt(selectedImage.visionData);
      setCurrentPrompt(generatedPrompt);
      
      toast({
        title: "Prompt generated",
        description: "A new prompt has been created based on the image content."
      });
    } catch (error) {
      console.error("Error generating prompt:", error);
      toast({
        variant: "destructive",
        title: "Prompt generation failed",
        description: "Could not generate a prompt from the image content."
      });
    }
  }, [generatePrompt, selectedImage]);
  
  return (
    <div className="space-y-4">
      <Card className="h-full">
        <CardHeader>
          <CardTitle>Content Generation</CardTitle>
          <CardDescription>
            Generate AI content based on your image
          </CardDescription>
        </CardHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="px-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="prompt">Prompt</TabsTrigger>
              <TabsTrigger value="result">Result</TabsTrigger>
            </TabsList>
          </div>
          
          <CardContent className="pt-6">
            <TabsContent value="prompt" className="space-y-4">
              <div className="space-y-2">
                <Select
                  value={selectedModel?.id || ''}
                  onValueChange={(value) => {
                    const model = availableModels.find(m => m.id === value);
                    setSelectedModel(model || null);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a model" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableModels.map((model) => (
                      <SelectItem key={model.id} value={model.id}>
                        {model.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {selectedModel && (
                  <p className="text-xs text-muted-foreground">
                    {selectedModel.description}
                  </p>
                )}
              </div>
              
              <div className="space-y-2">
                <Textarea
                  placeholder="Enter your prompt here..."
                  className="min-h-[200px] resize-none"
                  value={currentPrompt}
                  onChange={(e) => setCurrentPrompt(e.target.value)}
                  disabled={isGenerating}
                />
                
                <div className="flex justify-between">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleCopyPrompt}
                    disabled={!currentPrompt || isGenerating}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleGeneratePrompt}
                    disabled={!selectedImage || isGenerating}
                  >
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate Prompt
                  </Button>
                </div>
              </div>
              
              <PromptTemplates 
                onSelectTemplate={(template) => {
                  setCurrentPrompt(template.prompt);
                }}
                imageMetadata={selectedImage?.visionData}
              />
            </TabsContent>
            
            <TabsContent value="result" className="space-y-4">
              {isGenerating ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
                  <p className="text-center text-muted-foreground">
                    Generating content with {selectedModel?.name || 'AI'}...
                  </p>
                </div>
              ) : generationResult ? (
                generationResult.status === 'success' ? (
                  <div className="space-y-4">
                    <GeneratedImage 
                      imageUrl={generationResult.imageUrl} 
                      altText="Generated content"
                    />
                    
                    <div className="flex justify-end space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleDownloadImage}
                        disabled={!generationResult.imageUrl}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </div>
                ) : (
                  <GenerationError 
                    error={generationResult.error}
                    onRetry={handleRetry}
                  />
                )
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                  <AlertTriangle className="h-8 w-8 mb-4" />
                  <p>No content generated yet.</p>
                  <p className="text-sm">
                    Go to the Prompt tab to create and submit a prompt.
                  </p>
                </div>
              )}
            </TabsContent>
          </CardContent>
          
          <CardFooter className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => {
                setCurrentPrompt('');
                setSelectedHistory(null);
              }}
              disabled={isGenerating || !currentPrompt}
            >
              Clear
            </Button>
            
            <Button
              onClick={() => handleGenerateContent(
                currentPrompt, 
                selectedModel?.id || DEFAULT_MODEL
              )}
              disabled={isGenerating || !currentPrompt || !selectedImage}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generate
                </>
              )}
            </Button>
          </CardFooter>
        </Tabs>
      </Card>
      
      <PromptHistory
        items={promptHistory}
        onSelect={(item) => {
          setCurrentPrompt(item.prompt);
          setSelectedHistory(item);
        }}
        onToggleFavorite={(itemId) => {
          toggleFavorite(itemId);
        }}
        onRerun={(item) => {
          setCurrentPrompt(item.prompt);
          handleGenerateContent(item.prompt, selectedModel?.id || DEFAULT_MODEL);
        }}
        currentModel={selectedModel?.id || DEFAULT_MODEL}
        selectedItem={selectedHistory}
        isGenerating={isGenerating}
        filter={(item) => item.favorite}
      />
    </div>
  );
};

export default GenerationPanel;
