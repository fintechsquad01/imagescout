
import React from 'react';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import AdminSectionHeader from './AdminSectionHeader';
import InviteCodeStats from './invite/InviteCodeStats';
import InviteCodeTable from './invite/InviteCodeTable';
import InviteCodeChart from './invite/InviteCodeChart';
import { useInviteStats } from '@/hooks/useInviteStats';

const InviteCodeAnalytics = () => {
  const { 
    inviteStats, 
    inviteCodes, 
    isLoading, 
    isError, 
    pagination, 
    handlePageChange 
  } = useInviteStats();

  return (
    <div className="space-y-6">
      <AdminSectionHeader 
        title="Invite Code Analytics" 
        description="Track invite code usage and distribution"
      />
      
      {isError ? (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            There was an error loading the invite code data. Please try again.
          </AlertDescription>
        </Alert>
      ) : (
        <>
          <InviteCodeStats stats={inviteStats} isLoading={isLoading} />
          
          <div className="grid gap-6 lg:grid-cols-2">
            <InviteCodeChart inviteCodes={inviteCodes} isLoading={isLoading} />
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Recent Activity</h3>
              <p className="text-sm text-muted-foreground">
                Summary of recent invite code redemptions and signups
              </p>
              {/* Additional stats could go here in the future */}
            </div>
          </div>
          
          <InviteCodeTable 
            inviteCodes={inviteCodes} 
            isLoading={isLoading}
            pagination={pagination}
            onPageChange={handlePageChange} 
          />
        </>
      )}
    </div>
  );
};

export default InviteCodeAnalytics;
