
import React, { useState, useEffect } from 'react';
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getFeedbackByContentIntent, getTotalFeedbackCount } from '@/utils/feedbackUtils';
import { BarChart, PieChart } from "lucide-react";
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { Progress } from "@/components/ui/progress";

interface FeedbackAnalyticsProps {
  className?: string;
}

const FeedbackAnalytics: React.FC<FeedbackAnalyticsProps> = ({ className }) => {
  const [feedbackByIntent, setFeedbackByIntent] = useState<Record<string, { positive: number, negative: number }>>({});
  const [totalFeedback, setTotalFeedback] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const { isFeatureEnabled } = useFeatureFlags();
  
  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        setIsLoading(true);
        
        // Only fetch if user has access to advanced analytics
        if (!isFeatureEnabled('advanced_analytics')) {
          return;
        }
        
        // Add error handling for API calls
        try {
          const intentData = await getFeedbackByContentIntent();
          if (intentData && typeof intentData === 'object') {
            setFeedbackByIntent(intentData);
          }
          
          const total = await getTotalFeedbackCount();
          setTotalFeedback(total);
        } catch (apiError) {
          console.error('API error fetching feedback analytics:', apiError);
        }
      } catch (error) {
        console.error('Error fetching feedback analytics:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchAnalytics();
  }, [isFeatureEnabled]);
  
  // Calculate totals and percentages
  const totalPositive = Object.values(feedbackByIntent).reduce((sum, item) => sum + item.positive, 0);
  const totalNegative = Object.values(feedbackByIntent).reduce((sum, item) => sum + item.negative, 0);
  const satisfactionRate = totalPositive + totalNegative > 0 
    ? Math.round((totalPositive / (totalPositive + totalNegative)) * 100) 
    : 0;
  
  // Skip rendering if user doesn't have access or there's no data
  if (!isFeatureEnabled('advanced_analytics')) {
    return null;
  }
  
  return (
    <Card className={className}>
      <div className="p-6">
        <h3 className="text-lg font-medium mb-4">Feedback Analytics</h3>
        
        <Tabs defaultValue="summary">
          <TabsList className="mb-4">
            <TabsTrigger value="summary">Summary</TabsTrigger>
            <TabsTrigger value="by-intent">By Intent</TabsTrigger>
          </TabsList>
          
          <TabsContent value="summary" className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="p-4 border rounded-lg text-center">
                <div className="text-2xl font-bold">{totalFeedback}</div>
                <div className="text-sm text-muted-foreground">Total Feedback</div>
              </div>
              <div className="p-4 border rounded-lg text-center">
                <div className="text-2xl font-bold text-green-500">{totalPositive}</div>
                <div className="text-sm text-muted-foreground">Positive</div>
              </div>
              <div className="p-4 border rounded-lg text-center">
                <div className="text-2xl font-bold text-red-500">{totalNegative}</div>
                <div className="text-sm text-muted-foreground">Negative</div>
              </div>
            </div>
            
            <div className="mt-4">
              <div className="flex justify-between mb-1">
                <span className="text-sm">Satisfaction Rate</span>
                <span className="text-sm font-medium">{satisfactionRate}%</span>
              </div>
              <Progress value={satisfactionRate} className="h-2" />
            </div>
          </TabsContent>
          
          <TabsContent value="by-intent">
            {Object.entries(feedbackByIntent).length > 0 ? (
              <div className="space-y-4">
                {Object.entries(feedbackByIntent).map(([intent, counts]) => {
                  const total = counts.positive + counts.negative;
                  const positivePercent = total > 0 ? Math.round((counts.positive / total) * 100) : 0;
                  
                  return (
                    <div key={intent}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">{intent}</span>
                        <span className="text-sm text-muted-foreground">
                          {counts.positive}/{total} ({positivePercent}%)
                        </span>
                      </div>
                      <div className="h-2 w-full bg-secondary/50 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-green-500 rounded-full" 
                          style={{ width: `${positivePercent}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No feedback data available by content intent
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Card>
  );
};

export default FeedbackAnalytics;
