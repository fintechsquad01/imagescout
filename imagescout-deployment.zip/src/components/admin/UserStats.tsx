
import React from 'react';
import { useUserStats } from '@/hooks/useUserStats';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';
import RoleDistributionChart from './users/RoleDistributionChart';
import UserListTable from './users/UserListTable';

const UserStats = () => {
  const { 
    roleCounts, 
    recentUsers, 
    isLoading, 
    error,
    pagination,
    handlePageChange
  } = useUserStats();

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <div className="grid gap-6 md:grid-cols-2">
        <RoleDistributionChart data={roleCounts} isLoading={isLoading} />
        <UserListTable 
          users={recentUsers} 
          isLoading={isLoading} 
          pagination={pagination}
          onPageChange={handlePageChange}
        />
      </div>
    </div>
  );
};

export default UserStats;
