
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip } from "@/components/ui/chart";
import { PieChart, Pie, Cell } from 'recharts';
import { Skeleton } from "@/components/ui/skeleton";
import { UserRoleCounts } from '@/types/admin-dashboard';

interface RoleDistributionChartProps {
  data: UserRoleCounts[];
  isLoading: boolean;
}

const RoleDistributionChart: React.FC<RoleDistributionChartProps> = ({ data, isLoading }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>User Role Distribution</CardTitle>
        <CardDescription>Breakdown of users by assigned role</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Skeleton className="h-64 w-full" />
          </div>
        ) : (
          <div className="h-64">
            <ChartContainer 
              config={{
                admin: { color: '#FF6384' },
                internal: { color: '#36A2EB' },
                beta: { color: '#FFCE56' },
                user: { color: '#4BC0C0' }
              }}
            >
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                  nameKey="role"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <ChartTooltip />
              </PieChart>
            </ChartContainer>
          </div>
        )}
        <div className="mt-4">
          <dl className="grid grid-cols-2 gap-4 text-sm">
            {data.map((role) => (
              <div key={role.role} className="flex items-center justify-between">
                <dt className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-2"
                    style={{ backgroundColor: role.color }}
                  />
                  {role.role}:
                </dt>
                <dd className="font-medium">{role.count}</dd>
              </div>
            ))}
          </dl>
        </div>
      </CardContent>
    </Card>
  );
};

export default RoleDistributionChart;
