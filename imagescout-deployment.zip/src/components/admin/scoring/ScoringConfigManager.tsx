
import React, { useState } from 'react';
import { getSupabaseClient } from '@/lib/supabaseLogger';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Loader2, Copy, CheckCircle, AlertCircle, Code, RotateCw, ClipboardCopy, Eye } from 'lucide-react';
import { toast } from 'sonner';
import { ScoringConfig, scoringConfigSchema } from '@/types/scoring-config';
import AdminSectionHeader from '@/components/admin/AdminSectionHeader';
import { useScoringConfig } from '@/hooks/useScoringConfig';
import { useRoleCheck } from '@/hooks/useRoleCheck';
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth';
import UnauthorizedAccess from '@/components/admin/UnauthorizedAccess';
import { formatDistanceToNow } from 'date-fns';

const ScoringConfigManager: React.FC = () => {
  const { isAuthorized, isLoading: roleLoading } = useRoleCheck(['admin']);
  const { userId } = useSupabaseAuth();
  const { config: activeConfig, refetch: refetchActiveConfig } = useScoringConfig();
  const [showJsonDialog, setShowJsonDialog] = useState(false);
  const [selectedConfig, setSelectedConfig] = useState<ScoringConfig | null>(null);
  const [confirmActivateOpen, setConfirmActivateOpen] = useState(false);

  // Fetch all scoring configurations
  const { data: configs, isLoading, error, refetch } = useQuery({
    queryKey: ['scoringConfigs'],
    queryFn: async () => {
      const supabase = getSupabaseClient();
      const { data, error } = await supabase
        .from('scoring_configs')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as ScoringConfig[];
    },
    enabled: isAuthorized
  });

  if (roleLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Checking permissions...</span>
      </div>
    );
  }

  if (!isAuthorized) {
    return <UnauthorizedAccess />;
  }

  const handleCopyJson = (json: string) => {
    navigator.clipboard.writeText(json);
    toast.success('Configuration copied to clipboard');
  };

  const handleCloneConfig = async (config: ScoringConfig) => {
    try {
      const newVersion = incrementVersion(config.version);
      
      const newConfig = {
        ...config,
        id: undefined, // Let Supabase generate a new ID
        version: newVersion,
        is_active: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        created_by: userId
      };
      
      const supabase = getSupabaseClient();
      const { data, error } = await supabase
        .from('scoring_configs')
        .insert([newConfig])
        .select()
        .single();
      
      if (error) throw error;
      
      toast.success(`Cloned configuration as version ${newVersion}`);
      refetch();
    } catch (error) {
      console.error('Error cloning config:', error);
      toast.error('Failed to clone configuration');
    }
  };

  const handleActivateConfig = async (config: ScoringConfig) => {
    try {
      const supabase = getSupabaseClient();
      
      // First deactivate all configs
      const { error: deactivateError } = await supabase
        .from('scoring_configs')
        .update({ is_active: false })
        .eq('is_active', true);
      
      if (deactivateError) throw deactivateError;
      
      // Then activate the selected one
      const { error: activateError } = await supabase
        .from('scoring_configs')
        .update({ is_active: true })
        .eq('id', config.id);
      
      if (activateError) throw activateError;
      
      toast.success(`Activated configuration ${config.version}`);
      refetch();
      refetchActiveConfig();
      setConfirmActivateOpen(false);
    } catch (error) {
      console.error('Error activating config:', error);
      toast.error('Failed to activate configuration');
    }
  };

  const incrementVersion = (version: string): string => {
    const parts = version.split('.');
    if (parts.length !== 3) return `${version}-1`;
    
    const major = parseInt(parts[0]);
    const minor = parseInt(parts[1]);
    const patch = parseInt(parts[2]) + 1;
    
    return `${major}.${minor}.${patch}`;
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <AdminSectionHeader 
          title="Scoring Configuration Manager" 
          description="Manage and activate scoring configurations for image analysis"
        />
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <span className="ml-2">Loading configurations...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-4">
        <AdminSectionHeader 
          title="Scoring Configuration Manager" 
          description="Manage and activate scoring configurations for image analysis"
        />
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2 text-destructive">
              <AlertCircle className="h-5 w-5" />
              <span>Error loading configurations. Please try again.</span>
            </div>
            <Button onClick={() => refetch()} className="mt-4" variant="outline">
              <RotateCw className="mr-2 h-4 w-4" />
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <AdminSectionHeader 
        title="Scoring Configuration Manager" 
        description="Manage and activate scoring configurations for image analysis"
      />
      
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Active Configuration</h3>
          <p className="text-sm text-muted-foreground">
            Currently using: {activeConfig?.version} ({activeConfig?.model})
          </p>
        </div>
        <Button onClick={() => refetch()} variant="outline" size="sm">
          <RotateCw className="mr-2 h-4 w-4" />
          Refresh
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Configuration Versions</CardTitle>
          <CardDescription>
            View and manage all available scoring configurations
          </CardDescription>
        </CardHeader>
        <CardContent>
          {configs && configs.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Version</TableHead>
                  <TableHead>Model</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Last Updated</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {configs.map((config) => (
                  <TableRow key={config.id}>
                    <TableCell className="font-medium">{config.version}</TableCell>
                    <TableCell>{config.model}</TableCell>
                    <TableCell>
                      {config.is_active ? (
                        <Badge className="bg-green-500 hover:bg-green-600">Active</Badge>
                      ) : (
                        <Badge variant="outline">Inactive</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {formatDistanceToNow(new Date(config.created_at), { addSuffix: true })}
                    </TableCell>
                    <TableCell>
                      {formatDistanceToNow(new Date(config.updated_at), { addSuffix: true })}
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => {
                          setSelectedConfig(config);
                          setShowJsonDialog(true);
                        }}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleCloneConfig(config)}
                      >
                        <Copy className="h-4 w-4 mr-1" />
                        Clone
                      </Button>
                      
                      {!config.is_active && (
                        <Button 
                          variant="default" 
                          size="sm"
                          onClick={() => {
                            setSelectedConfig(config);
                            setConfirmActivateOpen(true);
                          }}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Activate
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="flex flex-col items-center justify-center py-6">
              <AlertCircle className="h-10 w-10 text-muted-foreground mb-2" />
              <p className="text-muted-foreground">No configurations found</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* View JSON Dialog */}
      <Dialog open={showJsonDialog} onOpenChange={setShowJsonDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Configuration Details</DialogTitle>
            <DialogDescription>
              Version {selectedConfig?.version} - {selectedConfig?.model}
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="weights">
            <TabsList>
              <TabsTrigger value="weights">Weights</TabsTrigger>
              <TabsTrigger value="prompt">Prompt Template</TabsTrigger>
              <TabsTrigger value="full">Full JSON</TabsTrigger>
            </TabsList>
            
            <TabsContent value="weights" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium">Scoring Weights</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => selectedConfig && handleCopyJson(JSON.stringify(selectedConfig.weights, null, 2))}
                >
                  <ClipboardCopy className="h-4 w-4 mr-1" />
                  Copy
                </Button>
              </div>
              
              <div className="relative">
                <Textarea 
                  readOnly
                  value={selectedConfig ? JSON.stringify(selectedConfig.weights, null, 2) : ''}
                  className="font-mono text-sm h-64"
                />
                <div className="absolute top-2 right-2">
                  <Badge variant="outline">Read Only</Badge>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="prompt" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium">Prompt Template</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => selectedConfig && handleCopyJson(selectedConfig.prompt_template || '')}
                >
                  <ClipboardCopy className="h-4 w-4 mr-1" />
                  Copy
                </Button>
              </div>
              
              <div className="relative">
                <Textarea 
                  readOnly
                  value={selectedConfig?.prompt_template || 'No prompt template available'}
                  className="font-mono text-sm h-64"
                />
                <div className="absolute top-2 right-2">
                  <Badge variant="outline">Read Only</Badge>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="full" className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium">Full Configuration</h3>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => selectedConfig && handleCopyJson(JSON.stringify(selectedConfig, null, 2))}
                >
                  <ClipboardCopy className="h-4 w-4 mr-1" />
                  Copy
                </Button>
              </div>
              
              <div className="relative">
                <Textarea 
                  readOnly
                  value={selectedConfig ? JSON.stringify(selectedConfig, null, 2) : ''}
                  className="font-mono text-sm h-64"
                />
                <div className="absolute top-2 right-2">
                  <Badge variant="outline">Read Only</Badge>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowJsonDialog(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirm Activation Dialog */}
      <Dialog open={confirmActivateOpen} onOpenChange={setConfirmActivateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Activate Configuration</DialogTitle>
            <DialogDescription>
              Are you sure you want to activate version {selectedConfig?.version}? 
              This will be used for all image scoring.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-2">
            <div className="flex items-center space-x-2">
              <div className="flex-1">
                <p className="text-sm font-medium">Current active version</p>
                <p className="text-sm text-muted-foreground">{activeConfig?.version}</p>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">New version to activate</p>
                <p className="text-sm text-muted-foreground">{selectedConfig?.version}</p>
              </div>
            </div>
            
            <div className="border rounded p-3 bg-amber-50 dark:bg-amber-950/20">
              <p className="text-sm text-amber-800 dark:text-amber-400">
                This change will affect all new image analysis operations. 
                Existing scores won't be recalculated.
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmActivateOpen(false)}>
              Cancel
            </Button>
            <Button 
              variant="default" 
              onClick={() => selectedConfig && handleActivateConfig(selectedConfig)}
            >
              <CheckCircle className="h-4 w-4 mr-1" />
              Activate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ScoringConfigManager;
