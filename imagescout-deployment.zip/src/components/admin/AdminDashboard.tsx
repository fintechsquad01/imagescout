
import React, { useState, Suspense, lazy } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from '@/components/ui/separator';
import { Loader2, HelpCircle } from 'lucide-react';
import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import AdminSidebar from './AdminSidebar';
import UserStats from './UserStats';
import { useRoleCheck } from '@/hooks/useRoleCheck';
import UnauthorizedAccess from './UnauthorizedAccess';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { isDevelopmentMode, logRoleBypass } from '@/utils/devMode';
import DevModeBanner from '@/components/dev/DevModeBanner';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const InviteCodeAnalytics = lazy(() => import('./InviteCodeAnalytics'));
const UsageStatistics = lazy(() => import('./UsageStatistics'));
const FeedbackDashboard = lazy(() => import('./FeedbackDashboard'));
const ScoringConfigManager = lazy(() => import('./scoring/ScoringConfigManager'));

const TabLoading = () => (
  <div className="space-y-4">
    <Skeleton className="h-8 w-64" />
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {[1, 2, 3].map((i) => (
        <Skeleton key={i} className="h-32 w-full" />
      ))}
    </div>
    <Skeleton className="h-[350px] w-full" />
  </div>
);

const EmptyStateMessage = ({ title, description, testWorkflow = false }) => (
  <div className="flex flex-col items-center justify-center p-8 border border-dashed rounded-lg bg-muted/30 min-h-[350px]">
    <h3 className="text-lg font-medium mb-2">{title}</h3>
    <p className="text-muted-foreground text-center max-w-md mb-4">{description}</p>
    
    {testWorkflow && isDevelopmentMode() && (
      <div className="bg-amber-50 border border-amber-200 dark:bg-amber-950/20 dark:border-amber-900 p-4 rounded-md mt-4 max-w-md">
        <div className="flex items-start">
          <HelpCircle className="text-amber-600 w-5 h-5 mr-2 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-amber-800 dark:text-amber-400">Developer Testing Guide</p>
            <p className="text-xs text-amber-700 dark:text-amber-500 mt-1">
              Use the "Generate Test Data" button in the bottom right corner to create sample scoring data for testing. 
              This feature is only available in development mode.
            </p>
          </div>
        </div>
      </div>
    )}
  </div>
);

const AdminDashboard = () => {
  const { isAuthorized, isLoading: roleLoading } = useRoleCheck(['admin', 'internal']);
  const { isFeatureEnabled, isLoading: flagsLoading } = useFeatureFlags();
  const [activeTab, setActiveTab] = useState('users');

  const isLoading = roleLoading || flagsLoading;
  
  React.useEffect(() => {
    if (isDevelopmentMode()) {
      logRoleBypass(['admin', 'internal']);
      toast.info('Development mode: Admin dashboard is accessible with all features enabled', {
        duration: 5000,
        id: 'dev-mode-admin'
      });
    }
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Loading dashboard access...</span>
      </div>
    );
  }

  if (!isAuthorized && !isDevelopmentMode()) {
    return <UnauthorizedAccess />;
  }

  const hasAdvancedAnalytics = isDevelopmentMode() || isFeatureEnabled('advanced_analytics');

  // Clear mapping between tabs and sidebar sections
  const tabToSection: Record<string, string> = {
    'users': 'overview',
    'invites': 'overview',
    'usage': 'usage',
    'feedback': 'feedback',
    'scoring': 'advanced'
  };

  const currentSection = tabToSection[activeTab] || 'overview';

  return (
    <SidebarProvider defaultOpen={true}>
      <div className="flex w-full">
        <AdminSidebar activeSection={currentSection} />
        
        <SidebarInset className="p-6">
          <div className="space-y-8 max-w-[1400px] mx-auto">
            {isDevelopmentMode() && (
              <DevModeBanner 
                context="Admin dashboard" 
                showDetails={true}
                className="mb-2"
              />
            )}
            
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
              <p className="text-muted-foreground mt-2">
                Monitor beta activity, invite codes, application usage statistics, and user feedback
                {isDevelopmentMode() && (
                  <Badge variant="outline" className="ml-2 bg-amber-500/10 text-amber-600 border-amber-500/30 hover:bg-amber-500/20 hover:text-amber-700">Dev Mode Access</Badge>
                )}
              </p>
            </div>
            
            <Separator className="my-6" />
            
            <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="users">Users</TabsTrigger>
                <TabsTrigger value="invites">Invite Codes</TabsTrigger>
                {hasAdvancedAnalytics && (
                  <>
                    <TabsTrigger value="usage">Usage Stats</TabsTrigger>
                    <TabsTrigger value="feedback">Feedback</TabsTrigger>
                    <TabsTrigger value="scoring">Scoring</TabsTrigger>
                  </>
                )}
              </TabsList>
              
              <TabsContent value="users" className="space-y-6">
                <UserStats />
              </TabsContent>
              
              <TabsContent value="invites" className="space-y-6">
                <Suspense fallback={<TabLoading />}>
                  <InviteCodeAnalytics />
                </Suspense>
              </TabsContent>
              
              {hasAdvancedAnalytics && (
                <>
                  <TabsContent value="usage" className="space-y-6">
                    <Suspense fallback={<TabLoading />}>
                      <UsageStatistics />
                    </Suspense>
                  </TabsContent>
                  
                  <TabsContent value="feedback" className="space-y-6">
                    <Suspense fallback={<TabLoading />}>
                      <FeedbackDashboard />
                    </Suspense>
                  </TabsContent>
                  
                  <TabsContent value="scoring" className="space-y-6">
                    <Suspense fallback={<TabLoading />}>
                      <ScoringConfigManager />
                      <EmptyStateMessage 
                        title="Need test data for development?"
                        description="This section allows you to manage and test scoring configurations for image analysis."
                        testWorkflow={true}
                      />
                    </Suspense>
                  </TabsContent>
                </>
              )}
            </Tabs>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
};

export default AdminDashboard;
