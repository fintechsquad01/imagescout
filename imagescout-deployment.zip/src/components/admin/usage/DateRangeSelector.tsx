
import React from 'react';

interface DateRangeSelectorProps {
  selectedRange: number;
  onRangeChange: (days: number) => void;
}

const DateRangeSelector: React.FC<DateRangeSelectorProps> = ({ 
  selectedRange, 
  onRangeChange 
}) => {
  return (
    <div className="flex justify-end space-x-2">
      <button 
        onClick={() => onRangeChange(7)} 
        className={`px-3 py-1 text-sm rounded-md ${selectedRange === 7 ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}
      >
        7 days
      </button>
      <button 
        onClick={() => onRangeChange(14)} 
        className={`px-3 py-1 text-sm rounded-md ${selectedRange === 14 ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}
      >
        14 days
      </button>
      <button 
        onClick={() => onRangeChange(30)} 
        className={`px-3 py-1 text-sm rounded-md ${selectedRange === 30 ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}
      >
        30 days
      </button>
    </div>
  );
};

export default DateRangeSelector;

// Add a DatePicker component as a separate export
interface DatePickerProps {
  date: Date | undefined;
  setDate: (date: Date) => void;
}

export const DatePicker: React.FC<DatePickerProps> = ({ date, setDate }) => {
  return (
    <div className="flex w-full max-w-sm items-center space-x-2">
      <input
        type="date"
        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
        value={date ? date.toISOString().split('T')[0] : ''}
        onChange={(e) => {
          const selectedDate = e.target.value ? new Date(e.target.value) : new Date();
          setDate(selectedDate);
        }}
      />
    </div>
  );
};

