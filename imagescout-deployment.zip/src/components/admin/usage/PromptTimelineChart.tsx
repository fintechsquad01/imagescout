
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip } from "@/components/ui/chart";
import { Skeleton } from "@/components/ui/skeleton";
import { DailyPromptCount } from '@/types/admin-dashboard';
import AdminSectionHeader from '../AdminSectionHeader';

interface PromptTimelineChartProps {
  data: DailyPromptCount[];
  isLoading: boolean;
}

const PromptTimelineChart: React.FC<PromptTimelineChartProps> = ({ data, isLoading }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Daily Prompt Submissions</CardTitle>
        <CardDescription>Number of prompts submitted per day</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-72 w-full" />
        ) : (
          <div className="h-72">
            <ChartContainer config={{}}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="formattedDate" 
                  tick={{ fontSize: 12 }}
                  tickMargin={10}
                />
                <YAxis />
                <Tooltip content={<ChartTooltip />} />
                <Line 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#8884d8" 
                  name="Prompts"
                  strokeWidth={2}
                  dot={{ r: 3 }}
                />
              </LineChart>
            </ChartContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default PromptTimelineChart;
