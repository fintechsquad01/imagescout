
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip } from "@/components/ui/chart";
import { Skeleton } from "@/components/ui/skeleton";
import { ModelUsage } from '@/types/admin-dashboard';
import AdminSectionHeader from '../AdminSectionHeader';

interface ModelUsageChartProps {
  data: ModelUsage[];
  isLoading: boolean;
}

const ModelUsageChart: React.FC<ModelUsageChartProps> = ({ data, isLoading }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Generation by Model</CardTitle>
        <CardDescription>Number of generations by AI model</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-72 w-full" />
        ) : (
          <div className="h-72">
            <ChartContainer config={{}}>
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="model" 
                  tick={{ fontSize: 12 }}
                  tickMargin={10}
                />
                <YAxis />
                <Tooltip content={<ChartTooltip />} />
                <Bar 
                  dataKey="count" 
                  name="Generations" 
                  fill="#8884d8"
                >
                  {data.map((entry, index) => (
                    <Bar key={`bar-${index}`} dataKey="count" fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ChartContainer>
          </div>
        )}
        
        <div className="mt-4 grid grid-cols-2 gap-2">
          {data.map((model) => (
            <div key={model.model} className="flex items-center">
              <div 
                className="w-3 h-3 mr-2 rounded-sm"
                style={{ backgroundColor: model.color }}
              />
              <span className="text-sm">
                {model.model}: <strong>{model.count}</strong> generations
              </span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default ModelUsageChart;
