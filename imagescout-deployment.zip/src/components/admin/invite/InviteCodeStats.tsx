
import React from 'react';
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { InviteStatistics } from '@/types/admin-dashboard';
import { Calendar, Clock } from 'lucide-react';

interface InviteCodeStatsProps {
  stats: InviteStatistics;
  isLoading: boolean;
}

const InviteCodeStats: React.FC<InviteCodeStatsProps> = ({ stats, isLoading }) => {
  return (
    <div className="grid gap-6 md:grid-cols-3">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl">Total Codes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold">
            {isLoading ? <Skeleton className="h-10 w-16" /> : stats.total}
          </div>
          <p className="text-xs text-muted-foreground mt-1">All invite codes</p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl">Used Codes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold">
            {isLoading ? <Skeleton className="h-10 w-16" /> : stats.used}
          </div>
          <p className="text-xs text-muted-foreground mt-1">Codes redeemed by users</p>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl">Remaining Codes</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold">
            {isLoading ? <Skeleton className="h-10 w-16" /> : stats.remaining}
          </div>
          <p className="text-xs text-muted-foreground mt-1">Available for new users</p>
        </CardContent>
      </Card>
      
      {stats.recentActivity && (
        <Card className="md:col-span-3">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              <span>Recent Activity</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Last 24 hours</p>
                <p className="text-2xl font-semibold mt-1">
                  {isLoading ? <Skeleton className="h-8 w-12" /> : stats.recentActivity.last24h}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Last 7 days</p>
                <p className="text-2xl font-semibold mt-1">
                  {isLoading ? <Skeleton className="h-8 w-12" /> : stats.recentActivity.last7d}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Last 30 days</p>
                <p className="text-2xl font-semibold mt-1">
                  {isLoading ? <Skeleton className="h-8 w-12" /> : stats.recentActivity.last30d}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default InviteCodeStats;
