
import React from 'react';
import { format } from 'date-fns';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { InviteCodeUI, PaginationState } from '@/types/admin-dashboard';
import { isDevelopmentMode } from '@/utils/devMode';

interface InviteCodeTableProps {
  inviteCodes: InviteCodeUI[];
  isLoading: boolean;
  pagination: PaginationState;
  onPageChange: (page: number) => void;
}

const InviteCodeTable: React.FC<InviteCodeTableProps> = ({ 
  inviteCodes, 
  isLoading, 
  pagination, 
  onPageChange 
}) => {
  if (isDevelopmentMode() && inviteCodes.length > 0) {
    console.log('[DEV MODE] Rendering invite code table with:', inviteCodes[0]);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Invite Code Details</CardTitle>
        <CardDescription>Complete list of invite codes and usage</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : (
          <>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Code</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Used By</TableHead>
                  <TableHead>Created By</TableHead>
                  <TableHead>Created On</TableHead>
                  <TableHead>Expires</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {inviteCodes.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-4 text-muted-foreground">
                      No invite codes found
                    </TableCell>
                  </TableRow>
                ) : (
                  inviteCodes.map((invite) => (
                    <TableRow key={invite.id}>
                      <TableCell className="font-mono">{invite.code}</TableCell>
                      <TableCell>
                        {invite.is_active ? (
                          invite.uses > 0 ? (
                            <Badge variant="secondary">Used</Badge>
                          ) : (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                              Available
                            </Badge>
                          )
                        ) : (
                          <Badge variant="destructive">Inactive</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <span className="truncate max-w-32 block">
                          {invite.user_email}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className="truncate max-w-32 block">
                          {invite.creator_email}
                        </span>
                      </TableCell>
                      <TableCell>
                        {format(new Date(invite.created_at), 'MMM d, yyyy')}
                      </TableCell>
                      <TableCell>
                        {invite.expires_at 
                          ? format(new Date(invite.expires_at), 'MMM d, yyyy')
                          : 'Never'
                        }
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
            
            {pagination.totalPages > 1 && (
              <Pagination className="mt-4">
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious 
                      onClick={() => onPageChange(pagination.currentPage - 1)}
                      className={pagination.currentPage === 1 ? 'pointer-events-none opacity-50' : ''}
                    />
                  </PaginationItem>
                  
                  {Array.from({ length: Math.min(5, pagination.totalPages) }).map((_, i) => {
                    // Show current page and surrounding pages
                    let pageToShow = pagination.currentPage - 2 + i;
                    if (pagination.currentPage < 3) {
                      pageToShow = i + 1;
                    } else if (pagination.currentPage > pagination.totalPages - 2) {
                      pageToShow = pagination.totalPages - 4 + i;
                    }
                    
                    if (pageToShow > 0 && pageToShow <= pagination.totalPages) {
                      return (
                        <PaginationItem key={i}>
                          <PaginationLink 
                            isActive={pagination.currentPage === pageToShow}
                            onClick={() => onPageChange(pageToShow)}
                          >
                            {pageToShow}
                          </PaginationLink>
                        </PaginationItem>
                      );
                    }
                    return null;
                  })}
                  
                  <PaginationItem>
                    <PaginationNext 
                      onClick={() => onPageChange(pagination.currentPage + 1)}
                      className={pagination.currentPage === pagination.totalPages ? 'pointer-events-none opacity-50' : ''}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default InviteCodeTable;
