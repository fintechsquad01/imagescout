
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { Skeleton } from "@/components/ui/skeleton";
import { InviteCodeUI, InviteCodeChartData } from '@/types/admin-dashboard';
import { isDevelopmentMode } from '@/utils/devMode';
import { format } from 'date-fns';

interface InviteCodeChartProps {
  inviteCodes: InviteCodeUI[];
  isLoading: boolean;
}

const InviteCodeChart: React.FC<InviteCodeChartProps> = ({ inviteCodes, isLoading }) => {
  // Transform invite codes data for chart display
  const chartData = React.useMemo(() => {
    if (isDevelopmentMode()) {
      console.log('[DEV MODE] Generating chart data from invite codes:', inviteCodes.length);
    }

    // Group by creation month
    const groupedByMonth: Record<string, number> = {};
    
    inviteCodes.forEach(code => {
      try {
        if (!code.created_at) {
          if (isDevelopmentMode()) {
            console.warn('[DEV MODE] Missing created_at for invite code:', code.id);
          }
          return;
        }
        
        const date = new Date(code.created_at);
        const monthYear = format(date, 'MMM yyyy');
        
        if (!groupedByMonth[monthYear]) {
          groupedByMonth[monthYear] = 0;
        }
        
        groupedByMonth[monthYear]++;
      } catch (err) {
        if (isDevelopmentMode()) {
          console.warn('[DEV MODE] Error processing invite code for chart:', code, err);
        }
      }
    });
    
    // Convert to array format for Recharts
    return Object.entries(groupedByMonth)
      .map(([month, count]) => ({
        month,
        count
      }))
      .sort((a, b) => {
        // Sort by month chronologically
        const monthA = new Date(a.month);
        const monthB = new Date(b.month);
        return monthA.getTime() - monthB.getTime();
      });
  }, [inviteCodes]);
  
  const chartConfig = {
    invites: {
      color: '#10b981', // green-500
      label: 'Invite Codes'
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Invite Code Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-[300px] w-full" />
        ) : (
          <div className="h-[300px]">
            <ChartContainer config={chartConfig}>
              <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 30 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="month" 
                  tick={{ fontSize: 12 }}
                  tickMargin={10}
                />
                <YAxis 
                  allowDecimals={false}
                  tick={{ fontSize: 12 }}
                />
                <ChartTooltip 
                  content={({ active, payload }) => (
                    <ChartTooltipContent 
                      active={active} 
                      payload={payload}
                      labelFormatter={(value) => `${value}`}
                    />
                  )}
                />
                <Bar 
                  dataKey="count" 
                  fill="var(--color-invites)" 
                  name="invites"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ChartContainer>
          </div>
        )}
        {chartData.length === 0 && !isLoading && (
          <div className="h-[300px] flex items-center justify-center">
            <p className="text-muted-foreground">No invite code data available</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default InviteCodeChart;
