import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabaseClient';

const FeedbackStats = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    totalFeedback: 0,
    averageRating: 0,
    modelBreakdown: [] as { name: string; count: number; averageRating: number }[],
    scoreBreakdown: [] as { range: string; count: number; averageRating: number }[],
    labelFrequency: [] as { name: string; count: number }[],
  });

  useEffect(() => {
    const fetchStats = async () => {
      setIsLoading(true);
      try {
        // Get all feedback
        const { data, error } = await supabase
          .from('scoring_feedback')
          .select('*');

        if (error) {
          throw error;
        }

        if (!data || data.length === 0) {
          setStats({
            totalFeedback: 0,
            averageRating: 0,
            modelBreakdown: [],
            scoreBreakdown: [],
            labelFrequency: []
          });
          setIsLoading(false);
          return;
        }

        // Calculate total and average rating
        const totalFeedback = data.length;
        const totalRating = data.reduce((sum, item) => sum + (item.rating || 0), 0);
        const averageRating = totalRating / totalFeedback;

        // Calculate model breakdown
        const modelMap = new Map<string, { count: number; totalRating: number }>();
        data.forEach(item => {
          const modelName = item.model_name || 'Unknown';
          if (!modelMap.has(modelName)) {
            modelMap.set(modelName, { count: 0, totalRating: 0 });
          }
          const current = modelMap.get(modelName)!;
          current.count += 1;
          current.totalRating += item.rating || 0;
        });

        const modelBreakdown = Array.from(modelMap.entries()).map(([name, stats]) => ({
          name,
          count: stats.count,
          averageRating: stats.totalRating / stats.count
        }));

        // Calculate score range breakdown
        const scoreRanges = [
          { min: 0, max: 30, label: '0-30' },
          { min: 31, max: 70, label: '31-70' },
          { min: 71, max: 100, label: '71-100' }
        ];

        const scoreMap = new Map<string, { count: number; totalRating: number }>();
        scoreRanges.forEach(range => {
          scoreMap.set(range.label, { count: 0, totalRating: 0 });
        });

        data.forEach(item => {
          const score = item.score || 0;
          const range = scoreRanges.find(r => score >= r.min && score <= r.max);
          if (range) {
            const current = scoreMap.get(range.label)!;
            current.count += 1;
            current.totalRating += item.rating || 0;
          }
        });

        const scoreBreakdown = Array.from(scoreMap.entries())
          .map(([range, stats]) => ({
            range,
            count: stats.count,
            averageRating: stats.count > 0 ? stats.totalRating / stats.count : 0
          }))
          .filter(item => item.count > 0);

        // Calculate label frequency
        const labelMap = new Map<string, number>();
        data.forEach(item => {
          if (item.labels && Array.isArray(item.labels)) {
            item.labels.forEach(label => {
              if (typeof label === 'string') {
                labelMap.set(label, (labelMap.get(label) || 0) + 1);
              }
            });
          }
        });

        const labelFrequency = Array.from(labelMap.entries())
          .map(([name, count]) => ({ name, count }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 10);

        setStats({
          totalFeedback,
          averageRating,
          modelBreakdown,
          scoreBreakdown,
          labelFrequency
        });
      } catch (err) {
        console.error('Error fetching stats:', err);
        toast('Error loading stats: Failed to load feedback statistics');
      } finally {
        setIsLoading(false);
      }
    };

    fetchStats();
  }, []);

  const colors = [
    '#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#0088FE', 
    '#00C49F', '#FFBB28', '#FF8042', '#a4de6c', '#d0ed57'
  ];

  const renderModelChart = () => (
    <ResponsiveContainer width="100%" height={300}>
      {stats.modelBreakdown.length > 0 ? (
        <BarChart data={stats.modelBreakdown}>
          <XAxis dataKey="name" />
          <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
          <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
          <Tooltip />
          <Bar yAxisId="left" dataKey="count" name="Feedback Count" fill="#8884d8" />
          <Bar yAxisId="right" dataKey="averageRating" name="Avg Rating" fill="#82ca9d" />
        </BarChart>
      ) : (
        <div className="h-full flex items-center justify-center">
          <p className="text-muted-foreground">No model data available</p>
        </div>
      )}
    </ResponsiveContainer>
  );

  const renderScoreChart = () => (
    <ResponsiveContainer width="100%" height={300}>
      {stats.scoreBreakdown.length > 0 ? (
        <BarChart data={stats.scoreBreakdown}>
          <XAxis dataKey="range" />
          <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
          <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
          <Tooltip />
          <Bar yAxisId="left" dataKey="count" name="Feedback Count" fill="#8884d8" />
          <Bar yAxisId="right" dataKey="averageRating" name="Avg Rating" fill="#82ca9d" />
        </BarChart>
      ) : (
        <div className="h-full flex items-center justify-center">
          <p className="text-muted-foreground">No score range data available</p>
        </div>
      )}
    </ResponsiveContainer>
  );

  const renderLabelChart = () => (
    <ResponsiveContainer width="100%" height={300}>
      {stats.labelFrequency.length > 0 ? (
        <BarChart data={stats.labelFrequency}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="count" name="Frequency">
            {stats.labelFrequency.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
            ))}
          </Bar>
        </BarChart>
      ) : (
        <div className="h-full flex items-center justify-center">
          <p className="text-muted-foreground">No label data available</p>
        </div>
      )}
    </ResponsiveContainer>
  );

  if (isLoading) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Feedback Analytics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </div>
          <Skeleton className="h-[300px]" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle>Feedback Analytics</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-muted/40 p-4 rounded-lg">
            <div className="text-2xl font-bold">{stats.totalFeedback}</div>
            <div className="text-muted-foreground">Total Feedback</div>
          </div>
          <div className="bg-muted/40 p-4 rounded-lg">
            <div className="text-2xl font-bold">
              {stats.averageRating.toFixed(1)}
              <span className="text-yellow-500 ml-2 text-lg">★</span>
            </div>
            <div className="text-muted-foreground">Average Rating</div>
          </div>
          <div className="bg-muted/40 p-4 rounded-lg">
            <div className="text-2xl font-bold">{stats.labelFrequency.length}</div>
            <div className="text-muted-foreground">Unique Labels</div>
          </div>
        </div>

        <Tabs defaultValue="models">
          <TabsList className="mb-4">
            <TabsTrigger value="models">By Model</TabsTrigger>
            <TabsTrigger value="scores">By Score Range</TabsTrigger>
            <TabsTrigger value="labels">By Label</TabsTrigger>
          </TabsList>
          
          <TabsContent value="models">
            {renderModelChart()}
          </TabsContent>
          
          <TabsContent value="scores">
            {renderScoreChart()}
          </TabsContent>
          
          <TabsContent value="labels">
            {renderLabelChart()}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default FeedbackStats;
