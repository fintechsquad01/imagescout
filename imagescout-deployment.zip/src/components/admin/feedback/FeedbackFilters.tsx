import React, { useState, useEffect } from 'react';
import { Calendar as CalendarIcon, Filter, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { supabase } from '@/lib/supabaseClient';

interface FeedbackFiltersProps {
  dateRange: { start?: Date; end?: Date };
  setDateRange: React.Dispatch<React.SetStateAction<{ start?: Date; end?: Date }>>;
  modelFilter: string;
  setModelFilter: React.Dispatch<React.SetStateAction<string>>;
  ratingFilter: string;
  setRatingFilter: React.Dispatch<React.SetStateAction<string>>;
  labelFilter: string;
  setLabelFilter: React.Dispatch<React.SetStateAction<string>>;
}

interface ModelInfo {
  id: string;
  name: string;
}

const FeedbackFilters: React.FC<FeedbackFiltersProps> = ({
  dateRange,
  setDateRange,
  modelFilter,
  setModelFilter,
  ratingFilter,
  setRatingFilter,
  labelFilter,
  setLabelFilter
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [dateValue, setDateValue] = useState<Date | undefined>(undefined);
  const [availableModels, setAvailableModels] = useState<ModelInfo[]>([]);
  const [availableLabels, setAvailableLabels] = useState<string[]>([]);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);

  useEffect(() => {
    const fetchFilterOptions = async () => {
      try {
        const { data: modelData, error: modelError } = await supabase
          .from('scoring_feedback')
          .select('model_id, model_name')
          .order('model_name');

        if (modelError) throw modelError;

        const processedModels: ModelInfo[] = [];
        const modelMap = new Map<string, string>();
        
        if (modelData) {
          modelData.forEach(item => {
            if (item.model_id && !modelMap.has(item.model_id)) {
              modelMap.set(item.model_id, item.model_name || 'Unknown model');
              processedModels.push({
                id: item.model_id,
                name: item.model_name || 'Unknown model'
              });
            }
          });
        }

        setAvailableModels(processedModels);

        const { data: labelData, error: labelError } = await supabase
          .from('scoring_feedback')
          .select('labels');

        if (labelError) throw labelError;

        const allLabels = new Set<string>();
        if (labelData) {
          labelData.forEach(item => {
            if (item.labels && Array.isArray(item.labels)) {
              item.labels.forEach(label => {
                if (typeof label === 'string') {
                  allLabels.add(label);
                }
              });
            }
          });
        }

        setAvailableLabels(Array.from(allLabels).sort());
      } catch (error) {
        console.error('Error fetching filter options:', error);
      }
    };

    fetchFilterOptions();
  }, []);

  useEffect(() => {
    const filters = [];
    
    if (dateRange.start && dateRange.end) {
      filters.push(`Date: ${format(dateRange.start, 'MMM d')} - ${format(dateRange.end, 'MMM d, yyyy')}`);
    } else if (dateRange.start) {
      filters.push(`Date from: ${format(dateRange.start, 'MMM d, yyyy')}`);
    } else if (dateRange.end) {
      filters.push(`Date until: ${format(dateRange.end, 'MMM d, yyyy')}`);
    }
    
    if (modelFilter) {
      const modelName = availableModels.find(m => m.id === modelFilter)?.name || 'Unknown model';
      filters.push(`Model: ${modelName}`);
    }
    
    if (ratingFilter) {
      filters.push(`Rating: ${ratingFilter} ★`);
    }
    
    if (labelFilter) {
      filters.push(`Label: ${labelFilter}`);
    }
    
    setActiveFilters(filters);
  }, [dateRange, modelFilter, ratingFilter, labelFilter, availableModels]);

  const handleDateSelect = (date: Date | undefined) => {
    if (!dateValue) {
      setDateValue(date);
      setDateRange(prev => ({ ...prev, start: date }));
    } else if (date && date < dateValue) {
      setDateRange({ start: date, end: dateValue });
      setDateValue(undefined);
    } else {
      setDateRange(prev => ({ ...prev, end: date }));
      setDateValue(undefined);
    }
  };

  const clearDateFilter = () => {
    setDateRange({});
    setDateValue(undefined);
  };

  const clearAllFilters = () => {
    setDateRange({});
    setDateValue(undefined);
    setModelFilter('');
    setRatingFilter('');
    setLabelFilter('');
  };

  const removeFilter = (filterText: string) => {
    if (filterText.startsWith('Date')) {
      clearDateFilter();
    } else if (filterText.startsWith('Model')) {
      setModelFilter('');
    } else if (filterText.startsWith('Rating')) {
      setRatingFilter('');
    } else if (filterText.startsWith('Label')) {
      setLabelFilter('');
    }
  };

  return (
    <div className="space-y-2">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filters
            {activeFilters.length > 0 && (
              <Badge className="ml-2 bg-primary text-primary-foreground">{activeFilters.length}</Badge>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80">
          <div className="space-y-4">
            <div className="space-y-2">
              <h4 className="font-medium">Date Range</h4>
              <div className="grid gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "justify-start text-left font-normal",
                        (dateRange.start || dateRange.end) && "text-primary"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateRange.start && dateRange.end ? (
                        <>
                          {format(dateRange.start, "MMM d")} - {format(dateRange.end, "MMM d, yyyy")}
                        </>
                      ) : dateRange.start ? (
                        <>From {format(dateRange.start, "MMM d, yyyy")}</>
                      ) : dateRange.end ? (
                        <>Until {format(dateRange.end, "MMM d, yyyy")}</>
                      ) : (
                        "Select date range"
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateValue}
                      onSelect={handleDateSelect}
                      disabled={(date) => 
                        date > new Date()
                      }
                      initialFocus
                    />
                    {(dateRange.start || dateRange.end) && (
                      <div className="p-3 border-t border-border">
                        <Button variant="ghost" size="sm" onClick={clearDateFilter} className="w-full">
                          <X className="h-4 w-4 mr-2" />
                          Clear date filter
                        </Button>
                      </div>
                    )}
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Model</h4>
              <Select value={modelFilter} onValueChange={setModelFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All models" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All models</SelectItem>
                  {availableModels.map(model => (
                    <SelectItem key={model.id} value={model.id}>
                      {model.name || 'Unknown model'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Rating</h4>
              <Select value={ratingFilter} onValueChange={setRatingFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Any rating" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Any rating</SelectItem>
                  {[5, 4, 3, 2, 1].map(rating => (
                    <SelectItem key={rating} value={rating.toString()}>
                      {rating} ★
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <h4 className="font-medium">Label</h4>
              <Select value={labelFilter} onValueChange={setLabelFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Any label" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Any label</SelectItem>
                  {availableLabels.map(label => (
                    <SelectItem key={label} value={label}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {activeFilters.length > 0 && (
              <Button variant="ghost" size="sm" onClick={clearAllFilters} className="w-full">
                <X className="h-4 w-4 mr-2" />
                Clear all filters
              </Button>
            )}
          </div>
        </PopoverContent>
      </Popover>

      {activeFilters.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          {activeFilters.map((filter, index) => (
            <Badge 
              key={index} 
              variant="secondary"
              className="rounded-full py-1 px-3 flex items-center"
            >
              {filter}
              <Button
                variant="ghost"
                size="sm"
                className="h-4 w-4 p-0 ml-1"
                onClick={() => removeFilter(filter)}
              >
                <X className="h-3 w-3" />
                <span className="sr-only">Remove filter</span>
              </Button>
            </Badge>
          ))}
          
          {activeFilters.length > 1 && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs"
              onClick={clearAllFilters}
            >
              Clear all
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default FeedbackFilters;
