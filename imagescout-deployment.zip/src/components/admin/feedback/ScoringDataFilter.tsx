
import React from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  CalendarIcon,
  Filter,
  SlidersHorizontal
} from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface ScoringDataFilterProps {
  dateRange: {
    startDate: Date;
    endDate: Date;
  };
  setDateRange: (range: { startDate: Date; endDate: Date }) => void;
  scoreFilter: [number, number];
  setScoreFilter: (range: [number, number]) => void;
  includeTestData: boolean;
  setIncludeTestData: (include: boolean) => void;
}

const ScoringDataFilter = ({
  dateRange,
  setDateRange,
  scoreFilter,
  setScoreFilter,
  includeTestData,
  setIncludeTestData,
}: ScoringDataFilterProps) => {
  const [dateOpen, setDateOpen] = React.useState(false);
  const [filtersOpen, setFiltersOpen] = React.useState(false);
  
  // Date range selection
  const handleDateSelect = (date: Date | undefined) => {
    if (!date) return;
    
    // If no start date is selected or a new range is being selected
    if (!dateRange.startDate || (dateRange.startDate && dateRange.endDate)) {
      setDateRange({
        startDate: date,
        endDate: date
      });
    } 
    // If start date is selected but end date isn't
    else if (dateRange.startDate && !dateRange.endDate) {
      // Ensure end date is after start date
      if (date < dateRange.startDate) {
        setDateRange({
          startDate: date,
          endDate: dateRange.startDate
        });
      } else {
        setDateRange({
          startDate: dateRange.startDate,
          endDate: date
        });
      }
      setDateOpen(false);
    }
  };
  
  const formattedDateRange = dateRange.startDate && dateRange.endDate
    ? `${format(dateRange.startDate, 'MMM dd')} - ${format(dateRange.endDate, 'MMM dd')}`
    : "Select date range";

  return (
    <div className="flex items-center gap-2">
      <Popover open={dateOpen} onOpenChange={setDateOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="w-auto justify-start">
            <CalendarIcon className="mr-2 h-4 w-4" />
            {formattedDateRange}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="end">
          <Calendar
            mode="range"
            selected={{
              from: dateRange.startDate,
              to: dateRange.endDate
            }}
            onSelect={(range) => {
              if (range?.from) {
                setDateRange({
                  startDate: range.from,
                  endDate: range.to || range.from
                });
                // Only close if a complete range is selected
                if (range.to) setDateOpen(false);
              }
            }}
            initialFocus
          />
        </PopoverContent>
      </Popover>

      <Popover open={filtersOpen} onOpenChange={setFiltersOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm">
            <Filter className="mr-2 h-4 w-4" />
            Filters
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80" align="end">
          <div className="space-y-4">
            <h4 className="font-medium">Filter Options</h4>
            
            <div className="space-y-2">
              <h5 className="text-sm font-medium">Score Range</h5>
              <Slider
                defaultValue={scoreFilter}
                min={0}
                max={100}
                step={1}
                value={scoreFilter}
                onValueChange={(value) => setScoreFilter(value as [number, number])}
                className="py-4"
              />
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>{scoreFilter[0]}</span>
                <span>{scoreFilter[1]}</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="include-test"
                checked={includeTestData}
                onCheckedChange={setIncludeTestData}
              />
              <Label htmlFor="include-test">Include test data</Label>
            </div>
            
            <div className="flex justify-end">
              <Button 
                size="sm" 
                onClick={() => setFiltersOpen(false)}
              >
                Apply Filters
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default ScoringDataFilter;
