
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Filter } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import FeedbackEmptyState from './FeedbackEmptyState';
import { 
  ChartDataItem, 
  DetailChartDataItem,
  getIntentOptions 
} from '@/utils/feedbackCharts';

interface FeedbackChartProps {
  isLoading: boolean;
  hasData: boolean;
  selectedIntent: string;
  setSelectedIntent: (intent: string) => void;
  sortMethod: 'alphabetical' | 'positive' | 'negative' | 'total';
  setSortMethod: (method: 'alphabetical' | 'positive' | 'negative' | 'total') => void;
  chartData: ChartDataItem[] | DetailChartDataItem[];
  intentStats: Record<string, { positive: number; negative: number }>;
}

const FeedbackChart: React.FC<FeedbackChartProps> = ({
  isLoading,
  hasData,
  selectedIntent,
  setSelectedIntent,
  sortMethod,
  setSortMethod,
  chartData,
  intentStats
}) => {
  if (isLoading) {
    return (
      <Card className="col-span-1 md:col-span-3">
        <CardHeader>
          <Skeleton className="h-5 w-40" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-[300px] w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
          <CardTitle>Feedback by Content Intent</CardTitle>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={selectedIntent} onValueChange={setSelectedIntent}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by intent" />
              </SelectTrigger>
              <SelectContent>
                {getIntentOptions(intentStats).map((intent) => (
                  <SelectItem key={intent} value={intent}>
                    {intent === 'all' ? 'All Intents' : (intent === 'unknown' ? 'Unknown' : intent)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortMethod} onValueChange={(value) => setSortMethod(value as any)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="alphabetical">Alphabetical</SelectItem>
                <SelectItem value="positive">Most Positive</SelectItem>
                <SelectItem value="negative">Most Negative</SelectItem>
                <SelectItem value="total">Total Feedback</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {!hasData ? (
          <FeedbackEmptyState />
        ) : (
          <div className="h-[350px] mt-4">
            <ResponsiveContainer width="100%" height="100%">
              {selectedIntent === 'all' ? (
                <BarChart
                  data={chartData as ChartDataItem[]}
                  margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fontSize: 12 }}
                    interval={0}
                    angle={-45}
                    textAnchor="end"
                  />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="positive" name="Positive" fill="#10b981" />
                  <Bar dataKey="negative" name="Negative" fill="#ef4444" />
                </BarChart>
              ) : (
                <BarChart
                  data={chartData as DetailChartDataItem[]}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="value">
                    {(chartData as DetailChartDataItem[]).map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              )}
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FeedbackChart;
