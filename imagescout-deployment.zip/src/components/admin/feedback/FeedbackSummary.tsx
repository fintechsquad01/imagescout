
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { ThumbsUp, ThumbsDown } from 'lucide-react';
import { calculateSatisfactionRate } from '@/utils/feedbackCharts';

interface FeedbackSummaryProps {
  isLoading: boolean;
  stats: {
    positive: number;
    negative: number;
    total: number;
  };
}

const FeedbackSummary: React.FC<FeedbackSummaryProps> = ({ isLoading, stats }) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <Skeleton className="h-4 w-28" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-10 w-16 mb-2" />
              <Skeleton className="h-4 w-20" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Overall Rating</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2">
            <p className="text-2xl font-bold">
              {calculateSatisfactionRate(stats.positive, stats.positive + stats.negative)}%
            </p>
            <p className="text-muted-foreground text-sm">positive</p>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Based on {stats.positive + stats.negative} ratings
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Positive Feedback</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2">
            <p className="text-2xl font-bold text-emerald-600">{stats.positive}</p>
            <ThumbsUp className="h-5 w-5 text-emerald-600" />
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {((stats.positive / (stats.positive + stats.negative || 1)) * 100).toFixed(1)}% of total feedback
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Negative Feedback</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2">
            <p className="text-2xl font-bold text-red-600">{stats.negative}</p>
            <ThumbsDown className="h-5 w-5 text-red-600" />
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {((stats.negative / (stats.positive + stats.negative || 1)) * 100).toFixed(1)}% of total feedback
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default FeedbackSummary;
