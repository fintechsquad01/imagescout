
import React from 'react';
import { AlertCircle } from 'lucide-react';

const FeedbackEmptyState: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center h-[300px] text-muted-foreground">
      <AlertCircle className="h-12 w-12 mb-4 text-muted-foreground/50" />
      <h3 className="font-medium mb-2">No feedback data available</h3>
      <p className="text-center text-sm max-w-md">
        No user feedback has been collected for the selected filters. 
        Data will appear here once users start providing feedback.
      </p>
    </div>
  );
};

export default FeedbackEmptyState;
