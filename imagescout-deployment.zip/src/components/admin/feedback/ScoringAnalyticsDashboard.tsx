
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, 
  ResponsiveContainer, BarChart, Bar, Legend 
} from 'recharts';
import { 
  CalendarDays, Filter, ChartBar, ChartLine, ImageIcon, Info
} from 'lucide-react';
import { format, subDays } from 'date-fns';
import { useScoringFeedback } from '@/hooks/useScoringFeedback';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useProject } from '@/context/ProjectContext';
import ExportScoringDataButton from '@/components/feedback/ExportScoringDataButton';
import ScoringDataFilter from './ScoringDataFilter';

const ScoringAnalyticsDashboard = () => {
  const [dateRange, setDateRange] = useState<{
    startDate: Date;
    endDate: Date;
  }>({
    startDate: subDays(new Date(), 30),
    endDate: new Date()
  });
  
  const [activeTab, setActiveTab] = useState('overview');
  const [scoreFilter, setScoreFilter] = useState<[number, number]>([0, 100]);
  const [includeTestData, setIncludeTestData] = useState(false);
  
  const { currentProject } = useProject();
  const { 
    feedback, 
    isLoading, 
    fetchAnalytics, 
    analytics, 
    isAnalyticsLoading 
  } = useScoringFeedback();

  useEffect(() => {
    if (currentProject?.id) {
      fetchAnalytics({
        projectId: currentProject.id,
        startDate: dateRange.startDate,
        endDate: dateRange.endDate,
        scoreRange: scoreFilter,
        includeTest: includeTestData
      });
    }
  }, [currentProject?.id, dateRange, scoreFilter, includeTestData, fetchAnalytics]);

  const timeSeriesData = React.useMemo(() => {
    if (!analytics?.timeSeriesData) return [];
    
    return analytics.timeSeriesData.map(item => ({
      date: format(new Date(item.date), 'MMM dd'),
      avgScore: item.avgScore,
      count: item.count,
      promotedCount: item.promotedCount
    }));
  }, [analytics?.timeSeriesData]);

  const scoreDistribution = React.useMemo(() => {
    if (!analytics?.scoreDistribution) return [];
    
    return analytics.scoreDistribution.map(item => ({
      range: `${item.min}-${item.max}`,
      count: item.count,
    }));
  }, [analytics?.scoreDistribution]);

  const labelFrequency = React.useMemo(() => {
    if (!analytics?.labelFrequency) return [];
    
    return analytics.labelFrequency
      .slice(0, 10)
      .sort((a, b) => b.count - a.count);
  }, [analytics?.labelFrequency]);

  const hasData = analytics?.summary?.totalFeedback > 0;

  if (isLoading || isAnalyticsLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
        <Skeleton className="h-[400px]" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Scoring Analytics</h2>
          <p className="text-muted-foreground">
            Analyze user feedback to guide model iteration and content decisions
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <ScoringDataFilter 
            dateRange={dateRange}
            setDateRange={setDateRange}
            scoreFilter={scoreFilter}
            setScoreFilter={setScoreFilter}
            includeTestData={includeTestData}
            setIncludeTestData={setIncludeTestData}
          />
          <ExportScoringDataButton 
            variant="outline" 
            className="whitespace-nowrap"
          />
        </div>
      </div>

      {hasData ? (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col gap-2">
                  <span className="text-muted-foreground text-sm">Average Score</span>
                  <div className="text-3xl font-bold">
                    {analytics?.summary?.averageScore.toFixed(1) || 'N/A'}
                  </div>
                  {analytics?.summary?.scoreTrend !== undefined && (
                    <Badge variant={analytics.summary.scoreTrend >= 0 ? "secondary" : "destructive"} className="w-fit">
                      {analytics.summary.scoreTrend >= 0 ? '↑' : '↓'} 
                      {Math.abs(analytics.summary.scoreTrend).toFixed(1)}% from previous period
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col gap-2">
                  <span className="text-muted-foreground text-sm">Total Feedback</span>
                  <div className="text-3xl font-bold">
                    {analytics?.summary?.totalFeedback || 0}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {analytics?.summary?.promotedCount || 0} promoted to training
                    {includeTestData && ` (${analytics?.summary?.testCount || 0} test entries)`}
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col gap-2">
                  <span className="text-muted-foreground text-sm">Top Label</span>
                  <div className="text-2xl font-bold truncate">
                    {labelFrequency[0]?.name || 'No data'}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {labelFrequency[0]?.count || 0} occurrences
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader className="pb-2">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
                  <CardTitle>Scoring Trends</CardTitle>
                  <TabsList className="h-auto">
                    <TabsTrigger value="overview" className="text-xs sm:text-sm">
                      <ChartLine className="h-4 w-4 mr-2" />
                      <span className="hidden sm:inline">Overview</span>
                    </TabsTrigger>
                    <TabsTrigger value="scores" className="text-xs sm:text-sm">
                      <ChartBar className="h-4 w-4 mr-2" />
                      <span className="hidden sm:inline">Distribution</span>
                    </TabsTrigger>
                    <TabsTrigger value="labels" className="text-xs sm:text-sm">
                      <Filter className="h-4 w-4 mr-2" />
                      <span className="hidden sm:inline">Labels</span>
                    </TabsTrigger>
                  </TabsList>
                </div>
              </Tabs>
            </CardHeader>
            <CardContent>
              <TabsContent value="overview" className="mt-0">
                {timeSeriesData.length > 0 ? (
                  <div className="h-[400px] w-full mt-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={timeSeriesData}
                        margin={{ top: 20, right: 30, left: 20, bottom: 10 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="date" 
                          padding={{ left: 30, right: 30 }} 
                        />
                        <YAxis 
                          yAxisId="left" 
                          domain={[0, 100]} 
                          label={{ value: 'Avg Score', angle: -90, position: 'insideLeft' }} 
                        />
                        <YAxis 
                          yAxisId="right" 
                          orientation="right" 
                          label={{ value: 'Count', angle: 90, position: 'insideRight' }} 
                        />
                        <Tooltip />
                        <Legend />
                        <Line 
                          yAxisId="left"
                          type="monotone" 
                          dataKey="avgScore" 
                          name="Avg Score" 
                          stroke="#8884d8" 
                          activeDot={{ r: 8 }} 
                        />
                        <Line 
                          yAxisId="right"
                          type="monotone" 
                          dataKey="count" 
                          name="Feedback Count" 
                          stroke="#82ca9d" 
                        />
                        <Line 
                          yAxisId="right"
                          type="monotone" 
                          dataKey="promotedCount" 
                          name="Promoted Count" 
                          stroke="#ff7300" 
                          strokeDasharray="5 5" 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-[400px] flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground">No data available for the selected filters</p>
                      <p className="text-sm text-muted-foreground mt-1">Try adjusting your filters or collecting more feedback</p>
                    </div>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="scores" className="mt-0">
                {scoreDistribution.length > 0 ? (
                  <div className="h-[400px] w-full mt-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={scoreDistribution}
                        margin={{ top: 20, right: 30, left: 20, bottom: 10 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="range" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar 
                          dataKey="count" 
                          name="Count" 
                          fill="#8884d8" 
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-[400px] flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground">No score distribution data available</p>
                      <p className="text-sm text-muted-foreground mt-1">Try adjusting your filters or collecting more feedback</p>
                    </div>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="labels" className="mt-0">
                {labelFrequency.length > 0 ? (
                  <div className="h-[400px] w-full mt-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={labelFrequency}
                        layout="vertical"
                        margin={{ top: 20, right: 30, left: 100, bottom: 10 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis 
                          dataKey="name" 
                          type="category" 
                          width={80}
                          tick={{ fontSize: 12 }}
                        />
                        <Tooltip />
                        <Legend />
                        <Bar 
                          dataKey="count" 
                          name="Occurrences" 
                          fill="#82ca9d" 
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-[400px] flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground">No label data available</p>
                      <p className="text-sm text-muted-foreground mt-1">Try adding labels to your feedback items</p>
                    </div>
                  </div>
                )}
              </TabsContent>
            </CardContent>
          </Card>
        </>
      ) : (
        <EmptyAnalyticsState />
      )}
    </div>
  );
};

// Empty state component when no analytics data is available
const EmptyAnalyticsState = () => {
  return (
    <Card className="py-16">
      <CardContent className="flex flex-col items-center justify-center text-center">
        <div className="rounded-full bg-primary/10 p-4 mb-6">
          <ImageIcon className="h-10 w-10 text-primary" />
        </div>
        <h3 className="text-xl font-semibold mb-2">No scoring data yet</h3>
        <p className="text-muted-foreground max-w-md mx-auto mb-6">
          Start collecting scoring feedback by uploading and scoring images, then ask users to provide feedback on the results.
        </p>
        <div className="bg-muted/50 rounded-lg p-4 max-w-lg mx-auto">
          <div className="flex items-start space-x-3">
            <Info className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
            <div className="text-left">
              <h4 className="font-medium text-sm">Get started with scoring analytics</h4>
              <ol className="mt-2 text-sm text-muted-foreground space-y-2 ml-4 list-decimal">
                <li>Upload images to your project for analysis</li>
                <li>Review opportunity scores generated by our models</li>
                <li>Collect feedback on how accurate the scores are</li>
                <li>Use this dashboard to analyze feedback trends</li>
              </ol>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ScoringAnalyticsDashboard;
