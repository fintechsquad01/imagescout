
import React, { useState, useEffect } from 'react';
import { 
  getFeedbackStats, 
  getFeedbackByContentIntent, 
  getTotalFeedbackCount 
} from '@/utils/feedbackUtils';
import AdminSectionHeader from './AdminSectionHeader';
import FeedbackSummary from './feedback/FeedbackSummary';
import FeedbackChart from './feedback/FeedbackChart';
import { 
  getIntentChartData, 
  getDetailedIntentData,
  ChartDataItem,
  DetailChartDataItem
} from '@/utils/feedbackCharts';

const FeedbackDashboard = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [overallStats, setOverallStats] = useState({ positive: 0, negative: 0, total: 0 });
  const [intentStats, setIntentStats] = useState<Record<string, { positive: number, negative: number }>>({});
  const [selectedIntent, setSelectedIntent] = useState<string>('all');
  const [sortMethod, setSortMethod] = useState<'alphabetical' | 'positive' | 'negative' | 'total'>('total');
  const [hasData, setHasData] = useState(true);

  useEffect(() => {
    const loadFeedbackData = async () => {
      setIsLoading(true);
      try {
        // Fetch overall feedback stats
        const stats = await getFeedbackStats();
        const totalCount = await getTotalFeedbackCount();
        setOverallStats({
          positive: stats.positive,
          negative: stats.negative,
          total: totalCount
        });
        
        // Fetch feedback stats by content intent
        const intentData = await getFeedbackByContentIntent();
        setIntentStats(intentData);
        
        // Check if we have any data
        const hasAnyData = totalCount > 0 || 
          Object.values(intentData).some(
            stat => stat.positive > 0 || stat.negative > 0
          );
        setHasData(hasAnyData);
      } catch (error) {
        console.error('Error loading feedback data:', error);
        setHasData(false);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadFeedbackData();
  }, []);

  // Get chart data based on selected intent and sort method
  const getChartData = (): ChartDataItem[] | DetailChartDataItem[] => {
    if (selectedIntent === 'all') {
      return getIntentChartData(intentStats, sortMethod);
    } else {
      return getDetailedIntentData(selectedIntent, intentStats);
    }
  };

  return (
    <div className="space-y-6">
      <AdminSectionHeader 
        title="User Feedback Analysis" 
        description="Track user satisfaction and feedback trends to guide product improvements" 
      />

      <FeedbackSummary 
        isLoading={isLoading} 
        stats={overallStats} 
      />

      <FeedbackChart 
        isLoading={isLoading}
        hasData={hasData}
        selectedIntent={selectedIntent}
        setSelectedIntent={setSelectedIntent}
        sortMethod={sortMethod}
        setSortMethod={setSortMethod}
        chartData={getChartData()}
        intentStats={intentStats}
      />
    </div>
  );
};

export default FeedbackDashboard;
