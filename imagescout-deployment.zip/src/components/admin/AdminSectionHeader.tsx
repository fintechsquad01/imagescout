
import React from 'react';
import { AdminDashboardSectionProps } from '@/types/admin-dashboard';

export interface ExtendedAdminSectionHeaderProps extends AdminDashboardSectionProps {
  icon?: React.ReactNode;
  backButton?: React.ReactNode;
}

const AdminSectionHeader: React.FC<ExtendedAdminSectionHeaderProps> = ({ 
  title, 
  description,
  icon,
  backButton
}) => {
  return (
    <div className="flex items-center justify-between mb-6">
      <div className="flex items-center gap-2">
        {icon && <div className="text-primary">{icon}</div>}
        <div>
          <h2 className="text-xl font-semibold tracking-tight">{title}</h2>
          {description && (
            <p className="text-muted-foreground text-sm mt-1">{description}</p>
          )}
        </div>
      </div>
      {backButton && (
        <div>{backButton}</div>
      )}
    </div>
  );
};

export default AdminSectionHeader;
