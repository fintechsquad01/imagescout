
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useProject } from '@/context/ProjectContext';
import { Download, RefreshCw } from 'lucide-react';
import { useScoringFeedback } from '@/hooks/useScoringFeedback';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';

const ScoringDataExport = () => {
  const { currentProject } = useProject();
  const { feedback, fetchFeedback, exportToCSV, isLoading, isExporting } = useScoringFeedback();

  const refreshData = () => {
    if (currentProject?.id) {
      fetchFeedback(currentProject.id);
    }
  };

  const handleExport = () => {
    if (currentProject?.id) {
      exportToCSV(currentProject.id);
    } else {
      exportToCSV(); // Export all data
    }
  };

  const feedbackCount = feedback.length;
  const testFeedbackCount = feedback.filter(item => item.test).length;
  const realFeedbackCount = feedbackCount - testFeedbackCount;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Scoring Feedback Data</span>
          {currentProject && (
            <Badge variant="outline" className="ml-2">
              {currentProject.name}
            </Badge>
          )}
        </CardTitle>
        <CardDescription>
          Export scoring feedback data for analysis
        </CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-5 w-32" />
            <Skeleton className="h-5 w-40" />
            <Skeleton className="h-5 w-36" />
          </div>
        ) : (
          <div className="space-y-2 text-sm">
            <p>
              <strong>Total feedback entries:</strong> {feedbackCount}
            </p>
            <p>
              <strong>Production entries:</strong> {realFeedbackCount}
            </p>
            <p>
              <strong>Test entries:</strong> {testFeedbackCount}
            </p>
            {feedbackCount === 0 && (
              <p className="italic text-muted-foreground">
                No feedback data available for this project
              </p>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          size="sm"
          onClick={refreshData}
          disabled={isLoading}
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh
        </Button>
        <Button
          onClick={handleExport}
          disabled={isExporting || feedbackCount === 0}
        >
          {isExporting ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Exporting...
            </>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Export to CSV
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ScoringDataExport;
