
import React, { useState } from 'react';
import { useUsageStats } from '@/hooks/useUsageStats';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';
import PromptTimelineChart from './usage/PromptTimelineChart';
import ModelUsageChart from './usage/ModelUsageChart';
import DateRangeSelector from './usage/DateRangeSelector';

const UsageStatistics = () => {
  const [dateRange, setDateRange] = useState(14); // Last 14 days by default
  const { dailyPrompts, modelUsage, isLoading, error } = useUsageStats(dateRange);
  
  const handleDateRangeChange = (days: number) => {
    setDateRange(days);
  };

  return (
    <div className="space-y-6">
      <DateRangeSelector selectedRange={dateRange} onRangeChange={handleDateRangeChange} />
      
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <PromptTimelineChart data={dailyPrompts} isLoading={isLoading} />
      <ModelUsageChart data={modelUsage} isLoading={isLoading} />
    </div>
  );
};

export default UsageStatistics;
