
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Lock } from 'lucide-react';

const UnauthorizedAccess = () => {
  return (
    <div className="container mx-auto py-12">
      <Card className="border-destructive/50">
        <CardContent className="pt-6 flex flex-col items-center text-center">
          <Lock className="h-12 w-12 text-destructive mb-4" />
          <h2 className="text-2xl font-bold tracking-tight mb-2">Unauthorized Access</h2>
          <p className="text-muted-foreground max-w-md">
            You don't have permission to access the admin dashboard. This area is restricted to internal and admin users only.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default UnauthorizedAccess;
