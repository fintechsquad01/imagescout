
import React, { useState, useEffect } from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { getSupabaseClient } from '@/lib/supabaseLogger';
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth';
import { toast } from '@/hooks/use-toast';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';

interface InviteCode {
  id: string;
  code: string;
  description: string;
  max_uses: number;
  uses: number;
  expires_at: string | null;
  created_at: string;
  is_active: boolean;
}

const inviteFormSchema = z.object({
  code: z.string().min(6, "Code must be at least 6 characters").optional(),
  description: z.string().optional(),
  max_uses: z.coerce.number().int().min(1, "Must allow at least 1 use").default(1),
});

type InviteFormValues = z.infer<typeof inviteFormSchema>;

const InviteCodesManager: React.FC = () => {
  const [inviteCodes, setInviteCodes] = useState<InviteCode[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { userId } = useSupabaseAuth();
  const { isFeatureEnabled } = useFeatureFlags();
  
  const form = useForm<InviteFormValues>({
    resolver: zodResolver(inviteFormSchema),
    defaultValues: {
      max_uses: 1,
    },
  });
  
  useEffect(() => {
    // Only load if invite system feature is enabled
    if (isFeatureEnabled('invite_system')) {
      fetchInviteCodes();
    } else {
      setIsLoading(false);
    }
  }, [isFeatureEnabled]);
  
  const fetchInviteCodes = async () => {
    try {
      setIsLoading(true);
      const supabase = getSupabaseClient();
      
      const { data, error } = await supabase
        .from('invite_codes')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (error) {
        console.error('Error fetching invite codes:', error);
        return;
      }
      
      setInviteCodes(data || []);
    } catch (err) {
      console.error('Error in fetchInviteCodes:', err);
    } finally {
      setIsLoading(false);
    }
  };
  
  const generateRandomCode = () => {
    const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Removed confusing chars like 0, O, 1, I
    const codeLength = 8;
    let result = '';
    
    for (let i = 0; i < codeLength; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    
    form.setValue('code', result);
  };
  
  const onSubmit = async (values: InviteFormValues) => {
    if (!isFeatureEnabled('invite_system')) {
      toast({
        title: "Feature Not Enabled",
        description: "The invite system feature is not enabled for your account.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      const supabase = getSupabaseClient();
      
      // Generate a random code if none provided
      const inviteCode = values.code || form.getValues('code');
      
      if (!inviteCode) {
        toast({
          title: "Error",
          description: "Please provide an invite code or generate one.",
          variant: "destructive",
        });
        return;
      }
      
      const { data, error } = await supabase
        .from('invite_codes')
        .insert({
          code: inviteCode,
          description: values.description || null,
          max_uses: values.max_uses,
          created_by: userId,
        })
        .select();
        
      if (error) {
        console.error('Error creating invite code:', error);
        
        // Check for unique constraint violation
        if (error.code === '23505') {
          toast({
            title: "Duplicate Code",
            description: "This invite code already exists. Please try another.",
            variant: "destructive",
          });
        } else {
          toast({
            title: "Error",
            description: "Failed to create invite code.",
            variant: "destructive",
          });
        }
        return;
      }
      
      toast({
        title: "Success",
        description: "New invite code created successfully.",
      });
      
      // Reset form
      form.reset();
      
      // Refresh the list
      fetchInviteCodes();
    } catch (err) {
      console.error('Error in createInviteCode:', err);
      toast({
        title: "Error",
        description: "An unexpected error occurred.",
        variant: "destructive",
      });
    }
  };
  
  // Skip rendering if user doesn't have access
  if (!isFeatureEnabled('invite_system')) {
    return null;
  }
  
  return (
    <Card className="p-6">
      <h3 className="text-lg font-medium mb-4">Invite Codes Manager</h3>
      
      <div className="space-y-6">
        <div>
          <h4 className="text-sm font-medium mb-2">Create New Invite Code</h4>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="flex gap-2">
                <FormField
                  control={form.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel>Code</FormLabel>
                      <div className="flex space-x-2">
                        <FormControl>
                          <Input {...field} placeholder="Enter or generate code" />
                        </FormControl>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={generateRandomCode}
                        >
                          Generate
                        </Button>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="max_uses"
                  render={({ field }) => (
                    <FormItem className="w-32">
                      <FormLabel>Max Uses</FormLabel>
                      <FormControl>
                        <Input {...field} type="number" min="1" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Optional description or purpose" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button type="submit">Create Invite Code</Button>
            </form>
          </Form>
        </div>
        
        <div>
          <h4 className="text-sm font-medium mb-2">Active Invite Codes</h4>
          {isLoading ? (
            <div className="text-center py-4 text-muted-foreground">Loading...</div>
          ) : inviteCodes.length > 0 ? (
            <div className="border rounded-md">
              <div className="grid grid-cols-6 gap-4 p-3 bg-muted text-xs font-medium">
                <div>Code</div>
                <div className="col-span-2">Description</div>
                <div>Uses</div>
                <div>Created</div>
                <div>Status</div>
              </div>
              <div className="divide-y">
                {inviteCodes.map((invite) => (
                  <div key={invite.id} className="grid grid-cols-6 gap-4 p-3 text-sm">
                    <div className="font-mono">{invite.code}</div>
                    <div className="col-span-2 truncate">{invite.description || "—"}</div>
                    <div>{invite.uses}/{invite.max_uses}</div>
                    <div>{new Date(invite.created_at).toLocaleDateString()}</div>
                    <div>
                      <span 
                        className={`inline-flex items-center rounded-full px-2 py-1 text-xs ${
                          invite.is_active 
                            ? 'bg-green-100 text-green-700' 
                            : 'bg-red-100 text-red-700'
                        }`}
                      >
                        {invite.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-4 text-muted-foreground">
              No invite codes found. Create your first one above.
            </div>
          )}
        </div>
      </div>
    </Card>
  );
};

export default InviteCodesManager;
