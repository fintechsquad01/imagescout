
import React from "react";
import {
  BarChart2,
  Book,
  Code,
  Home,
  Image,
  LayoutDashboard,
  MessageSquare,
  Settings,
  User,
  Users,
  Database
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";

import { useToast } from "@/components/ui/use-toast";
import { useRoleCheck } from "@/hooks/useRoleCheck";
import { Skeleton } from "@/components/ui/skeleton";
import { isDevelopmentMode } from "@/utils/devMode";

interface AdminSidebarProps {
  activeSection?: string;
}

const AdminSidebar: React.FC<AdminSidebarProps> = ({ activeSection = 'overview' }) => {
  const { toast } = useToast();
  const { isAuthorized, isLoading } = useRoleCheck(["admin", "internal"]);
  const location = useLocation();

  // Map routes to sections for automatic highlighting
  const routeToSectionMap: Record<string, string> = {
    "/admin": "overview",
    "/admin/users": "overview",
    "/admin/feedback": "feedback",
    "/admin/scoring-analytics": "advanced",
    "/admin/scoring-logs": "usage",
    "/admin/test-scoring": "advanced",
    "/admin/content": "content",
  };

  // Determine active section based on current route if not explicitly provided
  const currentSection = activeSection || routeToSectionMap[location.pathname] || 'overview';

  const navigation = [
    { name: "Dashboard", href: "/admin", icon: LayoutDashboard, section: "overview" },
    { name: "Users", href: "/admin/users", icon: Users, section: "overview" },
    { name: "Feedback", href: "/admin/feedback", icon: MessageSquare, section: "feedback" },
    { name: "Scoring Analytics", href: "/admin/scoring-analytics", icon: BarChart2, section: "advanced" },
    { name: "Scoring Logs", href: "/admin/scoring-logs", icon: Database, section: "usage" },
    { name: "Test Scoring", href: "/admin/test-scoring", icon: Code, section: "advanced", devOnly: true },
    { name: "Content", href: "/admin/content", icon: Book, section: "content" },
  ];

  return (
    <div className="flex flex-col h-full bg-card py-4 w-64">
      <div className="px-4 mb-4">
        <h1 className="text-lg font-semibold">Admin Panel</h1>
      </div>
      <nav className="flex-1 px-2 space-y-1">
        {isLoading ? (
          <>
            <Skeleton className="w-full h-8 rounded-md" />
            <Skeleton className="w-full h-8 rounded-md" />
            <Skeleton className="w-full h-8 rounded-md" />
            <Skeleton className="w-full h-8 rounded-md" />
          </>
        ) : isAuthorized || isDevelopmentMode() ? (
          navigation
            .filter(item => !item.devOnly || isDevelopmentMode())
            .map((item) => (
              <NavLink
                key={item.name}
                to={item.href}
                className={({ isActive }) =>
                  `flex items-center px-3 py-2 text-sm font-medium rounded-md
                  ${
                    isActive || currentSection === item.section
                      ? "bg-accent text-accent-foreground"
                      : "text-foreground hover:bg-accent/50 hover:text-accent-foreground"
                  }`
                }
              >
                <item.icon className="w-4 h-4 mr-2" />
                {item.name}
                {item.devOnly && isDevelopmentMode() && (
                  <span className="ml-2 px-1.5 py-0.5 text-xs rounded-sm bg-amber-200 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                    Dev
                  </span>
                )}
              </NavLink>
            ))
        ) : (
          <div className="text-center text-muted-foreground">
            Not authorized to view admin pages.
          </div>
        )}
      </nav>
    </div>
  );
};

export default AdminSidebar;
