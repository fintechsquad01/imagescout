
import React, { useState, useEffect } from 'react';
import { cn } from "@/lib/utils";
import { Sparkles, ToggleLeft, ToggleRight, Beaker, BarChart } from "lucide-react";
import { useSupabaseLogger } from '@/hooks/useSupabaseLogger';
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth';
import ProjectSelector from '@/components/ProjectSelector';
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import UsageDisplay from '@/components/usage/UsageDisplay';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';

interface HeaderProps {
  className?: string;
  onToggleExperimentalMode?: (enabled: boolean) => void;
}

const Header: React.FC<HeaderProps> = ({ 
  className,
  onToggleExperimentalMode
}) => {
  // Make sure we're destructuring the correct properties with fallbacks
  const logger = useSupabaseLogger();
  const remainingUploads = logger.remainingUploads || 0;
  const maxDailyUploads = logger.maxDailyUploads || 10;
  
  const { isAuthenticated } = useSupabaseAuth();
  const { isFeatureEnabled } = useFeatureFlags();
  const [experimentalMode, setExperimentalMode] = useState(false);
  const [showUsageStats, setShowUsageStats] = useState(false);
  
  // Load experimental mode preference from localStorage on mount
  useEffect(() => {
    const savedMode = localStorage.getItem('experimentalMode') === 'true';
    setExperimentalMode(savedMode);
    if (onToggleExperimentalMode) {
      onToggleExperimentalMode(savedMode);
    }
  }, [onToggleExperimentalMode]);
  
  const toggleExperimentalMode = () => {
    const newMode = !experimentalMode;
    setExperimentalMode(newMode);
    if (onToggleExperimentalMode) {
      onToggleExperimentalMode(newMode);
    }
    
    // Save preference to localStorage
    localStorage.setItem('experimentalMode', newMode ? 'true' : 'false');
  };
  
  // Calculate usage percentage
  const usagePercentage = maxDailyUploads > 0 
    ? Math.max(0, Math.min(100, 100 * (1 - remainingUploads / maxDailyUploads)))
    : 0;
  
  return (
    <header className={cn(
      "w-full py-6 px-6 flex items-center justify-between bg-transparent z-10",
      className
    )}>
      <div className="flex items-center gap-2 animate-fade-in">
        <Sparkles className="h-6 w-6 text-primary" />
        <h1 className="text-xl font-medium tracking-tight">
          <span className="font-semibold">AI</span> Content Repurposing Studio
        </h1>
      </div>
      
      <div className="flex items-center gap-4">
        {/* Experimental Mode Toggle - Only shown for internal users */}
        {isFeatureEnabled && isFeatureEnabled('experimental_mode') && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                className="gap-2"
                onClick={toggleExperimentalMode}
              >
                <Beaker className="h-4 w-4 text-amber-500" />
                {experimentalMode ? (
                  <ToggleRight className="h-4 w-4 text-green-500" />
                ) : (
                  <ToggleLeft className="h-4 w-4 text-muted-foreground" />
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Toggle Experimental Features</p>
            </TooltipContent>
          </Tooltip>
        )}
        
        {/* Usage Stats Button */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 h-9"
              onClick={() => setShowUsageStats(!showUsageStats)}
            >
              <div className="hidden md:flex items-center gap-2">
                <div className="w-32 h-2 bg-secondary/50 rounded-full overflow-hidden">
                  <div 
                    className={cn(
                      "h-full rounded-full", 
                      usagePercentage > 80 ? "bg-red-500" : 
                      usagePercentage > 60 ? "bg-amber-500" : 
                      "bg-green-500"
                    )}
                    style={{ width: `${usagePercentage}%` }}
                  />
                </div>
                <span className="text-sm text-muted-foreground">
                  {remainingUploads}/{maxDailyUploads}
                </span>
              </div>
              <BarChart className="h-4 w-4 md:hidden" />
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Daily upload usage</p>
          </TooltipContent>
        </Tooltip>
        
        <ProjectSelector />
      </div>
      
      {/* Usage Stats Panel */}
      {showUsageStats && (
        <UsageDisplay 
          isOpen={showUsageStats}
          onClose={() => setShowUsageStats(false)}
        />
      )}
    </header>
  );
};

export default Header;
