
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { getSupabaseClient } from '@/lib/supabaseLogger';
import { toast } from '@/hooks/use-toast';
import { Link } from 'react-router-dom';
import { useRoleCheck } from '@/hooks/useRoleCheck';
import { ExternalLink } from 'lucide-react';

const inviteCodeSchema = z.object({
  code: z.string().min(6, "Invite code must be at least 6 characters"),
});

type InviteCodeFormValues = z.infer<typeof inviteCodeSchema>;

interface InviteCodeEntryProps {
  onSuccess: () => void;
}

const InviteCodeEntry: React.FC<InviteCodeEntryProps> = ({ onSuccess }) => {
  const [isValidating, setIsValidating] = useState(false);
  const { isAuthorized: isAdminOrInternal } = useRoleCheck(['admin', 'internal']);
  
  const form = useForm<InviteCodeFormValues>({
    resolver: zodResolver(inviteCodeSchema),
    defaultValues: {
      code: localStorage.getItem('invite_code') || "",
    },
  });
  
  const onSubmit = async (values: InviteCodeFormValues) => {
    setIsValidating(true);
    
    try {
      const supabase = getSupabaseClient();
      
      // Call the validate_invite_code function in Supabase
      const { data, error } = await supabase
        .rpc('validate_invite_code', { code_to_validate: values.code });
        
      if (error) {
        toast({
          title: "Error",
          description: "Could not validate invite code. Please try again.",
          variant: "destructive",
        });
        console.error('Error validating invite code:', error);
        return;
      }
      
      if (data) {
        // Successfully validated code
        toast({
          title: "Success",
          description: "Invite code accepted. Welcome to the beta!",
        });
        
        // Store the invite code in user_onboarding table
        const { data: user } = await supabase.auth.getUser();
        if (user && user.user) {
          await supabase
            .from('user_onboarding')
            .upsert({
              user_id: user.user.id,
              invite_code: values.code,
              updated_at: new Date().toISOString()
            });
        }
        
        // Clear from localStorage since it's now saved in the database
        localStorage.removeItem('invite_code');
        
        onSuccess();
      } else {
        toast({
          title: "Invalid Invite Code",
          description: "This code is invalid, expired, or has already been used.",
          variant: "destructive",
        });
      }
    } catch (err) {
      console.error('Error in invite code validation:', err);
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsValidating(false);
    }
  };
  
  return (
    <div className="w-full max-w-md mx-auto">
      <div className="space-y-2 text-center mb-6">
        <h2 className="text-2xl font-bold">Enter Your Invite Code</h2>
        <p className="text-muted-foreground">
          This app is currently in beta. Please enter your invite code to continue.
        </p>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="code"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Invite Code</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    placeholder="Enter your invite code"
                    disabled={isValidating}
                    autoComplete="off"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button 
            type="submit" 
            className="w-full" 
            disabled={isValidating}
          >
            {isValidating ? "Validating..." : "Continue"}
          </Button>
        </form>
      </Form>
      
      {isAdminOrInternal && (
        <div className="mt-6 text-center">
          <Link 
            to="/admin" 
            className="text-sm text-primary hover:underline inline-flex items-center"
          >
            Admin Dashboard <ExternalLink className="ml-1 h-3 w-3" />
          </Link>
        </div>
      )}
    </div>
  );
};

export default InviteCodeEntry;
