
import React, { useState, useEffect } from 'react';
import { X, ArrowRight, Upload, Wand2, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth';
import { getSupabaseClient } from '@/lib/supabaseLogger';

interface OnboardingStep {
  title: string;
  description: string;
  icon: React.ReactNode;
}

interface OnboardingOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

const OnboardingOverlay: React.FC<OnboardingOverlayProps> = ({
  isOpen,
  onClose
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const { userId } = useSupabaseAuth();
  
  const onboardingSteps: OnboardingStep[] = [
    {
      title: "Upload Images",
      description: "Start by uploading images you want to repurpose. Our AI will analyze them and provide content suggestions.",
      icon: <Upload className="h-6 w-6 text-primary" />
    },
    {
      title: "Generate Content",
      description: "Choose your content intent and writing tone. Our AI will generate tailored content based on your preferences.",
      icon: <Wand2 className="h-6 w-6 text-primary" />
    },
    {
      title: "Provide Feedback",
      description: "Help us improve by rating the generated content. Your feedback makes our AI smarter.",
      icon: <MessageSquare className="h-6 w-6 text-primary" />
    }
  ];
  
  const handleNextStep = () => {
    if (currentStep < onboardingSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      completeOnboarding();
    }
  };
  
  const completeOnboarding = async () => {
    if (userId) {
      try {
        const supabase = getSupabaseClient();
        await supabase
          .from('user_onboarding')
          .upsert({
            user_id: userId,
            onboarding_completed: true,
            updated_at: new Date().toISOString()
          });
      } catch (error) {
        console.error('Error updating onboarding status:', error);
      }
    }
    
    onClose();
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />
      
      <div className="bg-card border rounded-xl shadow-2xl w-full max-w-md p-6 z-10 animate-in fade-in slide-in-from-bottom-10 duration-300">
        <div className="absolute top-4 right-4">
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={onClose}>
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </Button>
        </div>
        
        <div className="flex justify-center mb-6">
          <div className="flex space-x-2">
            {onboardingSteps.map((_, index) => (
              <div 
                key={index}
                className={`h-2 w-${index === currentStep ? '8' : '2'} rounded-full ${
                  index === currentStep ? 'bg-primary' : 
                  index < currentStep ? 'bg-primary/50' : 'bg-secondary'
                }`}
              />
            ))}
          </div>
        </div>
        
        <div className="text-center mb-8">
          <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            {onboardingSteps[currentStep].icon}
          </div>
          <h2 className="text-xl font-bold mb-2">{onboardingSteps[currentStep].title}</h2>
          <p className="text-muted-foreground">{onboardingSteps[currentStep].description}</p>
        </div>
        
        <div className="flex justify-between">
          <Button 
            variant="ghost" 
            onClick={onClose}
          >
            Skip
          </Button>
          <Button 
            onClick={handleNextStep}
            className="gap-2"
          >
            {currentStep < onboardingSteps.length - 1 ? 'Next' : 'Get Started'}
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default OnboardingOverlay;
