
import React from 'react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Button } from '@/components/ui/button';
import { HelpCircle, ChevronDown } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { ScoredImage } from '@/types/scoring';
import { ScoringConfig, DEFAULT_SCORING_CONFIG } from '@/types/scoring-config';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Skeleton } from "@/components/ui/skeleton";

interface ScoreExplanationPanelProps {
  image: ScoredImage | null;
  scoringConfig?: ScoringConfig;
  className?: string;
  isLoading?: boolean;
}

const ScoreExplanationPanel: React.FC<ScoreExplanationPanelProps> = ({ 
  image, 
  scoringConfig,
  className,
  isLoading = false
}) => {
  // Handle all potential undefined cases with fallbacks
  if (isLoading) {
    return (
      <div className={`mt-4 border rounded-md ${className}`}>
        <Skeleton className="h-12 w-full rounded-t-md" />
        <div className="p-4">
          <Skeleton className="h-4 w-3/4 mb-3" />
          <div className="space-y-2">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex justify-between">
                <Skeleton className="h-4 w-1/3" />
                <Skeleton className="h-4 w-16" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Guard against missing data
  if (!image?.visionData || !scoringConfig) {
    return null;
  }

  // Use provided config or fall back to default
  const config = scoringConfig || DEFAULT_SCORING_CONFIG;

  // Calculate individual score components with null/undefined guards
  const baseScore = config.weights.baseScore || 0;
  const labelScore = Math.min(((image.visionData.labels?.length ?? 0) * config.weights.labels), 25);
  const objectScore = Math.min(((image.visionData.objects?.length ?? 0) * config.weights.objects), 20);
  const landmarkScore = ((image.visionData.landmarks?.length ?? 0) * config.weights.landmarks);
  const colorScore = Math.min(((image.visionData.colors?.length ?? 0) * config.weights.colors), 15);

  const factorContributions = [
    { name: 'Base Score', value: baseScore, description: 'Starting value for all images' },
    { name: 'Labels', value: labelScore, description: `Based on ${image.visionData.labels?.length || 0} detected labels` },
    { name: 'Objects', value: objectScore, description: `Based on ${image.visionData.objects?.length || 0} detected objects` },
    { name: 'Landmarks', value: landmarkScore, description: `Based on ${image.visionData.landmarks?.length || 0} detected landmarks` },
    { name: 'Colors', value: colorScore, description: `Based on ${image.visionData.colors?.length || 0} detected colors` }
  ];

  // Sort by contribution value (highest first)
  factorContributions.sort((a, b) => b.value - a.value);

  return (
    <Collapsible className={`mt-4 border rounded-md ${className}`}>
      <CollapsibleTrigger asChild>
        <Button variant="ghost" className="flex w-full justify-between items-center p-4">
          <div className="flex items-center">
            <HelpCircle className="h-4 w-4 mr-2" />
            <span>Why this score?</span>
          </div>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </Button>
      </CollapsibleTrigger>
      <CollapsibleContent className="p-4 pt-0">
        <p className="text-sm text-muted-foreground mb-3">
          This score is calculated based on multiple factors using the {config.model} model:
        </p>
        <div className="space-y-2">
          {factorContributions.map((factor, index) => (
            <div 
              key={index} 
              className="flex items-center justify-between text-sm"
            >
              <div className="flex items-center">
                <span className="font-medium">{factor.name}:</span>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="ml-1 cursor-help">
                        <HelpCircle className="h-3 w-3 text-muted-foreground" />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs max-w-60">{factor.description}</p>
                      <p className="text-xs max-w-60">Weight: {config.weights[factor.name.toLowerCase().replace(' ', '')] || 'N/A'}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>
              <div>
                <Badge variant={factor.value > 0 ? "outline" : "secondary"}>
                  +{factor.value}
                </Badge>
              </div>
            </div>
          ))}
          <div className="border-t pt-2 mt-2 flex items-center justify-between font-medium">
            <span>Total Score:</span>
            <Badge className="bg-primary">{image.opportunityScore || image.score || 0}</Badge>
          </div>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
};

export default ScoreExplanationPanel;
