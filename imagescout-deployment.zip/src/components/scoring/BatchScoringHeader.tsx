
import React from 'react';
import { Button } from "@/components/ui/button";
import { Loader2, RefreshCw } from "lucide-react";
import { ImageFile } from '@/types/scoring';

interface BatchScoringHeaderProps {
  uploadedImages: ImageFile[];
  isScoring: boolean;
  onClearBatch: () => void;
  onStartScoring: () => void;
  modelId: string;
}

const BatchScoringHeader: React.FC<BatchScoringHeaderProps> = ({
  uploadedImages,
  isScoring,
  onClearBatch,
  onStartScoring,
  modelId
}) => {
  return (
    <div className="flex justify-between items-center">
      <div>
        <h3 className="text-sm font-medium">
          {uploadedImages.length} image{uploadedImages.length !== 1 ? 's' : ''} ready
        </h3>
        <p className="text-xs text-muted-foreground">
          Using model: {modelId}
        </p>
      </div>
      <div className="space-x-2">
        <Button 
          variant="outline" 
          size="sm"
          onClick={onClearBatch}
          disabled={isScoring}
        >
          Clear Batch
        </Button>
        <Button 
          size="sm"
          onClick={onStartScoring}
          disabled={isScoring || uploadedImages.length === 0}
        >
          {isScoring ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4 mr-2" />
              Start Scoring
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default BatchScoringHeader;
