import React, { useState, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useRenderNet } from '@/hooks/useRenderNet';
import { useToast } from '@/components/ui/use-toast';
import { ImageFile, BatchScoringResult, mapResponseToScoringResult } from '@/types/scoring';
import BatchImageUploader from './BatchImageUploader';
import BatchScoringResultTable from './BatchScoringResultTable';
import BatchScoringProgress from './BatchScoringProgress';
import BatchScoringError from './BatchScoringError';
import BatchScoringHeader from './BatchScoringHeader';

interface BatchScoringProps {
  modelId: string;
  prompt: string;
  skipCache?: boolean;
}

const BatchScoring: React.FC<BatchScoringProps> = ({ 
  modelId, 
  prompt,
  skipCache = false
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedImages, setUploadedImages] = useState<ImageFile[]>([]);
  const [results, setResults] = useState<BatchScoringResult[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isScoring, setIsScoring] = useState(false);
  const { toast } = useToast();
  
  const { generateContent } = useRenderNet('batch-scoring');
  
  const handleImagesSelected = useCallback((images: ImageFile[]) => {
    if (images.length === 0) return;
    
    const initialResults = images.map(img => ({
      id: img.id,
      filename: img.name,
      model: modelId,
      score: null,
      status: 'pending' as const,
      cached: false
    }));
    
    setUploadedImages(images);
    setResults(initialResults);
    
    toast({
      title: "Images uploaded",
      description: `${images.length} images ready for batch scoring.`
    });
  }, [modelId, toast]);
  
  const processNextImage = useCallback(async () => {
    if (currentIndex >= uploadedImages.length) {
      setIsScoring(false);
      return;
    }
    
    const currentImage = uploadedImages[currentIndex];
    
    try {
      setResults(prev => prev.map((result, idx) => 
        idx === currentIndex ? { ...result, status: 'pending' } : result
      ));
      
      const response = await generateContent(prompt, modelId, {
        model: modelId,
        skipCache: skipCache,
        imageId: currentImage.id
      });
      
      const scoringResult = mapResponseToScoringResult(response, currentImage.name);
      
      setResults(prev => prev.map((result, idx) => 
        idx === currentIndex ? scoringResult : result
      ));
    } catch (error) {
      console.error(`Error processing image ${currentImage.name}:`, error);
      
      setResults(prev => prev.map((result, idx) => 
        idx === currentIndex ? {
          ...result,
          status: 'error',
          error: error instanceof Error ? error.message : 'Unknown error'
        } : result
      ));
    }
    
    setCurrentIndex(prev => prev + 1);
  }, [currentIndex, uploadedImages, generateContent, prompt, modelId, skipCache]);
  
  const startBatchScoring = useCallback(async () => {
    if (uploadedImages.length === 0) {
      toast({
        title: "No files selected",
        description: "Please upload images before starting batch scoring.",
        variant: "destructive"
      });
      return;
    }
    
    setIsScoring(true);
    setCurrentIndex(0);
    
    processNextImage();
  }, [uploadedImages, toast, processNextImage]);
  
  useEffect(() => {
    if (isScoring && currentIndex < uploadedImages.length) {
      processNextImage();
    } else if (isScoring && currentIndex >= uploadedImages.length) {
      setIsScoring(false);
      toast({
        title: "Batch scoring complete",
        description: `Processed ${uploadedImages.length} images.`
      });
    }
  }, [currentIndex, isScoring, uploadedImages.length, processNextImage, toast]);
  
  const clearBatch = useCallback(() => {
    setUploadedImages([]);
    setResults([]);
    setCurrentIndex(0);
    setIsScoring(false);
  }, []);
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Batch Image Scoring</CardTitle>
        <CardDescription>
          Upload multiple images to score them with the selected model and prompt
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {uploadedImages.length === 0 ? (
          <BatchImageUploader 
            onImagesSelected={handleImagesSelected}
            isUploading={isUploading}
            maxImages={10}
          />
        ) : (
          <>
            <BatchScoringHeader
              uploadedImages={uploadedImages}
              isScoring={isScoring}
              onClearBatch={clearBatch}
              onStartScoring={startBatchScoring}
              modelId={modelId}
            />
            
            <BatchScoringProgress
              currentIndex={currentIndex}
              totalCount={uploadedImages.length}
              isScoring={isScoring}
            />
            
            <BatchScoringResultTable results={results} />
            
            <BatchScoringError results={results} />
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default BatchScoring;
