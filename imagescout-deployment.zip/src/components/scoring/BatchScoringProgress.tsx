
import React from 'react';
import { Progress } from "@/components/ui/progress";

interface BatchScoringProgressProps {
  currentIndex: number;
  totalCount: number;
  isScoring: boolean;
}

const BatchScoringProgress: React.FC<BatchScoringProgressProps> = ({ 
  currentIndex, 
  totalCount, 
  isScoring 
}) => {
  // Don't render if not scoring or no images to process
  if (!isScoring || totalCount === 0) {
    return null;
  }
  
  const progressPercentage = totalCount > 0
    ? (currentIndex / totalCount) * 100
    : 0;
  
  return (
    <div className="space-y-2">
      <div className="flex justify-between text-xs">
        <span>Processing image {currentIndex + 1} of {totalCount}</span>
        <span>{Math.round(progressPercentage)}%</span>
      </div>
      <Progress value={progressPercentage} className="h-2" />
    </div>
  );
};

export default BatchScoringProgress;
