
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Check, X, Loader2, Database } from "lucide-react";
import { BatchScoringResult } from '@/types/scoring';

interface BatchScoringResultTableProps {
  results: BatchScoringResult[];
}

const BatchScoringResultTable: React.FC<BatchScoringResultTableProps> = ({ results }) => {
  if (!results || results.length === 0) {
    return (
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Filename</TableHead>
              <TableHead>Model</TableHead>
              <TableHead>Score</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Cache</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell colSpan={5} className="text-center py-6 text-muted-foreground">
                No results yet. Start scoring to see results.
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </div>
    );
  }
  
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Filename</TableHead>
            <TableHead>Model</TableHead>
            <TableHead>Score</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Cache</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {results.map((result) => (
            <TableRow key={result.id}>
              <TableCell className="font-medium truncate max-w-[200px]">
                {result.filename}
              </TableCell>
              <TableCell>{result.model}</TableCell>
              <TableCell>
                {result.score !== null ? result.score : '-'}
              </TableCell>
              <TableCell>
                {result.status === 'success' && (
                  <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-200 flex items-center w-fit">
                    <Check className="h-3 w-3 mr-1" />
                    Success
                  </Badge>
                )}
                {result.status === 'error' && (
                  <Badge variant="destructive" className="flex items-center w-fit">
                    <X className="h-3 w-3 mr-1" />
                    Error
                  </Badge>
                )}
                {result.status === 'pending' && (
                  <Badge variant="outline" className="flex items-center w-fit">
                    <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                    Pending
                  </Badge>
                )}
              </TableCell>
              <TableCell>
                {result.cached ? (
                  <Badge variant="secondary" className="flex items-center w-fit">
                    <Database className="h-3 w-3 mr-1" />
                    Cached
                  </Badge>
                ) : (
                  <Badge variant="outline" className="text-muted-foreground flex items-center w-fit">
                    Fresh
                  </Badge>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default BatchScoringResultTable;
