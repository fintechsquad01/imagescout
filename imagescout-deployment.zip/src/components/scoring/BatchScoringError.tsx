
import React from 'react';
import { Alert, AlertDescription } from "@/components/ui/alert";
import { BatchScoringResult } from '@/types/scoring';

interface BatchScoringErrorProps {
  results: BatchScoringResult[];
}

const BatchScoringError: React.FC<BatchScoringErrorProps> = ({ results }) => {
  // Only show error banner if there are any failed results
  const hasErrors = Array.isArray(results) && results.some(r => r.status === 'error');
  
  if (!hasErrors) {
    return null;
  }
  
  return (
    <Alert variant="destructive">
      <AlertDescription>
        Some images failed to process. Check the status column for details.
      </AlertDescription>
    </Alert>
  );
};

export default BatchScoringError;
