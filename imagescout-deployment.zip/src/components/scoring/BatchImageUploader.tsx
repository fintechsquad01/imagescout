
import React, { useCallback, useState } from 'react';
import { cn } from "@/lib/utils";
import { Upload, Image as ImageIcon, Loader2, X, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/use-toast";
import { ImageFile } from '@/types/scoring';
import { ScrollArea } from "@/components/ui/scroll-area";
import { useProject } from '@/context/ProjectContext';

interface BatchImageUploaderProps {
  onImagesSelected: (images: ImageFile[]) => void;
  isUploading?: boolean;
  maxImages?: number;
  className?: string;
}

const BatchImageUploader: React.FC<BatchImageUploaderProps> = ({
  onImagesSelected,
  isUploading = false,
  maxImages = 10,
  className
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<ImageFile[]>([]);
  const { currentProject } = useProject();
  
  const validateFiles = (files: File[]): File[] => {
    return files.filter(file => {
      // Check if it's an image
      if (!file.type.startsWith('image/')) {
        toast({
          variant: "destructive",
          title: "Invalid file type",
          description: `${file.name} is not an image file.`
        });
        return false;
      }
      
      // Check file size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          variant: "destructive",
          title: "File too large",
          description: `${file.name} exceeds the 5MB limit.`
        });
        return false;
      }
      
      return true;
    });
  };
  
  const processFiles = (fileList: FileList | null) => {
    if (!fileList?.length) return;
    
    if (!currentProject) {
      toast({
        variant: "destructive",
        title: "No project selected",
        description: "Please select or create a project first"
      });
      return;
    }
    
    const filesArray = Array.from(fileList);
    
    // Validate files
    const validFiles = validateFiles(filesArray);
    
    // Check if adding these would exceed the limit
    if (selectedFiles.length + validFiles.length > maxImages) {
      toast({
        variant: "destructive",
        title: "Too many files",
        description: `You can only upload a maximum of ${maxImages} images at once.`
      });
      
      // Only take as many as we can accommodate
      const remaining = maxImages - selectedFiles.length;
      if (remaining > 0) {
        validFiles.splice(remaining);
      } else {
        return;
      }
    }
    
    if (validFiles.length === 0) return;
    
    // Convert to ImageFile objects
    const newImageFiles = validFiles.map(file => 
      Object.assign(file, {
        preview: URL.createObjectURL(file),
        id: `${file.name}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`
      })
    ) as ImageFile[];
    
    setSelectedFiles(prev => [...prev, ...newImageFiles]);
  };
  
  const handleFileChange = useCallback((files: FileList | null) => {
    processFiles(files);
  }, []);
  
  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);
  
  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);
  
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files) {
      processFiles(e.dataTransfer.files);
    }
  }, []);
  
  const handleRemoveFile = (id: string) => {
    setSelectedFiles(prev => {
      const file = prev.find(f => f.id === id);
      if (file?.preview) {
        URL.revokeObjectURL(file.preview);
      }
      return prev.filter(f => f.id !== id);
    });
  };
  
  const handleUpload = () => {
    if (selectedFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select at least one image to upload.",
        variant: "destructive"
      });
      return;
    }
    
    onImagesSelected(selectedFiles);
  };
  
  const handleClearAll = () => {
    // Revoke all object URLs to prevent memory leaks
    selectedFiles.forEach(file => {
      if (file.preview) {
        URL.revokeObjectURL(file.preview);
      }
    });
    setSelectedFiles([]);
  };
  
  return (
    <div className="space-y-4">
      <div 
        className={cn(
          "flex flex-col items-center justify-center p-6 transition-all duration-300 ease-in-out",
          "border-2 border-dashed rounded-lg gap-3",
          isDragging 
            ? "border-primary bg-primary/5" 
            : "border-border bg-secondary/50",
          "shadow-sm", 
          className
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
          <Upload className="h-6 w-6 text-primary" />
        </div>
        
        <div className="text-center">
          <h3 className="text-base font-medium mb-1">Upload Multiple Images</h3>
          <p className="text-muted-foreground text-sm">
            Drag and drop images here or click to browse
          </p>
        </div>
        
        <Button 
          variant="secondary" 
          onClick={() => {
            if (!currentProject) {
              toast({
                variant: "destructive",
                title: "No project selected",
                description: "Please select or create a project first"
              });
              return;
            }
            
            const input = document.createElement('input');
            input.type = 'file';
            input.multiple = true;
            input.accept = 'image/*';
            input.onchange = (e) => handleFileChange((e.target as HTMLInputElement).files);
            input.click();
          }}
          className="flex gap-2"
          disabled={isUploading || !currentProject}
          size="sm"
        >
          {isUploading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Uploading...
            </>
          ) : (
            <>
              <ImageIcon className="h-4 w-4" />
              Select Images
            </>
          )}
        </Button>
        
        <div className="text-xs text-muted-foreground mt-2">
          Supported formats: JPG, PNG, GIF (max {maxImages} images, 5MB each)
        </div>
      </div>
      
      {selectedFiles.length > 0 && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div className="text-sm font-medium">
              {selectedFiles.length} image{selectedFiles.length !== 1 ? 's' : ''} selected
            </div>
            <div className="space-x-2">
              <Button variant="outline" size="sm" onClick={handleClearAll}>
                Clear All
              </Button>
              <Button size="sm" onClick={handleUpload}>
                Start Processing
              </Button>
            </div>
          </div>
          
          <ScrollArea className="h-40 rounded-md border p-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {selectedFiles.map((file) => (
                <div 
                  key={file.id} 
                  className="relative flex items-center gap-2 p-2 rounded-md bg-muted/50 border group"
                >
                  <div className="h-10 w-10 shrink-0 rounded-md overflow-hidden bg-background">
                    <img
                      src={file.preview}
                      alt={file.name}
                      className="h-full w-full object-cover"
                      onLoad={() => {
                        // Add loaded class for fade-in effect
                        const target = event?.target as HTMLImageElement;
                        if (target) target.classList.add('opacity-100');
                      }}
                      style={{ opacity: 0, transition: 'opacity 0.2s' }}
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(file.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => handleRemoveFile(file.id)}
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">Remove file</span>
                  </Button>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}
    </div>
  );
};

export default BatchImageUploader;
