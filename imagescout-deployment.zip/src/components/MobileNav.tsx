
import React from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface MobileNavProps {
  showSidebar: boolean;
  setShowSidebar: (show: boolean) => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ showSidebar, setShowSidebar }) => {
  return (
    <div className="sticky top-0 z-30 flex items-center justify-between bg-background p-4 border-b md:hidden">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setShowSidebar(!showSidebar)}
        aria-label={showSidebar ? "Close menu" : "Open menu"}
      >
        {showSidebar ? (
          <X className="h-5 w-5" />
        ) : (
          <Menu className="h-5 w-5" />
        )}
      </Button>
      <div className="font-semibold">ImageScout</div>
      <div className="w-10" /> {/* Spacer to balance the layout */}
    </div>
  );
};
