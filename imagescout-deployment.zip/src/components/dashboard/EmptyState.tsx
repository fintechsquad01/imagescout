
import React from 'react';
import { UploadCloud, Image, Zap, Sparkles, FileImage, HelpCircle, ArrowRight, Lightbulb } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { motion } from 'framer-motion';
import ImageUploader from '@/components/ImageUploader';
import { ImageFile } from '@/types/types';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { useProject } from '@/context/ProjectContext';

interface EmptyStateProps {
  onImagesSelected: (images: ImageFile[]) => void;
  className?: string;
}

const EmptyState: React.FC<EmptyStateProps> = ({ onImagesSelected, className }) => {
  const { isFeatureEnabled } = useFeatureFlags();
  const { currentProject } = useProject();
  const showStripeBilling = isFeatureEnabled('enable_stripe_billing');
  
  // Animation variants
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  
  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      className={`mt-6 mx-auto max-w-2xl ${className}`}
      variants={container}
      initial="hidden"
      animate="show"
    >
      <Card className="p-8 bg-background/70 border border-border/50 backdrop-blur-sm overflow-hidden relative">
        {/* Background decorative elements */}
        <div className="absolute -top-16 -right-16 w-32 h-32 bg-primary/5 rounded-full blur-xl" />
        <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-secondary/10 rounded-full blur-xl" />
        
        <CardContent className="space-y-6 p-0 text-center relative z-10">
          <motion.div variants={item} className="flex flex-col items-center justify-center gap-4 mb-2">
            <motion.div 
              className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-1 shadow-inner"
              animate={{ 
                boxShadow: ['0 0 0 rgba(0,0,0,0)', '0 0 20px rgba(var(--primary), 0.3)', '0 0 0 rgba(0,0,0,0)']
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 3,
                repeatType: 'reverse'
              }}
            >
              <UploadCloud className="h-10 w-10 text-primary" />
            </motion.div>
            <h2 className="text-2xl font-medium bg-clip-text text-transparent bg-gradient-to-r from-foreground to-foreground/70">Get Started with ImageScout</h2>
            <p className="text-muted-foreground max-w-md">
              Upload your first image to explore your repurposing potential and get AI-powered content suggestions
            </p>
          </motion.div>
          
          {/* Onboarding Flow Visualization */}
          <motion.div variants={item} className="flex gap-3 sm:gap-4 justify-center items-center my-6 flex-wrap sm:flex-nowrap">
            <div className="w-16 h-16 rounded-full bg-secondary/20 flex items-center justify-center relative group">
              <Image className="h-7 w-7 text-primary group-hover:scale-110 transition-transform" />
              <motion.span 
                className="absolute -top-2 -right-2 bg-primary text-white w-6 h-6 rounded-full text-xs flex items-center justify-center shadow-sm"
                whileHover={{ scale: 1.1 }}
              >1</motion.span>
              <motion.div 
                className="absolute inset-0 rounded-full bg-primary/20 opacity-0 group-hover:opacity-100"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ repeat: Infinity, duration: 2 }}
              />
            </div>
            <motion.div 
              className="h-0.5 w-10 bg-border hidden sm:block"
              animate={{ 
                backgroundColor: ['hsl(var(--border))', 'hsl(var(--primary))', 'hsl(var(--border))'] 
              }}
              transition={{ repeat: Infinity, duration: 3, repeatType: 'reverse' }}
            />
            <div className="w-16 h-16 rounded-full bg-secondary/20 flex items-center justify-center relative group">
              <Zap className="h-7 w-7 text-primary group-hover:scale-110 transition-transform" />
              <motion.span 
                className="absolute -top-2 -right-2 bg-primary text-white w-6 h-6 rounded-full text-xs flex items-center justify-center shadow-sm"
                whileHover={{ scale: 1.1 }}
              >2</motion.span>
            </div>
            <motion.div 
              className="h-0.5 w-10 bg-border hidden sm:block"
              animate={{ 
                backgroundColor: ['hsl(var(--border))', 'hsl(var(--primary))', 'hsl(var(--border))'] 
              }}
              transition={{ repeat: Infinity, duration: 3, delay: 1, repeatType: 'reverse' }}
            />
            <div className="w-16 h-16 rounded-full bg-secondary/20 flex items-center justify-center relative group">
              <Sparkles className="h-7 w-7 text-primary group-hover:scale-110 transition-transform" />
              <motion.span 
                className="absolute -top-2 -right-2 bg-primary text-white w-6 h-6 rounded-full text-xs flex items-center justify-center shadow-sm"
                whileHover={{ scale: 1.1 }}
              >3</motion.span>
            </div>
          </motion.div>
          
          {/* Project Selection Reminder */}
          {!currentProject && (
            <motion.div 
              variants={item}
              className="bg-amber-50 dark:bg-amber-950/20 rounded-lg p-4 flex flex-col sm:flex-row gap-4 items-center border border-amber-200 dark:border-amber-800/30 my-4 text-amber-800 dark:text-amber-300"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 }}
            >
              <Lightbulb className="h-8 w-8 text-amber-500 shrink-0" />
              <div className="text-sm text-left space-y-2">
                <h3 className="font-medium">Project Required</h3>
                <p className="text-amber-700 dark:text-amber-400">
                  You'll need to select or create a project using the dropdown in the header before uploading images.
                </p>
              </div>
            </motion.div>
          )}
          
          {/* Upload Tips */}
          <motion.div 
            variants={item}
            className="bg-secondary/10 rounded-lg p-4 flex flex-col sm:flex-row gap-4 items-center border border-border/30 my-4"
          >
            <HelpCircle className="h-8 w-8 text-primary/70 shrink-0" />
            <div className="text-sm text-left space-y-2">
              <h3 className="font-medium">Quick Tips:</h3>
              <ul className="space-y-1.5 text-muted-foreground">
                <li className="flex items-center gap-2">
                  <FileImage className="h-4 w-4" />
                  <span>Upload up to 10 images at once</span>
                </li>
                <li className="flex items-center gap-2">
                  <UploadCloud className="h-4 w-4" />
                  <span>Drag & drop files or use the browse button</span>
                </li>
                <li className="flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  <span>Each image receives an opportunity score for social media</span>
                </li>
                {showStripeBilling && (
                  <li className="flex items-center gap-2 text-primary/90 font-medium">
                    <ArrowRight className="h-4 w-4" />
                    <span>Upgrade to Pro for higher daily upload limits</span>
                  </li>
                )}
              </ul>
            </div>
          </motion.div>
          
          {/* Enhanced Image Uploader */}
          <motion.div 
            variants={item} 
            className="mt-4"
            whileHover={{ scale: 1.02 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="relative">
                    <ImageUploader 
                      onImagesSelected={onImagesSelected} 
                      className="border-primary/30 transition-all duration-300 hover:shadow-md" 
                    />
                    <motion.div 
                      className="absolute inset-0 border-2 border-primary/40 rounded-xl pointer-events-none"
                      animate={{ 
                        opacity: [0, 0.5, 0],
                        scale: [0.98, 1.01, 0.98]
                      }}
                      transition={{ 
                        repeat: Infinity, 
                        duration: 3,
                        repeatType: 'reverse'
                      }}
                    />
                  </div>
                </TooltipTrigger>
                <TooltipContent side="bottom" className="max-w-xs">
                  <p>Upload your first image to get started!</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default EmptyState;
