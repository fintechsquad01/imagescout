import React, { useState, useEffect } from 'react';
import { Loader2, AlertTriangle } from 'lucide-react';
import ImagePreview from '@/components/ImagePreview';
import OpportunityScore from '@/components/OpportunityScore';
import ContentSuggestions from '@/components/ContentSuggestions';
import GenerationPanel from '@/components/GenerationPanel';
import DevScoringControls from '@/components/dev/DevScoringControls';
import VisionDataPanel from '@/components/dev/VisionDataPanel';
import ModelComparisonTable from '@/components/dev/ModelComparisonTable';
import ScoreExplanationPanel from '@/components/scoring/ScoreExplanationPanel';
import { ScoredImage, VisionApiOptions, ScoringOptions } from '@/types/types';
import { ContentSuggestion, AIModel } from '@/types/content';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { motion } from 'framer-motion';
import { analyzeImageWithVision, validateVisionData } from '@/utils/visionApi';
import { toast } from '@/components/ui/use-toast';
import { isDevelopmentMode } from '@/utils/devMode';
import { useScoringConfig } from '@/hooks/useScoringConfig';
import { scoreImage } from '@/services/imageScoring';
import { ModelComparisonResult, ModelComparisonResultWithCache, transformToComparisonResultsWithCache } from '@/types/scoring';
import { TEST_PROJECT_ID } from '@/context/ProjectContext';

interface ImageDashboardProps {
  isLoading: boolean;
  scoredImages: ScoredImage[];
  selectedImage: ScoredImage | null;
  contentSuggestions: ContentSuggestion[];
  selectedSuggestion: ContentSuggestion | null;
  isSuggestionsLoading: boolean;
  availableModels: AIModel[];
  onSelectImage: (image: ScoredImage) => void;
  onRemoveImage: (imageId: string) => void;
  onSelectSuggestion: (suggestion: ContentSuggestion) => void;
}

const ImageLoadingSkeleton = () => (
  <div className="space-y-6">
    <Skeleton className="h-64 w-full rounded-xl" />
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="space-y-6">
        <Skeleton className="h-32 w-full rounded-xl" />
        <Skeleton className="h-48 w-full rounded-xl" />
      </div>
      <Skeleton className="h-96 w-full rounded-xl" />
    </div>
  </div>
);

const ImageDashboard: React.FC<ImageDashboardProps> = ({
  isLoading,
  scoredImages,
  selectedImage,
  contentSuggestions,
  selectedSuggestion,
  isSuggestionsLoading,
  availableModels,
  onSelectImage,
  onRemoveImage,
  onSelectSuggestion
}) => {
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [forceMock, setForceMock] = useState<boolean>(false);
  const [showVisionData, setShowVisionData] = useState<boolean>(false);
  const [isCompareMode, setIsCompareMode] = useState<boolean>(false);
  const [selectedModelIds, setSelectedModelIds] = useState<string[]>([]);
  const [comparisonResults, setComparisonResults] = useState<ModelComparisonResultWithCache[]>([]);
  
  const { 
    config: scoringConfig, 
    isLoading: isConfigLoading,
    allConfigs,
    getConfigsByIds
  } = useScoringConfig();
  
  useEffect(() => {
    const analyzeImageIfNeeded = async () => {
      if (selectedImage && 
          !selectedImage.visionData && 
          !isAnalyzing &&
          !isConfigLoading) {
        
        if (!selectedImage.file) {
          console.warn('Cannot analyze image: File data is missing');
          toast({
            variant: "destructive",
            title: "Analysis Failed",
            description: "Image file data is missing and cannot be analyzed."
          });
          return;
        }
        
        try {
          setIsAnalyzing(true);
          console.log('Re-analyzing image due to missing vision data');
          
          // Check if we're in comparison mode
          if (isCompareMode && selectedModelIds.length > 0) {
            await analyzeWithComparison(selectedImage);
          } else {
            await analyzeWithSingleModel(selectedImage);
          }
        } catch (error) {
          console.error('Error analyzing image:', error);
          toast({
            variant: "destructive",
            title: "Image Analysis Failed",
            description: "We couldn't analyze this image. Please try again or select a different image."
          });
        } finally {
          setIsAnalyzing(false);
        }
      }
    };
    
    analyzeImageIfNeeded();
  }, [selectedImage, isAnalyzing, onSelectImage, forceMock, scoringConfig, isConfigLoading, isCompareMode, selectedModelIds]);

  const analyzeWithSingleModel = async (image: ScoredImage) => {
    if (!image.file) return;
    
    // Always ensure we have a projectId, using TEST_PROJECT_ID as fallback in dev mode
    const projectId = image.projectId || (isDevelopmentMode() ? TEST_PROJECT_ID : undefined);
    
    const options: VisionApiOptions = {
      projectId,
      forceMock: forceMock,
      debugInfo: true,
      scoringConfig: scoringConfig,
      test: projectId === TEST_PROJECT_ID || image.test === true
    };
    
    const visionData = await analyzeImageWithVision(image.file, options);
    
    const validation = validateVisionData(visionData);
    if (!validation.isValid && isDevelopmentMode()) {
      console.warn(
        '[DEV MODE] Vision data validation failed:',
        `Missing fields: ${validation.missingFields.join(', ')}`
      );
    }
    
    const updatedImage = {
      ...image,
      projectId, // Ensure projectId is set
      visionData,
      test: projectId === TEST_PROJECT_ID || image.test === true
    };
    
    onSelectImage(updatedImage);
  };

  const analyzeWithComparison = async (image: ScoredImage) => {
    if (!image.file) return;
    
    // Always ensure we have a projectId, using TEST_PROJECT_ID as fallback in dev mode
    const projectId = image.projectId || (isDevelopmentMode() ? TEST_PROJECT_ID : undefined);
    
    // Get the full config objects for selected model IDs
    const modelsToCompare = await getConfigsByIds(selectedModelIds);
    
    if (!modelsToCompare || modelsToCompare.length === 0) {
      toast({
        variant: "destructive",
        title: "No models selected",
        description: "Please select at least one scoring model to compare."
      });
      return;
    }
    
    // Call multi-model comparison
    const options: ScoringOptions = {
      projectId,
      forceMock: forceMock,
      compareModels: true,
      modelsToCompare,
      test: projectId === TEST_PROJECT_ID || image.test === true
    };
    
    // Use the correct type by transforming the results
    const results = await scoreImage(image.file, options);
    
    // Transform the results to ensure they match the expected type
    setComparisonResults(results);
    
    // Update the image with the primary model's vision data (first result)
    if (results.length > 0) {
      const updatedImage = {
        ...image,
        projectId, // Ensure projectId is set
        visionData: results[0].visionData,
        test: projectId === TEST_PROJECT_ID || image.test === true
      };
      
      onSelectImage(updatedImage);
    }
  };

  if (isLoading) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex items-center justify-center h-64"
      >
        <Loader2 className="h-8 w-8 text-primary animate-spin" />
        <span className="ml-3 text-lg">Analyzing images...</span>
      </motion.div>
    );
  }

  if (!Array.isArray(scoredImages) || scoredImages.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <Alert className="bg-muted">
          <AlertDescription>
            No images available. Please upload some images to get started.
          </AlertDescription>
        </Alert>
      </motion.div>
    );
  }

  if (selectedImage && !selectedImage.id) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          The selected image data appears to be corrupted. Try uploading the image again.
        </AlertDescription>
      </Alert>
    );
  }

  const fadeIn = {
    initial: { opacity: 0, y: 10 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.3 }
  };

  const handleToggleForceMock = (enabled: boolean) => {
    setForceMock(enabled);
    
    if (enabled) {
      toast({
        title: "Mock data mode enabled",
        description: "All image analysis will use mock data instead of real API calls",
        duration: 3000,
      });
    } else {
      toast({
        title: "Real analysis mode enabled",
        description: "Image analysis will use the actual Vision API",
        duration: 3000,
      });
    }
  };

  const handleToggleVisionData = () => {
    setShowVisionData(!showVisionData);
  };

  const handleToggleCompareMode = (enabled: boolean) => {
    setIsCompareMode(enabled);
    
    // If disabling, clear the comparison results
    if (!enabled) {
      setComparisonResults([]);
    }
    
    // If enabling and no models selected, automatically select the active model
    if (enabled && selectedModelIds.length === 0 && scoringConfig) {
      setSelectedModelIds([scoringConfig.id]);
    }
  };

  const handleSelectModelsToCompare = (modelIds: string[]) => {
    setSelectedModelIds(modelIds);
    
    // If we have an image selected, re-analyze it with the new model selection
    if (selectedImage && selectedImage.file) {
      setIsAnalyzing(true);
      analyzeWithComparison(selectedImage)
        .finally(() => setIsAnalyzing(false));
    }
  };

  return (
    <motion.div 
      className="space-y-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
    >
      <motion.div {...fadeIn}>
        <ImagePreview 
          images={scoredImages}
          selectedImage={selectedImage}
          onSelect={onSelectImage}
          onRemove={onRemoveImage}
        />
      </motion.div>
      
      {selectedImage && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-6">
            <motion.div {...fadeIn} transition={{ delay: 0.1 }}>
              {isCompareMode && comparisonResults.length > 0 ? (
                <ModelComparisonTable
                  results={comparisonResults}
                  isLoading={isAnalyzing}
                />
              ) : (
                <>
                  <OpportunityScore 
                    image={selectedImage} 
                    isLoading={isAnalyzing}
                  />
                  {selectedImage.visionData && scoringConfig && (
                    <ScoreExplanationPanel 
                      image={selectedImage}
                      scoringConfig={scoringConfig}
                      isLoading={isAnalyzing}
                    />
                  )}
                </>
              )}
            </motion.div>
            
            {isSuggestionsLoading ? (
              <motion.div {...fadeIn} transition={{ delay: 0.2 }}>
                <div className="p-6 rounded-xl glass-card h-64 flex items-center justify-center">
                  <Loader2 className="h-6 w-6 text-primary animate-spin" />
                  <span className="ml-3">Generating suggestions...</span>
                </div>
              </motion.div>
            ) : (
              <motion.div {...fadeIn} transition={{ delay: 0.2 }}>
                <ContentSuggestions 
                  suggestions={contentSuggestions || []}
                  onSelectSuggestion={onSelectSuggestion}
                />
              </motion.div>
            )}
            
            {isDevelopmentMode() && (
              <motion.div {...fadeIn} transition={{ delay: 0.3 }}>
                <DevScoringControls 
                  onToggleForceMock={handleToggleForceMock} 
                  selectedImage={selectedImage}
                  onToggleVisionData={handleToggleVisionData}
                  showVisionData={showVisionData}
                  scoringConfig={scoringConfig}
                  onToggleCompareMode={handleToggleCompareMode}
                  isCompareMode={isCompareMode}
                  onSelectModelsToCompare={handleSelectModelsToCompare}
                  selectedModelIds={selectedModelIds}
                />
              </motion.div>
            )}

            {isDevelopmentMode() && showVisionData && selectedImage.visionData && (
              <motion.div {...fadeIn} transition={{ delay: 0.4 }}>
                <VisionDataPanel 
                  visionData={selectedImage.visionData}
                  initialExpanded={true}
                />
              </motion.div>
            )}
          </div>
          
          <motion.div {...fadeIn} transition={{ delay: 0.3 }}>
            <GenerationPanel 
              selectedImage={selectedImage}
              selectedSuggestion={selectedSuggestion}
              availableModels={availableModels}
            />
          </motion.div>
        </div>
      )}
    </motion.div>
  );
};

export default ImageDashboard;
