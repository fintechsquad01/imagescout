
import React, { useEffect } from 'react';
import { Loader2, Image as ImageIcon, Zap, Sparkles, Clock } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { motion, AnimatePresence } from 'framer-motion';

interface UploadTrackerProps {
  dailyUploads?: number;
  maxUploads?: number;
  remainingUploads?: number;
  uploadProgress?: number;
  className?: string;
  estimatedTimeRemaining?: number; // in seconds
}

const UploadTracker: React.FC<UploadTrackerProps> = ({ 
  dailyUploads = 0,
  maxUploads = 50,
  remainingUploads = 50,
  uploadProgress = 0, 
  className,
  estimatedTimeRemaining = 15 
}) => {
  const [currentTask, setCurrentTask] = React.useState('Uploading');
  const [timeRemaining, setTimeRemaining] = React.useState(estimatedTimeRemaining);
  
  // Update task based on progress
  useEffect(() => {
    if (uploadProgress < 30) {
      setCurrentTask('Uploading');
    } else if (uploadProgress < 60) {
      setCurrentTask('Analyzing metadata');
    } else if (uploadProgress < 85) {
      setCurrentTask('Calculating opportunity score');
    } else {
      setCurrentTask('Finalizing');
    }
  }, [uploadProgress]);
  
  // Update time remaining
  useEffect(() => {
    if (uploadProgress < 100 && timeRemaining > 0) {
      const timer = setTimeout(() => {
        setTimeRemaining(prev => Math.max(0, prev - 1));
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [timeRemaining, uploadProgress]);
  
  // Animation variants
  const container = {
    hidden: { opacity: 0, y: -20 },
    show: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.4,
        staggerChildren: 0.1
      }
    },
    exit: {
      opacity: 0,
      y: -20,
      transition: {
        duration: 0.3
      }
    }
  };
  
  const item = {
    hidden: { opacity: 0, y: 10 },
    show: { opacity: 1, y: 0 }
  };
  
  const taskSteps = [
    { icon: <ImageIcon className="h-5 w-5" />, text: 'Uploading image files', status: uploadProgress >= 30 ? 'completed' : 'active' },
    { icon: <Zap className="h-5 w-5" />, text: 'Analyzing with Vision AI', status: uploadProgress >= 30 && uploadProgress < 60 ? 'active' : (uploadProgress < 30 ? 'pending' : 'completed') },
    { icon: <Sparkles className="h-5 w-5" />, text: 'Calculating opportunity score', status: uploadProgress >= 60 ? 'active' : 'pending' }
  ];

  return (
    <AnimatePresence>
      {uploadProgress < 100 && (
        <motion.div 
          className={`flex flex-col items-center justify-center h-64 mt-12 ${className}`}
          variants={container}
          initial="hidden"
          animate="show"
          exit="exit"
          key="upload-tracker"
        >
          <motion.div variants={item} className="w-full max-w-md mb-8">
            <div className="flex justify-between text-sm font-medium mb-2">
              <span>{currentTask}...</span>
              <span>{Math.round(uploadProgress)}%</span>
            </div>
            <Progress value={uploadProgress} className="h-2" />
          </motion.div>
          
          <motion.div variants={item} className="space-y-4 w-full max-w-md mb-4">
            {taskSteps.map((step, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className={`rounded-full w-8 h-8 flex items-center justify-center transition-all duration-300 ${
                  step.status === 'completed' ? 'bg-primary/20 text-primary' :
                  step.status === 'active' ? 'bg-primary text-white animate-pulse' : 
                  'bg-muted text-muted-foreground'
                }`}>
                  {step.status === 'active' ? <Loader2 className="h-4 w-4 animate-spin" /> : step.icon}
                </div>
                <span className={`text-sm transition-all duration-300 ${
                  step.status === 'completed' ? 'text-muted-foreground line-through' :
                  step.status === 'active' ? 'text-foreground font-medium' : 
                  'text-muted-foreground'
                }`}>
                  {step.text}
                </span>
              </div>
            ))}
          </motion.div>
          
          <motion.div variants={item} className="text-center">
            <Loader2 className="h-10 w-10 text-primary animate-spin mb-4 mx-auto" />
            <p className="text-muted-foreground text-center max-w-md flex flex-col gap-2">
              <span>Your images are being processed. This typically takes 10-15 seconds.</span>
              {timeRemaining > 0 && (
                <span className="flex items-center justify-center gap-1.5 text-sm font-medium">
                  <Clock className="h-4 w-4" />
                  Estimated time remaining: {timeRemaining}s
                </span>
              )}
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default UploadTracker;
