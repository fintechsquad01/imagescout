
import React from 'react';
import { Github, Zap, Database } from 'lucide-react';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import FeedbackAnalytics from '@/components/admin/FeedbackAnalytics';

const AppFooter: React.FC = () => {
  const { isFeatureEnabled } = useFeatureFlags();
  
  return (
    <footer className="py-6 border-t border-white/10 mt-10 backdrop-blur-sm">
      {/* Analytics Panel for Internal Users */}
      {isFeatureEnabled('advanced_analytics') && (
        <div className="container mx-auto px-4 max-w-6xl mb-8">
          <FeedbackAnalytics />
        </div>
      )}
      
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <p>AI Content Repurposing Studio &copy; {new Date().getFullYear()}</p>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Zap className="h-3 w-3" />
              <span>Powered by RenderNet</span>
            </div>
            
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Database className="h-3 w-3" />
              <span>Built with Supabase</span>
            </div>
            
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Github className="h-3 w-3" />
              <span>Open Source</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default AppFooter;
