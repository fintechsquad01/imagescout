
import React, { useEffect, useRef, useState } from 'react';
import { cn } from "@/lib/utils";
import { ScoredImage, VisionApiData } from '@/types/types';
import { Sparkles, Zap, Rocket, Tag, Palette, Globe, BarChart, AlertTriangle, Loader2 } from "lucide-react";
import { motion } from 'framer-motion';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Skeleton } from '@/components/ui/skeleton';

interface OpportunityScoreProps {
  image: ScoredImage;
  className?: string;
  isLoading?: boolean;
}

const OpportunityScore: React.FC<OpportunityScoreProps> = ({ 
  image, 
  className,
  isLoading = false
}) => {
  const scoreRef = useRef<SVGCircleElement>(null);
  const [isAnimating, setIsAnimating] = useState(false);
  
  // Ensure we have a score value, defaulting to opportunityScore or score or 0
  const score = image.opportunityScore || image.score || 0;
  
  useEffect(() => {
    if (scoreRef.current && !isLoading) {
      setIsAnimating(true);
      const circumference = 2 * Math.PI * 45;
      const offset = circumference - (score / 100) * circumference;
      
      // Set the custom property for the animation target
      scoreRef.current.style.setProperty('--target-offset', `${offset}`);
      scoreRef.current.setAttribute('stroke-dashoffset', `${circumference}`);
      
      // Trigger reflow to restart animation
      void scoreRef.current.getBoundingClientRect();
      
      // Add the animation class
      scoreRef.current.classList.add('score-circle');

      // Set animation state back to false after animation completes
      const timer = setTimeout(() => {
        setIsAnimating(false);
      }, 1500); // Animation duration
      
      return () => clearTimeout(timer);
    }
  }, [score, isLoading]);

  // Define score levels and messages
  const getScoreLevel = () => {
    if (score >= 80) return { 
      level: 'Excellent', 
      icon: <Rocket className="h-5 w-5" />,
      message: 'High viral potential. Recommended for repurposing.'
    };
    if (score >= 65) return { 
      level: 'Good', 
      icon: <Sparkles className="h-5 w-5" />,
      message: 'Good potential. Consider repurposing with enhancements.'
    };
    return { 
      level: 'Fair', 
      icon: <Zap className="h-5 w-5" />,
      message: 'Average potential. May need significant enhancements.'
    };
  };

  const { level, icon, message } = getScoreLevel();
  
  // Define color based on score
  const getScoreColor = () => {
    if (score >= 80) return 'text-green-500';
    if (score >= 65) return 'text-blue-500';
    return 'text-amber-500';
  };

  // Data quality indicator
  const getDataQualityIndicator = () => {
    if (isLoading) return {
      icon: <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />,
      label: 'Analysis in progress',
      description: 'Extracting visual data from image'
    };
    
    if (!image.visionData) return {
      icon: <AlertTriangle className="h-4 w-4 text-amber-500" />,
      label: 'No analysis data',
      description: 'Using basic scoring only'
    };
    
    const labelCount = image.visionData.labels?.length || 0;
    const objectCount = image.visionData.objects?.length || 0;
    const colorCount = image.visionData.colors?.length || 0;
    
    const total = labelCount + objectCount + colorCount;
    
    if (total >= 10) return {
      icon: <BarChart className="h-4 w-4 text-green-500" />,
      label: 'Complete analysis',
      description: 'High-quality metadata detected'
    };
    
    if (total >= 5) return {
      icon: <BarChart className="h-4 w-4 text-blue-500" />,
      label: 'Partial analysis',
      description: 'Some metadata detected'
    };
    
    return {
      icon: <AlertTriangle className="h-4 w-4 text-amber-500" />,
      label: 'Limited analysis',
      description: 'Minimal metadata detected'
    };
  };

  const dataQuality = getDataQualityIndicator();

  // Animation variants
  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0 }
  };

  // Render skeleton loading state
  if (isLoading) {
    return (
      <motion.div 
        className={cn(
          "p-6 rounded-xl glass-card",
          className
        )}
        initial={{ opacity: 0, scale: 0.97 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
      >
        <h3 className="text-lg font-medium mb-4">Opportunity Score</h3>
        
        <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-8">
          <div className="relative">
            <Skeleton className="h-[100px] w-[100px] rounded-full" />
          </div>
          
          <div className="flex-1 space-y-4">
            <Skeleton className="h-7 w-36" />
            <Skeleton className="h-5 w-full max-w-md" />
            <Skeleton className="h-4 w-24" />
            
            <div className="space-y-3 pt-2">
              <Skeleton className="h-4 w-32" />
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                <Skeleton className="h-7 w-20 rounded-full" />
                <Skeleton className="h-7 w-24 rounded-full" />
                <Skeleton className="h-7 w-16 rounded-full" />
              </div>
              
              <Skeleton className="h-4 w-28 mt-2" />
              <div className="flex gap-1.5 mt-1.5">
                <Skeleton className="h-5 w-9 rounded-full" />
                <Skeleton className="h-5 w-9 rounded-full" />
                <Skeleton className="h-5 w-9 rounded-full" />
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      className={cn(
        "p-6 rounded-xl glass-card",
        className
      )}
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
    >
      <h3 className="text-lg font-medium mb-4">Opportunity Score</h3>
      
      <div className="flex flex-col sm:flex-row items-center gap-6 sm:gap-8">
        <div className="relative">
          <svg width="100" height="100" viewBox="0 0 100 100">
            {/* Background circle */}
            <circle
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke="currentColor"
              strokeWidth="10"
              className="text-muted/20"
            />
            
            {/* Score circle */}
            <circle
              ref={scoreRef}
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke="currentColor"
              strokeWidth="10"
              strokeLinecap="round"
              strokeDasharray="283"
              strokeDashoffset="283"
              className={cn(getScoreColor(), {
                "transition-[stroke-dashoffset] duration-[1.5s] ease-out": isAnimating
              })}
              transform="rotate(-90 50 50)"
            />
          </svg>
          
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className={cn("text-2xl font-bold", getScoreColor())}>{score}</span>
            <span className="text-xs text-muted-foreground">/ 100</span>
          </div>
        </div>
        
        <div className="flex-1">
          <div className={cn("flex items-center gap-2 mb-2", getScoreColor())}>
            {icon}
            <h4 className="font-medium">{level} Potential</h4>
          </div>
          
          <p className="text-sm text-muted-foreground mb-3">
            {message}
          </p>
          
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-3 cursor-help">
                  {dataQuality.icon}
                  <span>{dataQuality.label}</span>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>{dataQuality.description}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
          
          {/* Display metadata from Vision API */}
          {image.visionData && (
            <motion.div 
              className="space-y-3"
              initial="hidden"
              animate="visible"
              transition={{ staggerChildren: 0.1 }}
            >
              <motion.div variants={itemVariants}>
                <h5 className="text-xs uppercase font-medium text-muted-foreground">Detected Elements</h5>
                <div className="flex flex-wrap gap-1.5 mt-1.5">
                  {image.visionData.labels.slice(0, 5).map((label, index) => (
                    <span 
                      key={index} 
                      className="inline-flex items-center text-xs bg-secondary px-2.5 py-1 rounded-full transition-colors hover:bg-secondary/80"
                    >
                      <Tag className="h-3 w-3 mr-1" /> {label}
                    </span>
                  ))}
                  {image.visionData.labels.length === 0 && (
                    <span className="text-xs text-muted-foreground">No elements detected</span>
                  )}
                </div>
              </motion.div>
              
              {image.visionData.colors.length > 0 && (
                <motion.div variants={itemVariants}>
                  <h5 className="text-xs uppercase font-medium text-muted-foreground mt-2">Color Palette</h5>
                  <div className="flex gap-1.5 mt-1.5">
                    {image.visionData.colors.slice(0, 5).map((color, index) => (
                      <TooltipProvider key={index}>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div 
                              className="h-5 w-9 rounded-full transition-transform hover:scale-110 flex items-center justify-center"
                              style={{ backgroundColor: color }}
                            >
                              <Palette className="h-3 w-3 text-white opacity-70" />
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{color}</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    ))}
                  </div>
                </motion.div>
              )}
              
              {image.visionData.landmarks.length > 0 && (
                <motion.div variants={itemVariants}>
                  <h5 className="text-xs uppercase font-medium text-muted-foreground mt-2">Landmarks</h5>
                  <div className="flex flex-wrap gap-1.5 mt-1.5">
                    {image.visionData.landmarks.slice(0, 3).map((landmark, index) => (
                      <span 
                        key={index} 
                        className="inline-flex items-center text-xs bg-blue-500/10 text-blue-700 dark:text-blue-300 px-2.5 py-1 rounded-full"
                      >
                        <Globe className="h-3 w-3 mr-1" /> {landmark}
                      </span>
                    ))}
                  </div>
                </motion.div>
              )}
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default OpportunityScore;
