
import React, { useCallback, useState } from 'react';
import { cn } from "@/lib/utils";
import { validateUploadLimits } from '@/utils/mockData';
import { ImageFile } from '@/types/types';
import { Upload, Image, Sparkles, Zap, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/use-toast";
import { Progress } from "@/components/ui/progress";
import { useSupabaseLogger } from '@/hooks/useSupabaseLogger';
import { useProject } from '@/context/ProjectContext';

interface ImageUploaderProps {
  onImagesSelected?: (images: ImageFile[]) => void;
  onUpload?: (images: ImageFile[]) => void;
  className?: string;
  maxImages?: number;
  isUploading?: boolean;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ 
  onImagesSelected,
  onUpload,
  className,
  maxImages = 10,
  isUploading = false
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const { dailyUploads, maxDailyUploads, remainingUploads, logImageUpload } = useSupabaseLogger();
  const { currentProject } = useProject();
  
  const uploadPercentage = (dailyUploads / maxDailyUploads) * 100;
  
  const handleFileChange = useCallback(async (files: FileList | null) => {
    if (!files?.length) return;
    
    if (!currentProject) {
      toast({
        variant: "destructive",
        title: "No project selected",
        description: "Please select or create a project first"
      });
      return;
    }
    
    const fileArray = Array.from(files);
    
    if (!validateUploadLimits(fileArray)) return;
    
    const imageFiles = fileArray.map(file => {
      if (!file.type.startsWith('image/')) {
        toast({
          variant: "destructive",
          title: "Invalid file type",
          description: `${file.name} is not an image file.`
        });
        return null;
      }
      
      return Object.assign(file, {
        preview: URL.createObjectURL(file),
        id: `${file.name}-${Date.now()}`
      });
    }).filter(Boolean) as ImageFile[];
    
    if (imageFiles.length) {
      await logImageUpload(imageFiles.length);
      
      toast({
        title: "Images uploaded",
        description: `Analyzing ${imageFiles.length} images with AI vision...`
      });
      
      // Use the appropriate callback - for backward compatibility
      if (onUpload) {
        onUpload(imageFiles);
      }
      if (onImagesSelected) {
        onImagesSelected(imageFiles);
      }
    }
  }, [onImagesSelected, onUpload, logImageUpload, currentProject]);
  
  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);
  
  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);
  
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files) {
      handleFileChange(e.dataTransfer.files);
    }
  }, [handleFileChange]);
  
  return (
    <div 
      className={cn(
        "flex flex-col items-center justify-center p-8 transition-all duration-300 ease-in-out",
        "border-2 border-dashed rounded-xl gap-4",
        isDragging 
          ? "border-primary bg-primary/5" 
          : "border-border bg-secondary/50",
        "animate-fade-in shadow-sm", 
        className
      )}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
        <Upload className="h-8 w-8 text-primary" />
      </div>
      
      <div className="text-center">
        <h3 className="text-lg font-medium mb-1">
          {currentProject ? (
            <>ImageScout Widget</>
          ) : (
            <>Select a Project First</>
          )}
        </h3>
        <p className="text-muted-foreground text-sm max-w-md">
          {currentProject ? (
            <>Upload 1-10 images to analyze their viral potential and get AI-powered content suggestions</>
          ) : (
            <>Select or create a project from the dropdown menu in the header</>
          )}
        </p>
      </div>
      
      <div className="flex gap-2 mt-2">
        <Button 
          variant="secondary" 
          onClick={() => {
            if (!currentProject) {
              toast({
                variant: "destructive",
                title: "No project selected",
                description: "Please select or create a project first"
              });
              return;
            }
            
            const input = document.createElement('input');
            input.type = 'file';
            input.multiple = true;
            input.accept = 'image/*';
            input.onchange = (e) => handleFileChange((e.target as HTMLInputElement).files);
            input.click();
          }}
          className="flex gap-2"
          disabled={!currentProject || isUploading}
        >
          {isUploading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Uploading...
            </>
          ) : (
            <>
              <Image className="h-4 w-4" />
              Select Images
            </>
          )}
        </Button>
      </div>
      
      <div className="w-full max-w-xs mt-4">
        <div className="flex justify-between items-center mb-1 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Info className="h-3 w-3" />
            Daily Upload Limit
          </span>
          <span className="font-medium">{dailyUploads}/{maxDailyUploads}</span>
        </div>
        <Progress value={uploadPercentage} className="h-1.5" />
      </div>
      
      <div className="flex flex-col gap-2 mt-4 text-center">
        <div className="text-xs text-muted-foreground flex items-center justify-center gap-1 font-medium">
          <Sparkles className="h-3 w-3 text-primary" />
          Google Vision AI analyzes your images for metadata
        </div>
        
        <div className="text-xs text-muted-foreground flex items-center justify-center gap-1 font-medium">
          <Zap className="h-3 w-3 text-primary" />
          RenderNet AI transforms images using custom prompts
        </div>
      </div>
      
      <div className="text-xs text-muted-foreground mt-3">
        Supported formats: JPG, PNG, GIF (max {maxImages} images, 5MB each)
      </div>
    </div>
  );
};

// Add Loader2 component
import { Loader2 } from "lucide-react";

export default ImageUploader;
