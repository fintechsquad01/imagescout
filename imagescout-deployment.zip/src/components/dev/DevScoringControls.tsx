
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Info, ArrowRight, RefreshCw, Loader2, Code, ChevronDown, ChevronUp, ScaleIcon, BrainCircuit, Database, XCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { isDevelopmentMode } from '@/utils/devMode';
import { getScoringStats, getMockScoringStats } from '@/utils/scoringTelemetry';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from "@/components/ui/badge";
import { ScoredImage } from '@/types/types';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import VisionDataPanel from './VisionDataPanel';
import { ScoringConfig } from '@/types/scoring-config';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useScoringConfig } from '@/hooks/useScoringConfig';
import { Checkbox } from "@/components/ui/checkbox";
import { clearScoreCache, clearSingleScoreCache } from '@/utils/scoreCacheUtils';
import { toast as sonnerToast } from 'sonner';

interface DevScoringControlsProps {
  onToggleForceMock?: (enabled: boolean) => void;
  selectedImage?: ScoredImage | null;
  onToggleVisionData?: () => void;
  showVisionData?: boolean;
  scoringConfig?: ScoringConfig;
  onToggleCompareMode?: (enabled: boolean) => void;
  isCompareMode?: boolean;
  onSelectModelsToCompare?: (modelIds: string[]) => void;
  selectedModelIds?: string[];
  onToggleSkipCache?: (enabled: boolean) => void;
  skipCache?: boolean;
}

const DevScoringControls: React.FC<DevScoringControlsProps> = ({ 
  onToggleForceMock,
  selectedImage,
  onToggleVisionData,
  showVisionData = false,
  scoringConfig: propScoringConfig,
  onToggleCompareMode,
  isCompareMode = false,
  onSelectModelsToCompare,
  selectedModelIds = [],
  onToggleSkipCache,
  skipCache = false
}) => {
  const [forceMock, setForceMock] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showScoringConfig, setShowScoringConfig] = useState(false);
  const [compareMode, setCompareMode] = useState(isCompareMode);
  const [modelIdsToCompare, setModelIdsToCompare] = useState<string[]>(selectedModelIds);
  const [skipCacheState, setSkipCacheState] = useState(skipCache);
  const [clearingCache, setClearingCache] = useState(false);
  const [stats, setStats] = useState<{
    totalScores: number;
    successRate: number;
    avgResponseTime: number;
    mockPercentage: number;
  } | null>(null);
  const { toast } = useToast();
  
  const { 
    config: hookScoringConfig, 
    allConfigs, 
    isLoadingAllConfigs, 
    activateConfig, 
    isActivating,
    refetchAllConfigs
  } = useScoringConfig();

  const scoringConfig = propScoringConfig || hookScoringConfig;

  if (!isDevelopmentMode()) {
    return null;
  }

  useEffect(() => {
    if (onSelectModelsToCompare && modelIdsToCompare.length > 0) {
      onSelectModelsToCompare(modelIdsToCompare);
    }
  }, [modelIdsToCompare, onSelectModelsToCompare]);

  const handleToggleForceMock = (enabled: boolean) => {
    setForceMock(enabled);
    if (onToggleForceMock) {
      onToggleForceMock(enabled);
    }
    
    console.log(`[DEV MODE] Force mock data ${enabled ? 'enabled' : 'disabled'}`);
    
    toast({
      title: enabled ? 'Mock data enabled' : 'Real API enabled',
      description: enabled ? 'Using mock Vision API responses' : 'Using real Vision API when available',
    });
  };

  const handleToggleSkipCache = (enabled: boolean) => {
    setSkipCacheState(enabled);
    if (onToggleSkipCache) {
      onToggleSkipCache(enabled);
    }
    
    console.log(`[DEV MODE] Skip cache ${enabled ? 'enabled' : 'disabled'}`);
    
    toast({
      title: enabled ? 'Cache bypassed' : 'Cache enabled',
      description: enabled ? 'Forcing fresh data fetches' : 'Using cached results when available',
    });
  };

  const handleClearCache = async () => {
    try {
      setClearingCache(true);
      
      const imageId = selectedImage?.id;
      const result = imageId 
        ? await clearSingleScoreCache(imageId)
        : await clearScoreCache();
      
      if (result) {
        sonnerToast.success(
          imageId ? 'Cache cleared for this image' : 'Complete cache cleared',
          { description: 'Subsequent scoring operations will use fresh data' }
        );
      } else {
        sonnerToast.error('Failed to clear cache', { 
          description: 'See console for details' 
        });
      }
    } catch (error) {
      console.error('Error clearing cache:', error);
      sonnerToast.error('Failed to clear cache', { 
        description: error instanceof Error ? error.message : 'Unknown error' 
      });
    } finally {
      setClearingCache(false);
    }
  };

  const handleScoringModelChange = async (configId: string) => {
    try {
      await activateConfig(configId);
      console.log(`[DEV MODE] Activated scoring config: ${configId}`);
    } catch (error) {
      console.error("Failed to change scoring model:", error);
      toast({
        variant: "destructive",
        title: "Failed to change scoring model",
        description: "Could not update the active scoring configuration."
      });
    }
  };

  const handleToggleCompareMode = (enabled: boolean) => {
    setCompareMode(enabled);
    
    if (onToggleCompareMode) {
      onToggleCompareMode(enabled);
    }
    
    if (enabled && modelIdsToCompare.length === 0 && scoringConfig) {
      const initialSelectedModels = [scoringConfig.id];
      setModelIdsToCompare(initialSelectedModels);
      
      if (onSelectModelsToCompare) {
        onSelectModelsToCompare(initialSelectedModels);
      }
    }
    
    console.log(`[DEV MODE] Model comparison mode ${enabled ? 'enabled' : 'disabled'}`);
    
    toast({
      title: enabled ? 'Comparison mode enabled' : 'Comparison mode disabled',
      description: enabled 
        ? 'Multiple scoring models will be compared' 
        : 'Using single scoring model',
    });
  };

  const handleModelSelectionChange = (configId: string, isSelected: boolean) => {
    let updatedModelIds: string[];
    
    if (isSelected) {
      updatedModelIds = [...modelIdsToCompare, configId];
    } else {
      updatedModelIds = modelIdsToCompare.filter(id => id !== configId);
    }
    
    setModelIdsToCompare(updatedModelIds);
    
    if (onSelectModelsToCompare) {
      onSelectModelsToCompare(updatedModelIds);
    }
  };

  const loadStats = async () => {
    setIsLoading(true);
    try {
      if (!import.meta.env.VITE_SUPABASE_URL || !import.meta.env.VITE_SUPABASE_ANON_KEY) {
        const mockStats = getMockScoringStats();
        setStats(mockStats);
        console.log('[DEV MODE] Loaded mock scoring stats:', mockStats);
        return;
      }
      
      const realStats = await getScoringStats();
      setStats(realStats);
      console.log('[DEV MODE] Loaded real scoring stats:', realStats);
    } catch (error) {
      console.error('Error loading scoring stats:', error);
      const mockStats = getMockScoringStats();
      setStats(mockStats);
      
      toast({
        variant: 'destructive',
        title: 'Failed to load stats',
        description: 'Using mock stats instead'
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, []);

  useEffect(() => {
    refetchAllConfigs();
  }, [refetchAllConfigs]);

  return (
    <Card className="border-dashed border-yellow-500/50 bg-yellow-50/50 dark:bg-yellow-950/20 shadow-sm">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center text-yellow-700 dark:text-yellow-400">
          <Info className="h-4 w-4 mr-2" />
          Developer Scoring Controls
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 pt-0">
        <div className="flex items-center space-x-2">
          <Switch
            id="force-mock"
            checked={forceMock}
            onCheckedChange={handleToggleForceMock}
          />
          <Label htmlFor="force-mock" className="text-xs cursor-pointer">
            Force mock data (bypass real API calls)
          </Label>
        </div>

        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Switch
              id="skip-cache"
              checked={skipCacheState}
              onCheckedChange={handleToggleSkipCache}
            />
            <Label htmlFor="skip-cache" className="text-xs cursor-pointer flex items-center">
              <Database className="h-3 w-3 mr-1" />
              Force cache miss (bypass cache)
            </Label>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            className="w-full text-xs flex items-center"
            onClick={handleClearCache}
            disabled={clearingCache}
          >
            {clearingCache ? (
              <Loader2 className="h-3 w-3 mr-1 animate-spin" />
            ) : (
              <XCircle className="h-3 w-3 mr-1" />
            )}
            {selectedImage ? 'Clear cache for this image' : 'Clear all cached scores'}
          </Button>
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="compare-mode"
            checked={compareMode}
            onCheckedChange={handleToggleCompareMode}
          />
          <Label htmlFor="compare-mode" className="text-xs cursor-pointer flex items-center">
            <BrainCircuit className="h-3 w-3 mr-1" />
            Enable model comparison
          </Label>
        </div>

        {!compareMode ? (
          <div className="space-y-2">
            <Label htmlFor="scoring-model" className="text-xs">
              Scoring Model
            </Label>
            <Select 
              disabled={isLoadingAllConfigs || isActivating} 
              value={scoringConfig?.id} 
              onValueChange={handleScoringModelChange}
            >
              <SelectTrigger id="scoring-model" className="w-full text-xs h-8">
                <SelectValue placeholder="Select scoring model" />
              </SelectTrigger>
              <SelectContent>
                {isLoadingAllConfigs ? (
                  <SelectItem value="loading" disabled>Loading models...</SelectItem>
                ) : !allConfigs || allConfigs.length === 0 ? (
                  <SelectItem value="none" disabled>No scoring models available</SelectItem>
                ) : (
                  allConfigs.map(config => (
                    <SelectItem key={config.id} value={config.id}>
                      {config.model} ({config.version})
                      {config.is_active && " - Active"}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
        ) : (
          <div className="space-y-2">
            <Label className="text-xs flex items-center">
              <ScaleIcon className="h-3 w-3 mr-1" />
              Models to Compare
            </Label>
            {isLoadingAllConfigs ? (
              <Skeleton className="h-20 w-full" />
            ) : (
              <div className="max-h-40 overflow-y-auto border rounded-md p-2 space-y-2">
                {!allConfigs || allConfigs.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No models available</p>
                ) : (
                  allConfigs.map(config => (
                    <div key={config.id} className="flex items-center space-x-2">
                      <Checkbox 
                        id={`compare-${config.id}`}
                        checked={modelIdsToCompare.includes(config.id)}
                        onCheckedChange={(checked) => handleModelSelectionChange(config.id, checked === true)}
                      />
                      <Label htmlFor={`compare-${config.id}`} className="text-xs cursor-pointer flex items-start">
                        <span className="font-medium">{config.model}</span>
                        <span className="text-muted-foreground ml-1">({config.version})</span>
                        {config.is_active && <Badge variant="outline" className="ml-2 text-[10px] py-0">Active</Badge>}
                      </Label>
                    </div>
                  ))
                )}
              </div>
            )}
            {modelIdsToCompare.length === 0 && (
              <Alert variant="destructive" className="py-2">
                <AlertDescription className="text-xs">
                  Please select at least one model for comparison
                </AlertDescription>
              </Alert>
            )}
          </div>
        )}

        {onToggleVisionData && (
          <div className="flex items-center space-x-2">
            <Switch
              id="show-vision-data"
              checked={showVisionData}
              onCheckedChange={onToggleVisionData}
            />
            <Label htmlFor="show-vision-data" className="text-xs cursor-pointer">
              Show raw vision data
            </Label>
          </div>
        )}
        
        {selectedImage && selectedImage.visionData && (
          <div className="mt-2">
            <Alert className="bg-muted p-2">
              <AlertTitle className="text-xs font-medium">
                Vision Data Summary
              </AlertTitle>
              <AlertDescription className="mt-1">
                <div className="flex flex-wrap gap-1 mt-1">
                  <Badge variant={selectedImage.visionData ? "default" : "destructive"} className="text-xs">
                    {selectedImage.visionData ? 'Has Vision Data' : 'No Vision Data'}
                  </Badge>
                  
                  <Badge variant="outline" className="text-xs">
                    Score: {selectedImage.opportunityScore || selectedImage.score || 'None'}
                  </Badge>

                  {scoringConfig && (
                    <Badge variant="secondary" className="text-xs">
                      Config: {scoringConfig.version}
                    </Badge>
                  )}
                </div>
              </AlertDescription>
            </Alert>
          </div>
        )}

        {scoringConfig && (
          <Collapsible 
            open={showScoringConfig} 
            onOpenChange={setShowScoringConfig}
            className="mt-2"
          >
            <CollapsibleTrigger asChild>
              <Button variant="outline" size="sm" className="w-full text-xs">
                {showScoringConfig ? <ChevronUp className="h-3 w-3 mr-1" /> : <ChevronDown className="h-3 w-3 mr-1" />}
                Scoring Config: {scoringConfig.version}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2">
              <div className="rounded border bg-muted p-2 text-xs font-mono">
                <div className="mb-2 font-semibold">Weights:</div>
                <div className="space-y-1">
                  <div>Labels: {scoringConfig.weights.labels}</div>
                  <div>Objects: {scoringConfig.weights.objects}</div>
                  <div>Landmarks: {scoringConfig.weights.landmarks}</div>
                  <div>Colors: {scoringConfig.weights.colors}</div>
                  <div>Base Score: {scoringConfig.weights.baseScore}</div>
                  <div>Max Score: {scoringConfig.weights.maxScore}</div>
                </div>
                {scoringConfig.prompt_template && (
                  <>
                    <div className="mt-2 mb-1 font-semibold">Prompt Template:</div>
                    <div className="p-1 bg-background rounded text-xs max-h-20 overflow-auto">
                      {scoringConfig.prompt_template}
                    </div>
                  </>
                )}
              </div>
            </CollapsibleContent>
          </Collapsible>
        )}
        
        <div className="grid grid-cols-2 gap-2 mt-2">
          {isLoading ? (
            <>
              <div className="bg-yellow-100/50 dark:bg-yellow-900/20 p-2 rounded">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-6 w-12 mt-1" />
              </div>
              <div className="bg-yellow-100/50 dark:bg-yellow-900/20 p-2 rounded">
                <Skeleton className="h-4 w-20" />
                <Skeleton className="h-6 w-12 mt-1" />
              </div>
            </>
          ) : stats ? (
            <>
              <div className="bg-yellow-100/50 dark:bg-yellow-900/20 p-2 rounded">
                <div className="text-xs text-yellow-800 dark:text-yellow-300">Total Scores</div>
                <div className="text-sm font-medium">{stats.totalScores}</div>
              </div>
              <div className="bg-yellow-100/50 dark:bg-yellow-900/20 p-2 rounded">
                <div className="text-xs text-yellow-800 dark:text-yellow-300">Success Rate</div>
                <div className="text-sm font-medium">{stats.successRate.toFixed(1)}%</div>
              </div>
              <div className="bg-yellow-100/50 dark:bg-yellow-900/20 p-2 rounded">
                <div className="text-xs text-yellow-800 dark:text-yellow-300">Avg Response</div>
                <div className="text-sm font-medium">{Math.round(stats.avgResponseTime)}ms</div>
              </div>
              <div className="bg-yellow-100/50 dark:bg-yellow-900/20 p-2 rounded">
                <div className="text-xs text-yellow-800 dark:text-yellow-300">Mock Usage</div>
                <div className="text-sm font-medium">{stats.mockPercentage.toFixed(1)}%</div>
              </div>
            </>
          ) : null}
        </div>

        <div className="mt-2">
          <Button 
            variant="outline" 
            size="sm"
            className="text-xs w-full border-yellow-500/50 text-yellow-700 hover:bg-yellow-100 dark:text-yellow-400 dark:hover:bg-yellow-900/30"
            asChild
          >
            <Link to="/test-scoring">
              Advanced Scoring Debug
              <ArrowRight className="h-3 w-3 ml-1" />
            </Link>
          </Button>
        </div>
        
        <div className="mt-2">
          <Button 
            variant="outline" 
            size="sm"
            className="text-xs w-full border-yellow-500/50 text-yellow-700 hover:bg-yellow-100 dark:text-yellow-400 dark:hover:bg-yellow-900/30"
            onClick={loadStats}
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="h-3 w-3 mr-1 animate-spin" />
                Refreshing...
              </>
            ) : (
              <>
                <RefreshCw className="h-3 w-3 mr-1" />
                Refresh Stats
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default DevScoringControls;
