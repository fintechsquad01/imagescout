
import React, { useState } from 'react';
import { Beaker, Info, AlertCircle, ShieldAlert } from 'lucide-react';
import { isDevelopmentMode, getDetailedDevModeStatus } from '@/utils/devMode';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';

interface DevModeIndicatorProps {
  className?: string;
}

const DevModeIndicator: React.FC<DevModeIndicatorProps> = ({ className = "" }) => {
  const [expanded, setExpanded] = useState(false);
  const isDevMode = isDevelopmentMode();
  
  if (!isDevMode) return null;
  
  const { features } = getDetailedDevModeStatus();
  
  return (
    <div className={`fixed bottom-4 right-4 z-50 flex items-center ${className}`}>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div 
              className="bg-amber-500 text-white p-2 rounded-full flex items-center justify-center cursor-pointer shadow-md hover:bg-amber-600 transition-colors animate-pulse"
              onClick={() => setExpanded(!expanded)}
            >
              <ShieldAlert className="h-5 w-5" />
            </div>
          </TooltipTrigger>
          <TooltipContent side="left">
            <div className="text-sm">
              <p className="font-semibold">Development Mode Active</p>
              <p className="text-xs mt-1">Role and flag checks bypassed locally</p>
              <ul className="mt-1 space-y-1 text-xs">
                {features.slice(0, 3).map((feature, index) => (
                  <li key={index} className="flex items-center gap-1">
                    <Info className="h-3 w-3" />
                    {feature}
                  </li>
                ))}
                {features.length > 3 && (
                  <li className="text-xs italic">+ {features.length - 3} more</li>
                )}
              </ul>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      {expanded && (
        <div className="absolute bottom-0 right-12 bg-white dark:bg-gray-800 p-3 rounded-lg shadow-lg border border-amber-200 w-64">
          <div className="flex justify-between items-center mb-2">
            <Badge className="bg-amber-500">Development Mode</Badge>
            <button 
              className="text-gray-500 hover:text-gray-700"
              onClick={() => setExpanded(false)}
            >
              ×
            </button>
          </div>
          <div className="space-y-2">
            <p className="text-sm font-medium">Active Bypass Features:</p>
            <ul className="space-y-1 text-xs">
              {features.map((feature, index) => (
                <li key={index} className="flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-green-500"></span>
                  {feature}
                </li>
              ))}
            </ul>
            <p className="text-xs mt-3 italic text-amber-700 dark:text-amber-400">
              This indicator is only visible in development mode
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default DevModeIndicator;
