
import React, { useState } from 'react';
import { Braces, Loader2, AlertTriangle, FileCheck, Info } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { VisionApiData } from '@/types/types';
import { validateVisionData } from '@/utils/visionApi';

interface VisionDataPanelProps {
  visionData?: VisionApiData;
  isLoading?: boolean;
  className?: string;
  initialExpanded?: boolean;
}

const VisionDataPanel: React.FC<VisionDataPanelProps> = ({ 
  visionData, 
  isLoading = false,
  className = "",
  initialExpanded = false
}) => {
  const [isExpanded, setIsExpanded] = useState(initialExpanded);
  const validation = visionData ? validateVisionData(visionData) : null;
  
  if (isLoading) {
    return (
      <div className={`p-4 border rounded-md bg-muted animate-pulse h-32 flex items-center justify-center ${className}`}>
        <Loader2 className="h-6 w-6 animate-spin" />
        <span className="ml-2">Loading vision data...</span>
      </div>
    );
  }
  
  if (!visionData) {
    return (
      <Alert variant="destructive" className={`mb-4 ${className}`}>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          No vision data available for this image. Try analyzing it again.
        </AlertDescription>
      </Alert>
    );
  }
  
  return (
    <div className={`border rounded-md overflow-hidden ${className}`}>
      <div 
        className="bg-muted p-3 flex justify-between items-center cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2">
          <Braces className="h-4 w-4" />
          <span className="font-medium">Vision API Data</span>
          
          {validation && (
            <div className="flex items-center gap-1 ml-2">
              <Badge 
                variant={validation.isValid ? "default" : "outline"} 
                className={validation.isValid ? "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300" : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"}
              >
                {validation.isValid 
                  ? <div className="flex items-center"><FileCheck className="h-3 w-3 mr-1" /> Valid</div>
                  : <div className="flex items-center"><AlertTriangle className="h-3 w-3 mr-1" /> Missing Fields</div>
                }
              </Badge>
            </div>
          )}
        </div>
        <Button variant="ghost" size="sm">
          {isExpanded ? "Collapse" : "Expand"}
        </Button>
      </div>
      
      {validation && !validation.isValid && (
        <div className="px-3 py-2 bg-yellow-50 border-t border-b border-yellow-200 text-xs text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300 dark:border-yellow-800/30">
          <div className="flex items-center">
            <Info className="h-3 w-3 mr-1" />
            Missing fields: {validation.missingFields.join(', ')}
          </div>
        </div>
      )}
      
      {isExpanded && (
        <div className="p-4 bg-card max-h-96 overflow-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Labels ({visionData.labels.length})</h4>
              <div className="border rounded p-2 bg-muted/20">
                {visionData.labels.length > 0 ? (
                  <div className="flex flex-wrap gap-1">
                    {visionData.labels.map((label, i) => (
                      <Badge key={i} variant="outline" className="text-xs">
                        {label}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs text-muted-foreground">No labels found</div>
                )}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium mb-1">Objects ({visionData.objects.length})</h4>
              <div className="border rounded p-2 bg-muted/20">
                {visionData.objects.length > 0 ? (
                  <div className="flex flex-wrap gap-1">
                    {visionData.objects.map((obj, i) => (
                      <Badge key={i} variant="outline" className="text-xs">
                        {obj}
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs text-muted-foreground">No objects found</div>
                )}
              </div>
            </div>
          </div>
          
          <Separator className="my-3" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="text-sm font-medium mb-1">Colors ({visionData.colors.length})</h4>
              <div className="border rounded p-2 bg-muted/20">
                {visionData.colors.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {visionData.colors.map((color, i) => (
                      <div key={i} className="flex items-center">
                        <div 
                          className="w-4 h-4 rounded-full mr-1" 
                          style={{ backgroundColor: color }}
                        />
                        <span className="text-xs">{color}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs text-muted-foreground">No colors found</div>
                )}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium mb-1">Safety Check</h4>
              <div className="border rounded p-2 bg-muted/20">
                {visionData.safeSearch ? (
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span>Adult content:</span>
                      <Badge variant={
                        visionData.safeSearch.adult === 'LIKELY' || visionData.safeSearch.adult === 'VERY_LIKELY' 
                          ? 'destructive' 
                          : 'default'
                      }
                      className={
                        visionData.safeSearch.adult === 'LIKELY' || visionData.safeSearch.adult === 'VERY_LIKELY' 
                          ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300' 
                          : 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300'
                      }>
                        {visionData.safeSearch.adult}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span>Violence:</span>
                      <Badge variant={
                        visionData.safeSearch.violence === 'LIKELY' || visionData.safeSearch.violence === 'VERY_LIKELY' 
                          ? 'destructive' 
                          : 'default'
                      }
                      className={
                        visionData.safeSearch.violence === 'LIKELY' || visionData.safeSearch.violence === 'VERY_LIKELY' 
                          ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300' 
                          : 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300'
                      }>
                        {visionData.safeSearch.violence}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span>Racy content:</span>
                      <Badge variant={
                        visionData.safeSearch.racy === 'LIKELY' || visionData.safeSearch.racy === 'VERY_LIKELY' 
                          ? 'destructive' 
                          : 'default'
                      }
                      className={
                        visionData.safeSearch.racy === 'LIKELY' || visionData.safeSearch.racy === 'VERY_LIKELY' 
                          ? 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300' 
                          : 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300'
                      }>
                        {visionData.safeSearch.racy}
                      </Badge>
                    </div>
                  </div>
                ) : (
                  <div className="text-xs text-muted-foreground">No safety data available</div>
                )}
              </div>
            </div>
          </div>
          
          <Separator className="my-3" />
          
          <details>
            <summary className="text-xs cursor-pointer font-medium mb-1">Raw JSON Data</summary>
            <pre className="text-xs mt-2 p-2 bg-muted rounded overflow-auto max-h-40">{JSON.stringify(visionData, null, 2)}</pre>
          </details>
        </div>
      )}
    </div>
  );
};

export default VisionDataPanel;
