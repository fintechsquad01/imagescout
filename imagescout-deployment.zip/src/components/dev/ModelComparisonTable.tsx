
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info, Award, AlertTriangle, Clock } from "lucide-react";
import { ModelComparisonResult, ModelComparisonResultWithCache } from '@/types/types';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface ModelComparisonTableProps {
  results: ModelComparisonResultWithCache[];
  isLoading: boolean;
}

const ModelComparisonTable: React.FC<ModelComparisonTableProps> = ({ 
  results,
  isLoading
}) => {
  if (isLoading) {
    return (
      <Card className="w-full">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Model Comparison</CardTitle>
          <Skeleton className="h-4 w-full mt-2" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!results || results.length === 0) {
    return (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          No comparison results available. Please select models to compare and run the analysis.
        </AlertDescription>
      </Alert>
    );
  }

  // Find the highest scoring model
  const highestScore = Math.max(...results.map(r => r.score));
  const bestModel = results.find(r => r.score === highestScore);

  // Helper function to safely check for error in visionData
  const hasError = (result: ModelComparisonResult): boolean => {
    // Check if visionData exists and if it has an 'error' property
    return result.visionData ? 'error' in result.visionData && !!result.visionData.error : false;
  };

  // Format cache date
  const formatCacheDate = (dateString?: string): string => {
    if (!dateString) return 'N/A';
    
    try {
      const date = new Date(dateString);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      
      if (diffMins < 60) {
        return `${diffMins} min${diffMins !== 1 ? 's' : ''} ago`;
      } else {
        const diffHrs = Math.floor(diffMins / 60);
        if (diffHrs < 24) {
          return `${diffHrs} hr${diffHrs !== 1 ? 's' : ''} ago`;
        } else {
          return date.toLocaleString();
        }
      }
    } catch (e) {
      return dateString;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Model Comparison</CardTitle>
          {bestModel && (
            <div className="flex items-center gap-2">
              <Award className="h-4 w-4 text-yellow-500" />
              <span className="text-sm">Best: {bestModel.modelName} ({bestModel.score})</span>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="scores">
          <TabsList className="mb-4">
            <TabsTrigger value="scores">Overall Scores</TabsTrigger>
            <TabsTrigger value="details">Detailed Comparison</TabsTrigger>
            <TabsTrigger value="raw">Raw Data</TabsTrigger>
          </TabsList>
          
          <TabsContent value="scores">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Model</TableHead>
                  <TableHead>Version</TableHead>
                  <TableHead className="text-right">Score</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((result) => (
                  <TableRow key={result.modelId}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {result.modelName}
                        {result.cacheStatus?.fromCache && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger>
                                <Badge variant="secondary" className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  <span className="text-xs">cached</span>
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Loaded from cache</p>
                                <p className="text-xs">
                                  {result.cacheStatus.cacheDate ? 
                                    `Cached: ${formatCacheDate(result.cacheStatus.cacheDate)}` : 
                                    'Cache information unavailable'}
                                </p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{result.modelVersion}</TableCell>
                    <TableCell className="text-right">
                      <Badge className={result.score === highestScore ? "bg-green-500" : ""}>
                        {result.score}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {hasError(result) ? (
                        <Badge variant="destructive">Failed</Badge>
                      ) : (
                        <Badge variant="outline">Success</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>
          
          <TabsContent value="details">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Model</TableHead>
                  <TableHead className="text-right">Labels</TableHead>
                  <TableHead className="text-right">Objects</TableHead>
                  <TableHead className="text-right">Landmarks</TableHead>
                  <TableHead className="text-right">Colors</TableHead>
                  <TableHead className="text-right">Source</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((result) => (
                  <TableRow key={result.modelId}>
                    <TableCell className="font-medium">{result.modelName}</TableCell>
                    <TableCell className="text-right">{result.visionData?.labels?.length || 0}</TableCell>
                    <TableCell className="text-right">{result.visionData?.objects?.length || 0}</TableCell>
                    <TableCell className="text-right">{result.visionData?.landmarks?.length || 0}</TableCell>
                    <TableCell className="text-right">{result.visionData?.colors?.length || 0}</TableCell>
                    <TableCell className="text-right">
                      {result.cacheStatus?.fromCache ? (
                        <Badge variant="secondary">Cache</Badge>
                      ) : (
                        <Badge variant="default">API</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>
          
          <TabsContent value="raw">
            <div className="overflow-auto max-h-96">
              <pre className="p-4 bg-muted rounded-md text-xs font-mono whitespace-pre-wrap">
                {JSON.stringify(results, null, 2)}
              </pre>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default ModelComparisonTable;
