import React from 'react';
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { isDevelopmentMode } from '@/utils/devMode';

const DevModeIndicator = () => {
  if (!isDevelopmentMode()) {
    return null;
  }

  return (
    <div className="bg-yellow-200 text-yellow-800 px-2 py-1 rounded text-xs font-medium dark:bg-yellow-800/40 dark:text-yellow-300">
      🛠️ Dev Mode
    </div>
  );
};

const DevNav = ({ className }: { className?: string }) => {
  return (
    <div className={cn("bg-yellow-50 p-2 rounded-lg border border-yellow-200 dark:bg-yellow-950/30 dark:border-yellow-800/50", className)}>
      <div className="flex items-center gap-1 flex-wrap">
        <DevModeIndicator />
        
        <div className="flex-1" />
        
        <Link to="/" className="bg-yellow-100/80 hover:bg-yellow-200/80 text-yellow-800 px-2 py-1 rounded text-xs font-medium dark:bg-yellow-900/30 dark:hover:bg-yellow-800/40 dark:text-yellow-300">
          Dashboard
        </Link>
        
        <Link to="/test-scoring" className="bg-yellow-100/80 hover:bg-yellow-200/80 text-yellow-800 px-2 py-1 rounded text-xs font-medium dark:bg-yellow-900/30 dark:hover:bg-yellow-800/40 dark:text-yellow-300">
          Test Scoring
        </Link>
        
        <Link to="/batch-scoring" className="bg-yellow-100/80 hover:bg-yellow-200/80 text-yellow-800 px-2 py-1 rounded text-xs font-medium dark:bg-yellow-900/30 dark:hover:bg-yellow-800/40 dark:text-yellow-300">
          Batch Scoring
        </Link>
        
        <Link to="/admin/scoring-analytics" className="bg-yellow-100/80 hover:bg-yellow-200/80 text-yellow-800 px-2 py-1 rounded text-xs font-medium dark:bg-yellow-900/30 dark:hover:bg-yellow-800/40 dark:text-yellow-300">
          Analytics
        </Link>
        
        <Link to="/admin/scoring-logs" className="bg-yellow-100/80 hover:bg-yellow-200/80 text-yellow-800 px-2 py-1 rounded text-xs font-medium dark:bg-yellow-900/30 dark:hover:bg-yellow-800/40 dark:text-yellow-300">
          Logs
        </Link>
        
        <Link to="/admin/feedback" className="bg-yellow-100/80 hover:bg-yellow-200/80 text-yellow-800 px-2 py-1 rounded text-xs font-medium dark:bg-yellow-900/30 dark:hover:bg-yellow-800/40 dark:text-yellow-300">
          Feedback
        </Link>
      </div>
    </div>
  );
};

export default DevNav;
