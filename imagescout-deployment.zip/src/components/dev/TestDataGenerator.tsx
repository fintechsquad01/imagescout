
import React, { useState } from 'react';
import { isDevelopmentMode } from '@/utils/devMode';
import { Button } from '@/components/ui/button';
import { Loader2, Database, Beaker, HelpCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { toast } from 'sonner';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export const TestDataGenerator = () => {
  const [isGenerating, setIsGenerating] = React.useState(false);
  const [popoverOpen, setPopoverOpen] = useState(false);

  // This is a placeholder for generating test data
  const generateTestData = async () => {
    if (!isDevelopmentMode()) return;
    
    try {
      setIsGenerating(true);
      // Here you would add logic to generate test data
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate work
      
      toast.success("Test data generated", {
        description: "Sample test data has been added to your account.",
        duration: 5000,
      });
      
      setPopoverOpen(false);
    } catch (error) {
      console.error('Error generating test data:', error);
      toast.error("Failed to generate test data", {
        description: error instanceof Error ? error.message : "Unknown error occurred",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  if (!isDevelopmentMode()) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className="mb-2">
              <Button 
                size="sm" 
                variant="secondary"
                className="flex items-center"
              >
                <HelpCircle className="h-4 w-4 mr-2" />
                <span>Testing Guide</span>
              </Button>
            </div>
          </TooltipTrigger>
          <TooltipContent side="left" className="w-80 p-4" align="end">
            <div className="space-y-2">
              <h4 className="font-medium">Developer Testing Workflow</h4>
              <ol className="list-decimal pl-4 text-sm space-y-1">
                <li>Use the "Generate Test Data" button to create sample scoring data</li>
                <li>Test scoring feedback submission with different ratings</li>
                <li>Check admin dashboard to view submitted feedback analytics</li>
                <li>Try different scoring models in the admin test scoring page</li>
              </ol>
              <div className="text-xs text-muted-foreground mt-2">
                Note: All generated data is marked with a "test" flag and can be filtered separately in analytics
              </div>
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      
      <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
        <PopoverTrigger asChild>
          <Button
            size="sm"
            variant="outline"
            className="bg-amber-100 hover:bg-amber-200 text-amber-800 border-amber-300 dark:bg-amber-950/50 dark:hover:bg-amber-950 dark:text-amber-400 dark:border-amber-800/50"
          >
            <Beaker className="mr-2 h-4 w-4" />
            Generate Test Data
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80" align="end">
          <div className="space-y-4">
            <div className="flex items-start space-x-2">
              <Beaker className="h-5 w-5 text-amber-500 mt-0.5" />
              <div>
                <h4 className="font-medium">Generate Test Data</h4>
                <p className="text-sm text-muted-foreground mt-1">
                  This will create sample scoring data for testing the admin dashboard and visualization features.
                </p>
              </div>
            </div>
            <div className="grid gap-2">
              <div className="rounded-md bg-amber-50 p-3 text-xs text-amber-700 dark:bg-amber-950/30 dark:text-amber-400">
                <p className="flex items-center">
                  <Database className="h-3 w-3 mr-1.5 inline" />
                  Only available in development mode
                </p>
              </div>
              <Button 
                onClick={generateTestData} 
                disabled={isGenerating}
                className="w-full"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  "Generate Test Data"
                )}
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default TestDataGenerator;
