
import React from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Beaker } from 'lucide-react';
import { isDevelopmentMode, getDetailedDevModeStatus, getDevModeLogStyle } from '@/utils/devMode';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface DevModeBannerProps {
  context?: string;
  showDetails?: boolean;
  className?: string;
  message?: string;
}

const DevModeBanner: React.FC<DevModeBannerProps> = ({
  context = "This page",
  showDetails = false,
  className = "",
  message
}) => {
  const isDevMode = isDevelopmentMode();
  
  if (!isDevMode) return null;
  
  const { features } = getDetailedDevModeStatus();
  
  const handleCopyLogs = () => {
    const logStyle = getDevModeLogStyle();
    console.log('%c[DEV MODE] Development environment detected', logStyle);
    console.log('[DEV MODE] Status: All authentication and authorization bypassed');
    console.log('[DEV MODE] Active features:', features.join(', '));
    console.log('[DEV MODE] Context:', context);
    if (message) console.log('[DEV MODE] Message:', message);
  };
  
  return (
    <Alert className={`border-amber-200 bg-amber-50/50 dark:bg-amber-900/20 ${className}`}>
      <Beaker className="h-4 w-4 text-amber-500" />
      <div className="flex justify-between w-full items-center">
        <div>
          <AlertTitle className="flex items-center">
            Development Mode
            <Badge className="ml-2 bg-amber-500 hover:bg-amber-600">Local Testing</Badge>
          </AlertTitle>
          <AlertDescription>
            {message || `${context} is running in development mode with all access restrictions bypassed.`}
            {showDetails && features.length > 0 && (
              <ul className="mt-2 list-disc list-inside space-y-1 text-xs">
                {features.map((feature, index) => (
                  <li key={index}>{feature}</li>
                ))}
              </ul>
            )}
          </AlertDescription>
        </div>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="outline" 
                size="sm" 
                className="ml-2 text-amber-600 border-amber-200 hover:bg-amber-100 hover:text-amber-700"
                onClick={handleCopyLogs}
              >
                View Logs
              </Button>
            </TooltipTrigger>
            <TooltipContent side="left">
              <p className="max-w-xs">
                View detailed development mode status in the console
              </p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </Alert>
  );
};

export default DevModeBanner;
