import { analyzeAndTransformImage } from '@/lib/ai/pipeline';
import { useState } from 'react';

// Types for the component props
interface ImageScoutUIProps {
  onAnalysisComplete?: (result: any) => void;
  initialPlatform?: 'instagram' | 'tiktok' | 'youtube' | 'linkedin' | 'twitter';
  showVideoOption?: boolean;
  className?: string;
}

export const ImageScoutUI = ({
  onAnalysisComplete,
  initialPlatform = 'instagram',
  showVideoOption = true,
  className = ''
}: ImageScoutUIProps) => {
  // State for the component
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [platform, setPlatform] = useState<string>(initialPlatform);
  const [createVideo, setCreateVideo] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  // Handle file selection
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      setPreviewUrl(URL.createObjectURL(file));
      setAnalysisResult(null);
      setError(null);
    }
  };

  // Handle platform selection
  const handlePlatformChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setPlatform(event.target.value);
  };

  // Handle video option toggle
  const handleVideoToggle = () => {
    setCreateVideo(!createVideo);
  };

  // Handle analysis submission
  const handleAnalyze = async () => {
    if (!selectedFile) {
      setError('Please select an image to analyze');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const result = await analyzeAndTransformImage({
        imageFile: selectedFile,
        platform: platform as any,
        createVideo,
        videoDuration: 6,
        motionType: 'subtle',
        optimizeForPlatform: true
      });

      setAnalysisResult(result);
      
      if (onAnalysisComplete) {
        onAnalysisComplete(result);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred during analysis');
      console.error('Analysis error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className={`image-scout-container ${className}`}>
      <div className="image-scout-upload">
        <h2 className="text-xl font-bold mb-4">Image Scout</h2>
        
        {/* Image Upload */}
        <div className="upload-section mb-6">
          <label className="block text-sm font-medium mb-2">Upload Image</label>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="w-full p-2 border rounded"
          />
          
          {previewUrl && (
            <div className="mt-4 preview-container">
              <img
                src={previewUrl}
                alt="Preview"
                className="max-w-full h-auto max-h-64 rounded"
              />
            </div>
          )}
        </div>
        
        {/* Options */}
        <div className="options-section mb-6">
          <div className="mb-4">
            <label className="block text-sm font-medium mb-2">Platform</label>
            <select
              value={platform}
              onChange={handlePlatformChange}
              className="w-full p-2 border rounded"
              disabled={isAnalyzing}
            >
              <option value="instagram">Instagram</option>
              <option value="tiktok">TikTok</option>
              <option value="youtube">YouTube</option>
              <option value="linkedin">LinkedIn</option>
              <option value="twitter">Twitter</option>
            </select>
          </div>
          
          {showVideoOption && (
            <div className="mb-4 flex items-center">
              <input
                type="checkbox"
                id="createVideo"
                checked={createVideo}
                onChange={handleVideoToggle}
                className="mr-2"
                disabled={isAnalyzing}
              />
              <label htmlFor="createVideo" className="text-sm font-medium">
                Create video from image
              </label>
            </div>
          )}
        </div>
        
        {/* Action Button */}
        <button
          onClick={handleAnalyze}
          disabled={!selectedFile || isAnalyzing}
          className={`w-full p-3 rounded font-medium ${
            !selectedFile || isAnalyzing
              ? 'bg-gray-300 text-gray-500'
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          {isAnalyzing ? 'Analyzing...' : 'Analyze Image'}
        </button>
        
        {error && (
          <div className="mt-4 p-3 bg-red-100 text-red-700 rounded">
            {error}
          </div>
        )}
      </div>
      
      {/* Results Section */}
      {analysisResult && (
        <div className="image-scout-results mt-8">
          <h3 className="text-lg font-bold mb-4">Analysis Results</h3>
          
          {/* Scores */}
          <div className="scores-section mb-6 grid grid-cols-4 gap-4">
            <div className="score-card p-4 border rounded text-center">
              <div className="text-2xl font-bold">{analysisResult.overallScore}</div>
              <div className="text-sm">Overall Score</div>
            </div>
            <div className="score-card p-4 border rounded text-center">
              <div className="text-2xl font-bold">{analysisResult.viralityScore}</div>
              <div className="text-sm">Virality</div>
            </div>
            <div className="score-card p-4 border rounded text-center">
              <div className="text-2xl font-bold">{analysisResult.aestheticScore}</div>
              <div className="text-sm">Aesthetic</div>
            </div>
            <div className="score-card p-4 border rounded text-center">
              <div className="text-2xl font-bold">{analysisResult.repurposeScore}</div>
              <div className="text-sm">Repurpose</div>
            </div>
          </div>
          
          {/* Analysis */}
          <div className="analysis-section mb-6">
            <h4 className="font-medium mb-2">Analysis</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="analysis-card p-4 border rounded">
                <h5 className="font-medium text-green-600 mb-2">Strengths</h5>
                <ul className="list-disc pl-5">
                  {analysisResult.analysis.strengths.map((strength: string, index: number) => (
                    <li key={`strength-${index}`} className="mb-1 text-sm">
                      {strength}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="analysis-card p-4 border rounded">
                <h5 className="font-medium text-red-600 mb-2">Weaknesses</h5>
                <ul className="list-disc pl-5">
                  {analysisResult.analysis.weaknesses.map((weakness: string, index: number) => (
                    <li key={`weakness-${index}`} className="mb-1 text-sm">
                      {weakness}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="analysis-card p-4 border rounded">
                <h5 className="font-medium text-blue-600 mb-2">Opportunities</h5>
                <ul className="list-disc pl-5">
                  {analysisResult.analysis.opportunities.map((opportunity: string, index: number) => (
                    <li key={`opportunity-${index}`} className="mb-1 text-sm">
                      {opportunity}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
          
          {/* Recommendations */}
          <div className="recommendations-section mb-6">
            <h4 className="font-medium mb-2">Recommendations</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="recommendation-card p-4 border rounded">
                <h5 className="font-medium mb-2">Composition</h5>
                <ul className="list-disc pl-5">
                  {analysisResult.recommendations.composition.map((rec: string, index: number) => (
                    <li key={`comp-${index}`} className="mb-1 text-sm">
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="recommendation-card p-4 border rounded">
                <h5 className="font-medium mb-2">Styling</h5>
                <ul className="list-disc pl-5">
                  {analysisResult.recommendations.styling.map((rec: string, index: number) => (
                    <li key={`style-${index}`} className="mb-1 text-sm">
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
          
          {/* Platform-Specific Recommendations */}
          <div className="platform-recommendations-section mb-6">
            <h4 className="font-medium mb-2">{platform.charAt(0).toUpperCase() + platform.slice(1)} Recommendations</h4>
            
            <div className="p-4 border rounded">
              <ul className="list-disc pl-5">
                {analysisResult.recommendations.platformSpecific[platform]?.map((rec: string, index: number) => (
                  <li key={`platform-${index}`} className="mb-1 text-sm">
                    {rec}
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          {/* Transformed Content */}
          {analysisResult.transformedContent && (
            <div className="transformed-content-section mb-6">
              <h4 className="font-medium mb-2">Transformed Content</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {analysisResult.transformedContent.optimizedImageUrl && (
                  <div className="p-4 border rounded">
                    <h5 className="font-medium mb-2">Optimized Image</h5>
                    <img
                      src={analysisResult.transformedContent.optimizedImageUrl}
                      alt="Optimized"
                      className="max-w-full h-auto rounded"
                    />
                    <a
                      href={analysisResult.transformedContent.optimizedImageUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block mt-2 text-sm text-blue-600"
                    >
                      Download Optimized Image
                    </a>
                  </div>
                )}
                
                {analysisResult.transformedContent.videoUrl && (
                  <div className="p-4 border rounded">
                    <h5 className="font-medium mb-2">Generated Video</h5>
                    <video
                      src={analysisResult.transformedContent.videoUrl}
                      controls
                      poster={analysisResult.transformedContent.thumbnailUrl}
                      className="max-w-full h-auto rounded"
                    />
                    <a
                      href={analysisResult.transformedContent.videoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block mt-2 text-sm text-blue-600"
                    >
                      Download Video
                    </a>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {/* Metadata */}
          <div className="metadata-section text-xs text-gray-500">
            Processing time: {analysisResult.metadata.processingTime}ms | 
            Image size: {Math.round(analysisResult.metadata.imageSize / 1024)} KB | 
            AI models: {analysisResult.metadata.aiModelsUsed.join(', ')}
          </div>
        </div>
      )}
    </div>
  );
};
