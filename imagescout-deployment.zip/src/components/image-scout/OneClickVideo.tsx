import { useState } from 'react';
import { analyzeAndTransformImage } from '@/lib/ai/pipeline';
import { enhancedAnalyzeAndTransform, validateAndProcessImage, getPlatformDefaults } from '@/lib/ai/refinements';

// Types for the component props
interface OneClickVideoProps {
  onVideoCreated?: (videoUrl: string, thumbnailUrl: string) => void;
  onError?: (error: string) => void;
  className?: string;
}

export const OneClickVideo = ({
  onVideoCreated,
  onError,
  className = ''
}: OneClickVideoProps) => {
  // State for the component
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  const [platform, setPlatform] = useState<string>('tiktok');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [results, setResults] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Handle file selection
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const fileArray = Array.from(files);
      setSelectedFiles(fileArray);
      
      // Create preview URLs
      const urls = fileArray.map(file => URL.createObjectURL(file));
      setPreviewUrls(urls);
      
      // Reset states
      setResults([]);
      setError(null);
      setProgress(0);
    }
  };

  // Handle platform selection
  const handlePlatformChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setPlatform(event.target.value);
  };

  // Handle one-click video creation
  const handleCreateVideos = async () => {
    if (selectedFiles.length === 0) {
      setError('Please select at least one image');
      return;
    }

    setIsProcessing(true);
    setError(null);
    setProgress(0);
    setResults([]);

    try {
      const newResults = [];
      
      for (let i = 0; i < selectedFiles.length; i++) {
        // Update progress
        setProgress(Math.round((i / selectedFiles.length) * 100));
        
        // Validate image
        const validationResult = await validateAndProcessImage(selectedFiles[i], null);
        if (!validationResult.success) {
          throw new Error(`Image ${i+1} validation failed: ${validationResult.error}`);
        }
        
        // Get platform defaults
        const platformDefaults = getPlatformDefaults(platform);
        
        // Process image
        const result = await enhancedAnalyzeAndTransform({
          imageFile: selectedFiles[i],
          platform: platform as any,
          createVideo: true,
          videoDuration: platform === 'tiktok' ? 9 : 6,
          motionType: 'subtle',
          optimizeForPlatform: true,
          aspectRatio: platformDefaults.aspectRatio,
          resolution: platformDefaults.recommendedResolution
        });
        
        if (!result.success) {
          throw new Error(`Processing failed for image ${i+1}: ${result.error}`);
        }
        
        newResults.push(result);
        
        // Notify if callback provided
        if (onVideoCreated && result.transformedContent?.videoUrl) {
          onVideoCreated(
            result.transformedContent.videoUrl,
            result.transformedContent.thumbnailUrl || ''
          );
        }
      }
      
      setResults(newResults);
      setProgress(100);
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred during processing');
      if (onError) {
        onError(err instanceof Error ? err.message : 'An error occurred during processing');
      }
      console.error('Processing error:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  // Clean up preview URLs when component unmounts
  React.useEffect(() => {
    return () => {
      previewUrls.forEach(url => URL.revokeObjectURL(url));
    };
  }, [previewUrls]);

  return (
    <div className={`one-click-video-container ${className}`}>
      <div className="upload-section mb-6">
        <h2 className="text-xl font-bold mb-4">One-Click Video Creation</h2>
        
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Upload Images (Up to 10)</label>
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={handleFileChange}
            className="w-full p-2 border rounded"
            disabled={isProcessing}
            max="10"
          />
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium mb-2">Target Platform</label>
          <select
            value={platform}
            onChange={handlePlatformChange}
            className="w-full p-2 border rounded"
            disabled={isProcessing}
          >
            <option value="tiktok">TikTok</option>
            <option value="instagram">Instagram</option>
            <option value="youtube">YouTube</option>
          </select>
        </div>
        
        {selectedFiles.length > 0 && (
          <div className="preview-grid grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 mb-4">
            {previewUrls.map((url, index) => (
              <div key={index} className="preview-item">
                <img
                  src={url}
                  alt={`Preview ${index + 1}`}
                  className="w-full h-auto rounded"
                />
                <div className="text-xs text-center mt-1">Image {index + 1}</div>
              </div>
            ))}
          </div>
        )}
        
        <button
          onClick={handleCreateVideos}
          disabled={selectedFiles.length === 0 || isProcessing}
          className={`w-full p-3 rounded font-medium ${
            selectedFiles.length === 0 || isProcessing
              ? 'bg-gray-300 text-gray-500'
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          {isProcessing ? 'Creating Videos...' : 'Create Videos'}
        </button>
        
        {isProcessing && (
          <div className="mt-4">
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-blue-600 h-2.5 rounded-full"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <div className="text-sm text-center mt-1">
              Processing {progress}% complete
            </div>
          </div>
        )}
        
        {error && (
          <div className="mt-4 p-3 bg-red-100 text-red-700 rounded">
            {error}
          </div>
        )}
      </div>
      
      {results.length > 0 && (
        <div className="results-section">
          <h3 className="text-lg font-bold mb-4">Created Videos</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {results.map((result, index) => (
              <div key={index} className="video-result p-4 border rounded">
                <h4 className="font-medium mb-2">Video {index + 1}</h4>
                
                {result.transformedContent?.videoUrl ? (
                  <div>
                    <video
                      src={result.transformedContent.videoUrl}
                      controls
                      poster={result.transformedContent.thumbnailUrl}
                      className="w-full h-auto rounded mb-2"
                    />
                    
                    <div className="flex space-x-2">
                      <a
                        href={result.transformedContent.videoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 text-center p-2 bg-blue-100 text-blue-700 rounded text-sm"
                      >
                        Download Video
                      </a>
                      
                      {result.transformedContent.optimizedImageUrl && (
                        <a
                          href={result.transformedContent.optimizedImageUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex-1 text-center p-2 bg-green-100 text-green-700 rounded text-sm"
                        >
                          Download Image
                        </a>
                      )}
                    </div>
                    
                    <div className="mt-2 text-xs text-gray-500">
                      Virality Score: {result.viralityScore} | 
                      Platform: {platform} | 
                      Processing Time: {result.metadata.processingTime}ms
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-yellow-100 text-yellow-700 rounded">
                    Video processing failed
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
