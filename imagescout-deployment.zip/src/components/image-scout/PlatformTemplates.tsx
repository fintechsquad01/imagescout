import { useState } from 'react';
import { getPlatformDefaults } from '@/lib/ai/refinements';

// Types for platform templates
export interface PlatformTemplate {
  id: string;
  name: string;
  platform: 'instagram' | 'tiktok' | 'youtube' | 'linkedin' | 'twitter';
  description: string;
  aspectRatio: string;
  resolution: string;
  videoDuration?: number;
  motionType?: 'zoom' | 'pan' | 'parallax' | 'ken-burns' | 'subtle';
  colorScheme?: string;
  contentType: 'lifestyle' | 'product' | 'travel' | 'fashion' | 'general';
  bestFor: string[];
  preview?: string;
}

// Pre-configured templates
const PLATFORM_TEMPLATES: PlatformTemplate[] = [
  {
    id: 'instagram-lifestyle',
    name: 'Instagram Lifestyle',
    platform: 'instagram',
    description: 'Perfect for luxury lifestyle content on Instagram feed',
    aspectRatio: '1:1',
    resolution: '1080x1080',
    videoDuration: 6,
    motionType: 'subtle',
    colorScheme: 'Warm, high contrast',
    contentType: 'lifestyle',
    bestFor: ['Product showcases', 'Luxury settings', 'Fashion items']
  },
  {
    id: 'instagram-story',
    name: 'Instagram Story',
    platform: 'instagram',
    description: 'Optimized for Instagram stories with vertical format',
    aspectRatio: '9:16',
    resolution: '1080x1920',
    videoDuration: 5,
    motionType: 'zoom',
    colorScheme: 'Bold, vibrant',
    contentType: 'lifestyle',
    bestFor: ['Quick moments', 'Behind the scenes', 'Teasers']
  },
  {
    id: 'tiktok-viral',
    name: 'TikTok Viral',
    platform: 'tiktok',
    description: 'Designed for maximum engagement on TikTok',
    aspectRatio: '9:16',
    resolution: '1080x1920',
    videoDuration: 9,
    motionType: 'parallax',
    colorScheme: 'High saturation',
    contentType: 'travel',
    bestFor: ['Trending content', 'Luxury destinations', 'Dramatic reveals']
  },
  {
    id: 'tiktok-luxury',
    name: 'TikTok Luxury',
    platform: 'tiktok',
    description: 'Elegant and sophisticated style for luxury brands',
    aspectRatio: '9:16',
    resolution: '1080x1920',
    videoDuration: 7,
    motionType: 'subtle',
    colorScheme: 'Muted, elegant',
    contentType: 'fashion',
    bestFor: ['Fashion items', 'Luxury products', 'Exclusive experiences']
  },
  {
    id: 'youtube-thumbnail',
    name: 'YouTube Thumbnail',
    platform: 'youtube',
    description: 'Eye-catching thumbnail optimization for YouTube',
    aspectRatio: '16:9',
    resolution: '1280x720',
    contentType: 'general',
    bestFor: ['Video thumbnails', 'Channel art', 'Preview images']
  },
  {
    id: 'youtube-shorts',
    name: 'YouTube Shorts',
    platform: 'youtube',
    description: 'Vertical video format for YouTube Shorts',
    aspectRatio: '9:16',
    resolution: '1080x1920',
    videoDuration: 15,
    motionType: 'ken-burns',
    colorScheme: 'Vibrant, attention-grabbing',
    contentType: 'travel',
    bestFor: ['Short-form content', 'Quick tutorials', 'Travel highlights']
  }
];

// Types for the component props
interface PlatformTemplatesProps {
  onSelectTemplate: (template: PlatformTemplate) => void;
  initialPlatform?: 'instagram' | 'tiktok' | 'youtube' | 'linkedin' | 'twitter';
  className?: string;
}

export const PlatformTemplates = ({
  onSelectTemplate,
  initialPlatform = 'instagram',
  className = ''
}: PlatformTemplatesProps) => {
  // State for the component
  const [selectedPlatform, setSelectedPlatform] = useState<string>(initialPlatform);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');

  // Filter templates by platform
  const filteredTemplates = PLATFORM_TEMPLATES.filter(
    template => template.platform === selectedPlatform
  );

  // Handle platform selection
  const handlePlatformChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedPlatform(event.target.value);
    setSelectedTemplate('');
  };

  // Handle template selection
  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId);
    const template = PLATFORM_TEMPLATES.find(t => t.id === templateId);
    if (template && onSelectTemplate) {
      onSelectTemplate(template);
    }
  };

  return (
    <div className={`platform-templates-container ${className}`}>
      <h2 className="text-xl font-bold mb-4">Platform Templates</h2>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Select Platform</label>
        <select
          value={selectedPlatform}
          onChange={handlePlatformChange}
          className="w-full p-2 border rounded"
        >
          <option value="instagram">Instagram</option>
          <option value="tiktok">TikTok</option>
          <option value="youtube">YouTube</option>
          <option value="linkedin">LinkedIn</option>
          <option value="twitter">Twitter</option>
        </select>
      </div>
      
      <div className="templates-grid grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        {filteredTemplates.map(template => (
          <div
            key={template.id}
            className={`template-card p-4 border rounded cursor-pointer transition-all ${
              selectedTemplate === template.id
                ? 'border-blue-500 bg-blue-50'
                : 'hover:border-gray-400'
            }`}
            onClick={() => handleTemplateSelect(template.id)}
          >
            <div className="flex justify-between items-start">
              <h3 className="font-medium">{template.name}</h3>
              {selectedTemplate === template.id && (
                <span className="text-blue-500 text-sm">Selected</span>
              )}
            </div>
            
            <p className="text-sm text-gray-600 mt-1 mb-2">
              {template.description}
            </p>
            
            <div className="template-specs grid grid-cols-2 gap-2 text-xs">
              <div className="spec-item">
                <span className="font-medium">Aspect Ratio:</span> {template.aspectRatio}
              </div>
              <div className="spec-item">
                <span className="font-medium">Resolution:</span> {template.resolution}
              </div>
              {template.videoDuration && (
                <div className="spec-item">
                  <span className="font-medium">Duration:</span> {template.videoDuration}s
                </div>
              )}
              {template.motionType && (
                <div className="spec-item">
                  <span className="font-medium">Motion:</span> {template.motionType}
                </div>
              )}
              <div className="spec-item col-span-2">
                <span className="font-medium">Best For:</span> {template.bestFor.join(', ')}
              </div>
            </div>
            
            <div className="aspect-preview mt-3">
              <div
                className="aspect-box border border-dashed border-gray-300 flex items-center justify-center"
                style={{
                  aspectRatio: template.aspectRatio.replace(':', '/'),
                  maxHeight: '100px'
                }}
              >
                <span className="text-xs text-gray-500">{template.aspectRatio}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {filteredTemplates.length === 0 && (
        <div className="p-4 bg-yellow-100 text-yellow-700 rounded">
          No templates available for {selectedPlatform}. Please select another platform.
        </div>
      )}
      
      {selectedTemplate && (
        <div className="selected-template-info p-4 bg-blue-50 border border-blue-200 rounded mt-4">
          <h3 className="font-medium mb-2">Selected Template</h3>
          <p className="text-sm">
            Apply this template to optimize your content for {selectedPlatform} with ideal
            settings for maximum engagement.
          </p>
          <button
            onClick={() => {
              const template = PLATFORM_TEMPLATES.find(t => t.id === selectedTemplate);
              if (template && onSelectTemplate) {
                onSelectTemplate(template);
              }
            }}
            className="mt-3 px-4 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
          >
            Apply Template
          </button>
        </div>
      )}
    </div>
  );
};
