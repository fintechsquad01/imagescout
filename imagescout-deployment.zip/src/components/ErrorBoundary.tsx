
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { Button } from '@/components/ui/button';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';
import { logToSupabase } from '@/lib/supabaseLogger';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      error
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    // Log error to console for development debugging
    console.error('Error caught by ErrorBoundary:', error);
    console.error('Component stack:', errorInfo.componentStack);
    
    // Attempt to log to Supabase for production monitoring
    try {
      logToSupabase({
        imageId: 'error-boundary',
        projectId: 'system',
        model: 'system',
        prompt: 'Error boundary caught exception',
        success: false,
        error: `${error.message}\n${errorInfo.componentStack}`
      });
    } catch (loggingError) {
      console.error('Failed to log error to Supabase:', loggingError);
    }
  }

  handleRetry = (): void => {
    this.setState({ hasError: false, error: null });
    // Refresh the page as a simple recovery mechanism
    window.location.reload();
  };

  render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-background p-4">
          <div className="w-full max-w-md space-y-6">
            <Alert variant="destructive" className="border-2">
              <AlertCircle className="h-5 w-5" />
              <AlertTitle className="text-lg font-semibold mb-2">Something went wrong</AlertTitle>
              <AlertDescription className="space-y-4">
                <p className="text-sm opacity-80">
                  We encountered an unexpected error. This has been logged for our team to investigate.
                </p>
                {this.state.error && (
                  <div className="p-2 bg-destructive/10 rounded text-xs font-mono overflow-auto max-h-32">
                    {this.state.error.message}
                  </div>
                )}
                <Button onClick={this.handleRetry} className="w-full mt-4">
                  Retry
                </Button>
              </AlertDescription>
            </Alert>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
