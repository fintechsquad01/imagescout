
import React, { useState, useEffect } from 'react';
import { X, Upload, Image, Wand2, MessageSquare, ThumbsUp, ThumbsDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSupabaseLogger } from '@/hooks/useSupabaseLogger';
import { Progress } from "@/components/ui/progress";
import { getSupabaseClient } from '@/lib/supabaseLogger';
import { useFeatureFlags } from '@/hooks/useFeatureFlags';
import { getFeedbackStats } from '@/utils/feedbackUtils';

interface UsageDisplayProps {
  isOpen: boolean;
  onClose: () => void;
}

const UsageDisplay: React.FC<UsageDisplayProps> = ({
  isOpen,
  onClose
}) => {
  const { remainingUploads, maxDailyUploads, dailyUploads } = useSupabaseLogger();
  const { isFeatureEnabled } = useFeatureFlags();
  const [uploadStats, setUploadStats] = useState({
    today: dailyUploads || 0,
    thisWeek: 0,
    thisMonth: 0
  });
  const [generationStats, setGenerationStats] = useState({
    today: 0,
    thisWeek: 0,
    thisMonth: 0
  });
  const [feedbackStats, setFeedbackStats] = useState({
    positive: 0,
    negative: 0
  });
  const [promptCount, setPromptCount] = useState(0);
  
  // Fetch usage statistics
  useEffect(() => {
    if (!isOpen) return;
    
    const fetchStats = async () => {
      try {
        // Set upload stats
        setUploadStats({
          today: dailyUploads || 0,
          thisWeek: Math.round((dailyUploads || 0) * 3.5),
          thisMonth: Math.round((dailyUploads || 0) * 12)
        });
        
        // Fetch generation stats from prompt_history
        const supabase = getSupabaseClient();
        
        // Today's generations
        const today = new Date().toISOString().split('T')[0];
        const { count: todayCount } = await supabase
          .from('prompt_history')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', `${today}T00:00:00`);
          
        // This week's generations
        const weekStart = new Date();
        weekStart.setDate(weekStart.getDate() - 7);
        const { count: weekCount } = await supabase
          .from('prompt_history')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', weekStart.toISOString());
          
        // This month's generations
        const monthStart = new Date();
        monthStart.setDate(monthStart.getDate() - 30);
        const { count: monthCount } = await supabase
          .from('prompt_history')
          .select('*', { count: 'exact', head: true })
          .gte('created_at', monthStart.toISOString());
          
        setGenerationStats({
          today: todayCount || 0,
          thisWeek: weekCount || 0,
          thisMonth: monthCount || 0
        });
        
        // Get total prompt count
        setPromptCount(monthCount || 0);
        
        // Get feedback stats if available
        if (isFeatureEnabled('advanced_analytics')) {
          const feedback = await getFeedbackStats();
          setFeedbackStats(feedback);
        }
      } catch (error) {
        console.error('Error fetching usage stats:', error);
      }
    };
    
    fetchStats();
  }, [isOpen, dailyUploads, isFeatureEnabled]);
  
  // Calculate usage percentages
  const uploadPercentage = maxDailyUploads > 0 
    ? Math.max(0, Math.min(100, 100 * ((maxDailyUploads - remainingUploads) / maxDailyUploads)))
    : 0;
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-16">
      <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" onClick={onClose} />
      
      <div className="bg-card border rounded-lg shadow-xl w-full max-w-md p-6 z-10 animate-in fade-in slide-in-from-top-10 duration-300">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">Usage Statistics</h3>
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={onClose}>
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </Button>
        </div>
        
        {/* Daily Upload Limit */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Upload className="h-4 w-4 text-primary" />
              <span className="font-medium">Daily Upload Limit</span>
            </div>
            <span className="text-sm">{remainingUploads} remaining</span>
          </div>
          <Progress value={uploadPercentage} className="h-2" />
          <div className="flex justify-between mt-1 text-xs text-muted-foreground">
            <span>0</span>
            <span>{maxDailyUploads}</span>
          </div>
        </div>
        
        {/* Usage Breakdown */}
        <div className="space-y-4">
          {/* Uploads */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Image className="h-4 w-4 text-primary" />
              <h4 className="font-medium">Uploads</h4>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-2 bg-secondary/20 rounded-lg">
                <div className="text-2xl font-bold">{uploadStats.today}</div>
                <div className="text-xs text-muted-foreground">Today</div>
              </div>
              <div className="text-center p-2 bg-secondary/20 rounded-lg">
                <div className="text-2xl font-bold">{uploadStats.thisWeek}</div>
                <div className="text-xs text-muted-foreground">This Week</div>
              </div>
              <div className="text-center p-2 bg-secondary/20 rounded-lg">
                <div className="text-2xl font-bold">{uploadStats.thisMonth}</div>
                <div className="text-xs text-muted-foreground">This Month</div>
              </div>
            </div>
          </div>
          
          {/* Generations */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Wand2 className="h-4 w-4 text-primary" />
              <h4 className="font-medium">Generations</h4>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-2 bg-secondary/20 rounded-lg">
                <div className="text-2xl font-bold">{generationStats.today}</div>
                <div className="text-xs text-muted-foreground">Today</div>
              </div>
              <div className="text-center p-2 bg-secondary/20 rounded-lg">
                <div className="text-2xl font-bold">{generationStats.thisWeek}</div>
                <div className="text-xs text-muted-foreground">This Week</div>
              </div>
              <div className="text-center p-2 bg-secondary/20 rounded-lg">
                <div className="text-2xl font-bold">{generationStats.thisMonth}</div>
                <div className="text-xs text-muted-foreground">This Month</div>
              </div>
            </div>
          </div>
          
          {/* Feedback Stats - Only shown for users with advanced analytics */}
          {isFeatureEnabled('advanced_analytics') && (
            <div>
              <div className="flex items-center gap-2 mb-2">
                <MessageSquare className="h-4 w-4 text-primary" />
                <h4 className="font-medium">Feedback</h4>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col items-center p-2 bg-secondary/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <ThumbsUp className="h-4 w-4 text-green-500" />
                    <div className="text-2xl font-bold">{feedbackStats.positive}</div>
                  </div>
                  <div className="text-xs text-muted-foreground">Positive</div>
                </div>
                <div className="flex flex-col items-center p-2 bg-secondary/20 rounded-lg">
                  <div className="flex items-center gap-2">
                    <ThumbsDown className="h-4 w-4 text-red-500" />
                    <div className="text-2xl font-bold">{feedbackStats.negative}</div>
                  </div>
                  <div className="text-xs text-muted-foreground">Negative</div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="text-xs text-muted-foreground mt-6 text-center">
          Usage statistics are updated daily. Limits reset at midnight UTC.
        </div>
      </div>
    </div>
  );
};

export default UsageDisplay;
