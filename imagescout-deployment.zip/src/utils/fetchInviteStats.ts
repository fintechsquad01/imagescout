
/**
 * @deprecated Use the modular utilities from @/utils/inviteStats instead
 */

// Re-export everything from the new modular structure for backward compatibility
export * from './inviteStats';
